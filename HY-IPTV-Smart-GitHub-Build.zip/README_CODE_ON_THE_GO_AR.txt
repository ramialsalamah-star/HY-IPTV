كيف تشغل المشروع في Code on the Go - HY IPTV V60 مصلح

1- فك الضغط وافتح مجلد project فقط (اللي فيه settings.gradle.kts) داخل التطبيق
2- من اعدادات التطبيق: اختر JDK 17
3- من Terminal داخل التطبيق نفذ:
   chmod +x gradlew
   rm -rf .gradle app/build
4- تأكد ان عندك انترنت قوي - اول مرة رح ينزل Gradle 8.0 وكل المكتبات (حوالي 300MB)
5- اضغط Run > Sync Project
6- اذا طلع خطأ اسحب من الاسفل لفوق لتشوف Logs

لو فشل على الموبايل (متوقع لان المشروع ثقيل) - ابنِه على الكمبيوتر:
export JAVA_HOME=/path/to/jdk17
./gradlew assembleDebug --no-daemon

APK: app/build/outputs/apk/debug/app-debug.apk

تم اصلاح:
- XtreamRepository كان خارج المسار الصحيح
- getSeriesEpisodes مفقودة
- jitpack مضاف
- VPN intent مضاف
- gradlew صلاحية تنفيذ
- gradle-8.0-bin بدل all لتخفيف الحجم
- compileSdk 34 بدل 35

اذا احتجت مساعدة صور لي الـ Build Output.
