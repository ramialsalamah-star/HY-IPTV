package com.hyiptv.player.ui.screens.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hyiptv.player.R
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
  onBack: () -> Unit,
  onPlayChannel: (Channel) -> Unit = {}
) {
  val context = LocalContext.current
  val repo = remember { ChannelRepository(context) }
  val scope = rememberCoroutineScope()
  val favorites by repo.favoritesFlow().collectAsState(initial = emptyList())

  Column(
    Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text(stringResource(R.string.favorites), color = GoldPrimary, fontWeight = FontWeight.Bold)
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    if (favorites.isEmpty()) {
      Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            Icons.Default.Favorite, null,
            tint = GoldPrimary.copy(alpha = 0.4f),
            modifier = Modifier.size(64.dp)
          )
          Spacer(Modifier.height(12.dp))
          Text("No favorites yet", color = TextMuted)
          Text(
            "اضغط القلب بجانب القناة لإضافتها",
            color = TextMuted,
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(favorites, key = { it.id }) { channel ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, DividerColor, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            onClick = {
              scope.launch { repo.markWatched(channel.id) }
              onPlayChannel(channel)
            }
          ) {
            Row(
              Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (!channel.logoUrl.isNullOrBlank()) {
                AsyncImage(
                  model = channel.logoUrl,
                  contentDescription = null,
                  modifier = Modifier
                    .size(48.dp)
                    .background(DarkSurface, RoundedCornerShape(8.dp)),
                  contentScale = ContentScale.Fit
                )
              } else {
                Box(
                  Modifier
                    .size(48.dp)
                    .background(GoldPrimary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.LiveTv, null, tint = GoldPrimary)
                }
              }
              Spacer(Modifier.width(14.dp))
              Column(Modifier.weight(1f)) {
                Text(channel.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                Text(channel.group, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
              }
              IconButton(onClick = {
                scope.launch { repo.toggleFavorite(channel.id) }
              }) {
                Icon(Icons.Default.Favorite, null, tint = GoldPrimary)
              }
            }
          }
        }
      }
    }
  }
}
