package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences

class DeviceModeManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("hy_device_mode", Context.MODE_PRIVATE)

  companion object {
    const val MODE_PHONE = "phone"
    const val MODE_TV = "tv"
    private const val KEY_MODE = "mode"
    private const val KEY_CHOSEN = "chosen"
  }

  fun hasChosenMode(): Boolean = prefs.getBoolean(KEY_CHOSEN, false)

  fun getMode(): String = prefs.getString(KEY_MODE, MODE_PHONE) ?: MODE_PHONE

  fun setMode(mode: String) {
    prefs.edit()
      .putString(KEY_MODE, mode)
      .putBoolean(KEY_CHOSEN, true)
      .apply()
  }

  fun isTv(): Boolean = getMode() == MODE_TV
}
