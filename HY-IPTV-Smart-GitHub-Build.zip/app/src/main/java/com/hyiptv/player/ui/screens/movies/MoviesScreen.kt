package com.hyiptv.player.ui.screens.movies

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as lazyColumnItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.hyiptv.player.R
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.ui.theme.*
import com.hyiptv.player.util.WatchProgressManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
@OptIn(ExperimentalFoundationApi::class)
fun MoviesScreen(
  onBack: () -> Unit,
  onPlay: (Channel) -> Unit = {}
) {
  val context = LocalContext.current
    var longPressFavMessage by remember { mutableStateOf<String?>(null) }
    val hapticFeedback = LocalHapticFeedback.current
    LaunchedEffect(longPressFavMessage) {
        if (longPressFavMessage != null) {
            kotlinx.coroutines.delay(2500)
            longPressFavMessage = null
        }
    }
  val repo = remember { ChannelRepository(context) }
  val progressManager = remember { WatchProgressManager(context) }
  val scope = rememberCoroutineScope()
  var progressByUrl by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
  val gridState = rememberLazyGridState()
  val lifecycleOwner = LocalLifecycleOwner.current

  var items by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var total by remember { mutableStateOf(0) }
  var query by remember { mutableStateOf("") }
  var page by remember { mutableStateOf(0) }
  var loading by remember { mutableStateOf(true) }
  var loadingMore by remember { mutableStateOf(false) }
  var end by remember { mutableStateOf(false) }
  var searchOpen by remember { mutableStateOf(false) }
  val sizePrefs = remember { context.getSharedPreferences("movie_display", Context.MODE_PRIVATE) }
  var posterSize by remember { mutableStateOf(sizePrefs.getString("size", "medium") ?: "medium") }
  
  // FIX 6: Favorites for movies
  var favorites by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var showOnlyFavorites by remember { mutableStateOf(false) }
  var selectedMovie by remember { mutableStateOf<Channel?>(null) }

  fun loadFirst() {
    scope.launch {
      loading = true
      end = false
      page = 0
      total = repo.getMovieCount()
      favorites = repo.getFavorites().filter { it.contentType == "movie" }
      val result = if (showOnlyFavorites) {
        favorites
      } else {
        repo.loadPage(query = query, page = 0, contentType = "movie")
      }
      items = result
      progressByUrl = result.associate { it.streamUrl to progressManager.getProgressPercent(it.streamUrl) }
      end = result.size < ChannelRepository.PAGE_SIZE || showOnlyFavorites
      loading = false
    }
  }

  fun toggleFavorite(channel: Channel) {
    scope.launch {
      repo.toggleFavorite(channel.id)
      favorites = repo.getFavorites().filter { it.contentType == "movie" }
      if (showOnlyFavorites) items = favorites
    }
  }

  fun loadMore() {
    if (loadingMore || end || showOnlyFavorites) return
    scope.launch {
      loadingMore = true
      val next = page + 1
      val more = repo.loadPage(query = query, page = next, contentType = "movie")
      if (more.isEmpty() || more.size < ChannelRepository.PAGE_SIZE) end = true
      if (more.isNotEmpty()) {
        items = items + more
        progressByUrl = progressByUrl + more.associate {
          it.streamUrl to progressManager.getProgressPercent(it.streamUrl)
        }
        page = next
      }
      loadingMore = false
    }
  }

  DisposableEffect(lifecycleOwner, items) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        progressByUrl = items.associate {
          it.streamUrl to progressManager.getProgressPercent(it.streamUrl)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  LaunchedEffect(query, showOnlyFavorites) { loadFirst() }
  LaunchedEffect(gridState) {
    snapshotFlow {
      val info = gridState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
      last >= info.totalItemsCount - 4
    }.collect { if (it) loadMore() }
  }

  Column(Modifier.fillMaxSize().background(BlackBackground)) {
    TopAppBar(
      title = {
        if (searchOpen) {
          OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.search), color = TextMuted) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = GoldPrimary,
              unfocusedBorderColor = DividerColor,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              cursorColor = GoldPrimary,
              focusedContainerColor = DarkSurface,
              unfocusedContainerColor = DarkSurface
            )
          )
        } else {
          Column {
            Text(stringResource(R.string.movies), color = GoldPrimary, fontWeight = FontWeight.Bold)
            if (total > 0) Text("$total", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
          }
        }
      },
      navigationIcon = {
        IconButton(onClick = {
          if (searchOpen) { searchOpen = false; query = "" } else onBack()
        }) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      actions = {
        if (!searchOpen) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
              posterSize = when (posterSize) { "small" -> "medium"; "medium" -> "large"; else -> "small" }
              sizePrefs.edit().putString("size", posterSize).apply()
            }) {
              Text(when (posterSize) { "small" -> "صغير"; "large" -> "كبير"; else -> "وسط" }, color = GoldPrimary)
            }
            IconButton(onClick = { searchOpen = true }) {
              Icon(Icons.Default.Search, null, tint = GoldPrimary)
            }
          }
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Row(Modifier.fillMaxSize()) {
      // شريط جانبي صغير للمفضلة على يسار الشاشة
      Card(
        onClick = { showOnlyFavorites = !showOnlyFavorites },
        modifier = Modifier.width(52.dp).fillMaxHeight().padding(start = 6.dp, top = 8.dp, bottom = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (showOnlyFavorites) Color(0xFF49351B) else CardBackground)
      ) {
        Column(
          Modifier.fillMaxSize().padding(vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Icon(
            if (showOnlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "المفضلة",
            tint = if (showOnlyFavorites) Color(0xFF4CAF50) else GoldPrimary,
            modifier = Modifier.size(22.dp)
          )
          Spacer(Modifier.height(12.dp))
          Text(
            "المفضلة",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.graphicsLayer(rotationZ = -90f),
            maxLines = 1
          )
          Spacer(Modifier.height(12.dp))
          Text("${favorites.size}", color = TextSecondary, fontSize = 10.sp)
        }
      }

      when {
        loading -> Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = GoldPrimary)
        }
        items.isEmpty() -> Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Movie, null, tint = GoldPrimary.copy(0.4f), modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.no_data), color = TextMuted)
            if (showOnlyFavorites) Text("لا توجد أفلام في المفضلة", color = TextMuted, style = MaterialTheme.typography.bodySmall)
          }
        }
        else -> LazyVerticalGrid(
          columns = GridCells.Fixed(when (posterSize) { "small" -> 5; "large" -> 2; else -> 3 }),
          state = gridState,
          contentPadding = PaddingValues(12.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          items(items, key = { it.id }) { movie ->
            var focused by remember(movie.id) { mutableStateOf(false) }
            val isFav = favorites.any { it.id == movie.id }
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = CardBackground),
              modifier = Modifier
                .onFocusChanged { focused = it.isFocused }
                .border(if (focused) 3.dp else 1.dp, if (focused) Color(0xFF39E600) else DividerColor, RoundedCornerShape(12.dp))
                .focusable()
            ) {
              Column(
                modifier = Modifier.combinedClickable(
                  onClick = { onPlay(movie) },
                  onLongClick = { toggleFavorite(movie) }
                )
              ) {
                Box(
                  Modifier.fillMaxWidth()
                    .aspectRatio(when (posterSize) { "small" -> 0.82f; "large" -> 0.62f; else -> 0.7f })
                    .background(DarkSurface),
                  contentAlignment = Alignment.Center
                ) {
                  if (!movie.logoUrl.isNullOrBlank()) {
                    AsyncImage(model = movie.logoUrl, contentDescription = movie.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                  } else {
                    Text("رَامِي", color = GoldPrimary, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(4.dp))
                  }
                  Card(
                    modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).clickable { toggleFavorite(movie) },
                    shape = RoundedCornerShape(7.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isFav) Color(0xFF4CAF50) else Color(0xDD111111))
                  ) {
                    Row(Modifier.padding(horizontal = 7.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                      Icon(if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (isFav) "In Favorite" else "Add to Favorite", tint = Color.White, modifier = Modifier.size(14.dp))
                      Text(if (isFav) "In Favorite" else "Add to Favorite", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                  val watchedPercent = progressByUrl[movie.streamUrl] ?: 0
                  if (watchedPercent > 0) {
                    Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(6.dp).background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp)).padding(5.dp).size(16.dp))
                  }
                  if (watchedPercent > 0) {
                    LinearProgressIndicator(progress = watchedPercent / 100f, modifier = Modifier.fillMaxWidth().height(4.dp).align(Alignment.BottomCenter), color = GoldPrimary, trackColor = Color.Black.copy(alpha = 0.45f))
                  }
                  if (watchedPercent >= 90) {
                    Icon(Icons.Default.CheckCircle, null, tint = SuccessGreen, modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(20.dp))
                  }
                }
                Text(movie.name, color = TextPrimary, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(8.dp))
              }
            }
          }
        }
      }
    }
    }
  }

  // DETAIL VIEW FOR MOVIE - English fav button inside (fixed inside function)
  if (selectedMovie != null) {
    val movie = selectedMovie!!
    val isFav = favorites.any { it.id == movie.id }
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(BlackBackground)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
          title = {
            Text(
              movie.name,
              color = GoldPrimary,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          },
          navigationIcon = {
            IconButton(onClick = { selectedMovie = null }) {
              Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                null,
                tint = GoldPrimary
              )
            }
          },
          actions = {
            Card(
              modifier = Modifier
                .padding(end = 8.dp)
                .clickable { toggleFavorite(movie) },
              colors = CardDefaults.cardColors(
                containerColor = if (isFav) Color(0xFF4CAF50) else GoldPrimary
              ),
              shape = RoundedCornerShape(8.dp),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                  contentDescription = "fav",
                  tint = if (isFav) Color.White else BlackBackground,
                  modifier = Modifier.size(18.dp)
                )
                Text(
                  text = if (isFav) "In Favorite ❤️" else "Add to Favorite 🤍",
                  color = if (isFav) Color.White else BlackBackground,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(containerColor = BlackBackground)
        )
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          AsyncImage(
            model = movie.logoUrl,
            contentDescription = null,
            modifier = Modifier
              .width(300.dp)
              .height(400.dp)
              .clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
          )
          Text(
            text = movie.name,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            textAlign = TextAlign.Center
          )
          Text(
            text = movie.group,
            color = TextSecondary,
            fontSize = 14.sp
          )
          Button(
            onClick = {
              onPlay(movie)
              selectedMovie = null
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(56.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = GoldPrimary,
              contentColor = BlackBackground
            ),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(
              text = "Play Movie",
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
          }
        }
      }
    }
  }

}