package com.hyiptv.player.ui.screens.stalker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hyiptv.player.data.model.StalkerProfile
import com.hyiptv.player.data.repository.StalkerRepository
import com.hyiptv.player.ui.theme.*
import com.hyiptv.player.util.DeviceIdManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StalkerPortalScreen(
  onBack: () -> Unit,
  onConnected: () -> Unit = {}
) {
  val context = LocalContext.current
  val repository = remember { StalkerRepository(context) }
  val deviceIdManager = remember { DeviceIdManager(context) }
  val scope = rememberCoroutineScope()

  var name by remember { mutableStateOf("") }
  var macAddress by remember { mutableStateOf("") }
  var portalUrl by remember { mutableStateOf("") }
  var isLoading by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }
  var showUserList by remember { mutableStateOf(false) }
  var profiles by remember { mutableStateOf<List<StalkerProfile>>(emptyList()) }
  var selectedProfileId by remember { mutableStateOf<String?>(null) }

  // Load device-based MAC suggestion + saved profiles
  LaunchedEffect(Unit) {
    val deviceId = deviceIdManager.getDeviceId()
    macAddress = repository.generateMac(deviceId)
    profiles = repository.getProfiles()
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text(
          text = "Stalker Portal Connectivity",
          color = GoldPrimary,
          fontWeight = FontWeight.Bold
        )
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = null,
            tint = GoldPrimary
          )
        }
      },
      actions = {
        IconButton(onClick = {
          showUserList = !showUserList
          scope.launch { profiles = repository.getProfiles() }
        }) {
          Icon(
            imageVector = Icons.Default.People,
            contentDescription = "List of User",
            tint = GoldPrimary
          )
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(
        containerColor = CharcoalSurface
      )
    )

    if (showUserList) {
      // List of saved users
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        Text(
          text = "List of User",
          style = MaterialTheme.typography.titleLarge,
          color = GoldPrimary,
          fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))

        if (profiles.isEmpty()) {
          Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
          ) {
            Text("No saved users yet", color = TextMuted)
          }
        } else {
          LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(profiles, key = { it.id }) { profile ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .border(1.dp, DividerColor, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                onClick = {
                  name = profile.name
                  macAddress = profile.macAddress
                  portalUrl = profile.portalUrl
                  selectedProfileId = profile.id
                  showUserList = false
                }
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(Modifier.weight(1f)) {
                    Text(
                      text = profile.name,
                      color = TextPrimary,
                      fontWeight = FontWeight.Medium
                    )
                    Text(
                      text = profile.macAddress,
                      color = TextSecondary,
                      style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                      text = profile.portalUrl,
                      color = TextMuted,
                      style = MaterialTheme.typography.bodySmall,
                      maxLines = 1
                    )
                  }
                  IconButton(onClick = {
                    scope.launch {
                      repository.deleteProfile(profile.id)
                      if (selectedProfileId == profile.id) selectedProfileId = null
                      profiles = repository.getProfiles()
                    }
                  }) {
                    Icon(
                      Icons.Default.Delete,
                      contentDescription = "Delete",
                      tint = ErrorRed
                    )
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Add / Connect form
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(Modifier.height(12.dp))

        Text(
          text = "Stalker Portal Connectivity",
          style = MaterialTheme.typography.headlineSmall,
          color = TextPrimary,
          fontWeight = FontWeight.SemiBold,
          textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(28.dp))

        // Name
        StalkerTextField(
          value = name,
          onValueChange = { name = it },
          label = "Name"
        )
        Spacer(Modifier.height(14.dp))

        // MAC Address + regenerate
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          StalkerTextField(
            value = macAddress,
            onValueChange = {
              macAddress = it.uppercase().replace('-', ':').filter { ch -> ch.isLetterOrDigit() || ch == ':' }.take(17)
            },
            label = "MAC Address",
            modifier = Modifier.weight(1f)
          )
          Spacer(Modifier.width(8.dp))
          IconButton(
            onClick = {
              scope.launch {
                val deviceId = deviceIdManager.getDeviceId()
                macAddress = repository.generateMac(deviceId + System.currentTimeMillis())
              }
            }
          ) {
            Icon(
              Icons.Default.Refresh,
              contentDescription = "Generate MAC",
              tint = GoldPrimary
            )
          }
        }
        Spacer(Modifier.height(14.dp))

        // Portal URL
        StalkerTextField(
          value = portalUrl,
          onValueChange = { portalUrl = it },
          label = "Portal URL"
        )

        Spacer(Modifier.height(12.dp))

        message?.let {
          Text(
            text = it,
            color = if (isError) ErrorRed else SuccessGreen,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
          )
          Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(16.dp))

        // ADD USER button
        Button(
          onClick = {
            val normalizedMac = macAddress.trim().uppercase().replace('-', ':')
            val validMac = Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(normalizedMac)
            if (portalUrl.isBlank() || !validMac) {
              message = if (portalUrl.isBlank()) "Please enter the Portal URL" else "MAC must use format 00:1A:79:XX:XX:XX"
              isError = true
              return@Button
            }
            isLoading = true
            message = null
            scope.launch {
              val existing = profiles.firstOrNull { it.id == selectedProfileId }
              val profile = if (existing != null) {
                existing.copy(
                  name = name.ifBlank { existing.name },
                  macAddress = normalizedMac,
                  portalUrl = portalUrl.trim()
                )
              } else {
                repository.createProfile(name, normalizedMac, portalUrl)
              }
              repository.saveProfile(profile)
              selectedProfileId = profile.id
              profiles = repository.getProfiles()

              val result = repository.connectAndLoad(profile)
              isLoading = false
              result.onSuccess { count ->
                message = "Connected! Loaded $count channels"
                isError = false
                onConnected()
              }.onFailure { e ->
                message = e.message ?: "Connection failed"
                isError = true
              }
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
          enabled = !isLoading,
          colors = ButtonDefaults.buttonColors(
            containerColor = GoldPrimary,
            contentColor = BlackBackground
          ),
          shape = RoundedCornerShape(28.dp)
        ) {
          if (isLoading) {
            CircularProgressIndicator(
              modifier = Modifier.size(22.dp),
              color = BlackBackground,
              strokeWidth = 2.dp
            )
          } else {
            Text(
              text = "ADD USER",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleMedium
            )
          }
        }

        Spacer(Modifier.height(16.dp))

        // List of User button
        OutlinedButton(
          onClick = {
            showUserList = true
            scope.launch { profiles = repository.getProfiles() }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
          shape = RoundedCornerShape(28.dp),
          colors = ButtonDefaults.outlinedButtonColors(
            contentColor = GoldPrimary
          ),
          border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = androidx.compose.ui.graphics.SolidColor(GoldPrimary)
          )
        ) {
          Icon(
            Icons.Default.People,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
          )
          Spacer(Modifier.width(8.dp))
          Text("List of User", fontWeight = FontWeight.Medium)
        }

        Spacer(Modifier.height(24.dp))

        Text(
          text = "Note: MAC is generated from Device ID (Android does not expose permanent hardware MAC freely). You can edit it if your provider requires a specific MAC.",
          style = MaterialTheme.typography.bodySmall,
          color = TextMuted,
          textAlign = TextAlign.Center
        )
      }
    }
  }
}

@Composable
private fun StalkerTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    modifier = modifier.fillMaxWidth(),
    label = { Text(label, color = TextSecondary) },
    singleLine = true,
    shape = RoundedCornerShape(28.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedBorderColor = GoldPrimary,
      unfocusedBorderColor = DividerColor,
      focusedTextColor = TextPrimary,
      unfocusedTextColor = TextPrimary,
      cursorColor = GoldPrimary,
      focusedContainerColor = DarkSurface,
      unfocusedContainerColor = DarkSurface,
      focusedLabelColor = GoldAccent,
      unfocusedLabelColor = TextMuted
    )
  )
}
