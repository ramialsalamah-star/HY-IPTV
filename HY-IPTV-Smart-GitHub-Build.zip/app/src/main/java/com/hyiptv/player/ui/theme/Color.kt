package com.hyiptv.player.ui.theme

import androidx.compose.ui.graphics.Color

// Final luxury Black & Gold palette
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF5D76E)
val GoldDark = Color(0xFFB8860B)
val GoldAccent = Color(0xFFE8C547)

val BlackBackground = Color(0xFF101010)
val CharcoalSurface = Color(0xFF1C1C1C)
val DarkSurface = Color(0xFF181818)
val CardBackground = Color(0xFF1C1C1C)
val ElevatedSurface = Color(0xFF252525)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B0B0)
val TextMuted = Color(0xFF757575)

val ErrorRed = Color(0xFFCF6679)
val SuccessGreen = Color(0xFF4CAF50)
val WarningOrange = Color(0xFFFF9800)

val FocusBorder = Color(0xFF4CAF50) // Green selection frame
val DividerColor = Color(0xFF2A2A2A)
