package com.hyiptv.player.data.repository

import android.content.Context
import android.os.Environment
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.hyiptv.player.data.local.AppDatabase
import com.hyiptv.player.data.local.ChannelEntity
import com.hyiptv.player.data.local.FavoriteEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Export / Import channels + favorites to JSON file.
 * Files are written to app external files dir AND attempted to Documents/HY_IPTV
 * so the user can copy them before uninstall and restore after reinstall.
 */
class BackupRepository(private val context: Context) {

  private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
  private val db = AppDatabase.getInstance(context)

  data class BackupData(
    val version: Int = 1,
    val exportedAt: String = "",
    val channels: List<ChannelEntity> = emptyList(),
    val favoriteIds: List<String> = emptyList()
  )

  private fun backupDir(): File {
    // Prefer public Documents so user can access via file manager
    val publicDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    val hyDir = File(publicDocs, "HY_IPTV")
    if (!hyDir.exists()) {
      hyDir.mkdirs()
    }
    // Fallback to app external files
    if (!hyDir.canWrite()) {
      val appExt = context.getExternalFilesDir(null) ?: context.filesDir
      val fallback = File(appExt, "backups")
      if (!fallback.exists()) fallback.mkdirs()
      return fallback
    }
    return hyDir
  }

  suspend fun exportToFile(): Result<File> = withContext(Dispatchers.IO) {
    try {
      val dao = db.channelDao()
      // Load all channels in batches to avoid OOM
      val allChannels = mutableListOf<ChannelEntity>()
      var offset = 0
      val pageSize = 2000
      while (true) {
        val page = dao.getChannelsPaged(pageSize, offset)
        if (page.isEmpty()) break
        allChannels.addAll(page)
        offset += pageSize
        if (page.size < pageSize) break
      }
      val favoriteIds = dao.getFavoriteIds()

      val backup = BackupData(
        version = 1,
        exportedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
        channels = allChannels,
        favoriteIds = favoriteIds
      )

      val fileName = "HY_IPTV_backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.json"
      val file = File(backupDir(), fileName)
      file.writeText(gson.toJson(backup), Charsets.UTF_8)
      Result.success(file)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun importFromFile(file: File): Result<Int> = withContext(Dispatchers.IO) {
    try {
      if (!file.exists()) return@withContext Result.failure(Exception("File not found"))
      val json = file.readText(Charsets.UTF_8)
      val backup = gson.fromJson(json, BackupData::class.java)
        ?: return@withContext Result.failure(Exception("Invalid backup file"))

      val dao = db.channelDao()
      // Clear current and insert in batches
      dao.clearAllChannels()

      val batchSize = 1500
      val restoredFavorites = mutableListOf<String>()
      val uniqueBackupChannels = backup.channels
        .filter { it.streamUrl.isNotBlank() }
        .groupBy { it.streamUrl.trim() }
        .values
        .map { duplicates ->
          val first = duplicates.first()
          first.copy(isFavorite = duplicates.any { it.isFavorite || backup.favoriteIds.contains(it.id) })
        }
      uniqueBackupChannels.chunked(batchSize).forEach { batch ->
        val withFav = batch.map { ch ->
          ch.copy(isFavorite = ch.isFavorite || backup.favoriteIds.contains(ch.id))
        }
        restoredFavorites += withFav.filter { it.isFavorite }.map { it.id }
        dao.insertChannels(withFav)
      }
      dao.clearFavorites()
      (restoredFavorites + backup.favoriteIds).distinct().forEach { id ->
        dao.insertFavorite(FavoriteEntity(channelId = id))
      }

      Result.success(uniqueBackupChannels.size)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun listBackupFiles(): List<File> = withContext(Dispatchers.IO) {
    val dir = backupDir()
    dir.listFiles { f -> f.isFile && f.name.endsWith(".json", ignoreCase = true) }
      ?.sortedByDescending { it.lastModified() }
      ?: emptyList()
  }

  fun getBackupFolderPath(): String = backupDir().absolutePath
}
