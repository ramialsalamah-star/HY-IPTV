package com.hyiptv.player.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val PremiumDarkColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = BlackBackground,
  primaryContainer = GoldDark,
  onPrimaryContainer = TextPrimary,
  secondary = GoldAccent,
  onSecondary = BlackBackground,
  secondaryContainer = DarkSurface,
  onSecondaryContainer = TextPrimary,
  tertiary = GoldLight,
  background = BlackBackground,
  onBackground = TextPrimary,
  surface = CharcoalSurface,
  onSurface = TextPrimary,
  surfaceVariant = CardBackground,
  onSurfaceVariant = TextSecondary,
  error = ErrorRed,
  onError = TextPrimary,
  outline = DividerColor,
  outlineVariant = DividerColor
)

@Composable
fun HYIPTVTheme(
  darkTheme: Boolean = true, // Always dark for premium look
  content: @Composable () -> Unit
) {
  val colorScheme = PremiumDarkColorScheme
  val view = LocalView.current

  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as Activity).window
      window.statusBarColor = BlackBackground.toArgb()
      window.navigationBarColor = BlackBackground.toArgb()
      WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
      WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
