package com.hyiptv.player.ui.screens.connections

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hyiptv.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionsScreen(
  onBack: () -> Unit,
  onNavigateToXtream: () -> Unit,
  onNavigateToM3u: () -> Unit,
  onNavigateToStalker: () -> Unit
) {
  Column(
    Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text("الاتصالات", color = GoldPrimary, fontWeight = FontWeight.Bold)
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    Column(
      Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Text(
        "اختر نوع الاتصال",
        color = TextSecondary,
        style = MaterialTheme.typography.bodyMedium
      )

      ConnectionCard(
        title = "Xtream Codes API",
        subtitle = "Server URL + Username + Password",
        icon = Icons.Default.Cloud,
        onClick = onNavigateToXtream
      )
      ConnectionCard(
        title = "M3U / M3U8 URL",
        subtitle = "تحميل قائمة من رابط مباشر",
        icon = Icons.Default.Link,
        onClick = onNavigateToM3u
      )
      ConnectionCard(
        title = "استيراد ملف M3U / M3U8",
        subtitle = "من الجهاز أو USB أو OTG",
        icon = Icons.Default.FolderOpen,
        onClick = onNavigateToM3u
      )
      ConnectionCard(
        title = "MAC Address / MAG Portal",
        subtitle = "بوابة Stalker مع عنوان MAC",
        icon = Icons.Default.Dns,
        onClick = onNavigateToStalker
      )
    }
  }
}

@Composable
private fun ConnectionCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  onClick: () -> Unit
) {
  var focused by remember { mutableStateOf(false) }
  Card(
    onClick = onClick,
    modifier = Modifier
      .fillMaxWidth()
      .onFocusChanged { focused = it.isFocused }
      .border(
        width = if (focused) 3.dp else 1.dp,
        color = if (focused) SuccessGreen else GoldPrimary.copy(alpha = 0.45f),
        shape = RoundedCornerShape(16.dp)
      ),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CardBackground)
  ) {
    Row(
      Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(icon, null, tint = GoldPrimary, modifier = Modifier.size(36.dp))
      Spacer(Modifier.width(14.dp))
      Column(Modifier.weight(1f)) {
        Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text(subtitle, color = TextMuted, style = MaterialTheme.typography.bodySmall)
      }
    }
  }
}
