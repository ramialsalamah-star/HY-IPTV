package com.hyiptv.player.data.repository

import android.content.Context
import com.hyiptv.player.data.local.AppDatabase
import com.hyiptv.player.data.local.ChannelEntity
import com.hyiptv.player.data.local.RecentEntity
import com.hyiptv.player.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ChannelRepository(context: Context) {

  private val dao = AppDatabase.getInstance(context).channelDao()
  private var favoriteSnapshot: List<ChannelEntity>? = null
  private var recentSnapshot: List<RecentSnap>? = null

  private data class RecentSnap(val streamUrl: String, val watchedAt: Long, val positionMs: Long)

  companion object {
    const val PAGE_SIZE = 100

    fun classifyContentType(group: String, name: String = ""): String {
      val g = (group + " " + name).lowercase()
      val seriesKeys = listOf(
        "series", "serial", "show", "مسلسل", "مسلسلات", "serie", "tv show", "seasons"
      )
      val movieKeys = listOf(
        "movie", "movies", "vod", "film", "cinema", "أفلام", "افلام", "فيلم", "on demand"
      )
      when {
        seriesKeys.any { g.contains(it) } -> return "series"
        movieKeys.any { g.contains(it) } -> return "movie"
        else -> return "live"
      }
    }
  }

  suspend fun getChannelCount(): Int = withContext(Dispatchers.IO) { dao.getChannelCount() }
  suspend fun getMovieCount(): Int = withContext(Dispatchers.IO) { dao.getCountByType("movie") }
  suspend fun getSeriesCount(): Int = withContext(Dispatchers.IO) { dao.getCountByType("series") }

  suspend fun getGroups(contentType: String = "live"): List<String> = withContext(Dispatchers.IO) {
    listOf("All") + if (contentType == "live") dao.getLiveGroups() else dao.getGroupsByType(contentType)
  }

  data class GroupInfo(val name: String, val count: Int)

  suspend fun getGroupInfos(contentType: String = "live"): List<GroupInfo> = withContext(Dispatchers.IO) {
    val total = dao.getCountByType(contentType)
    val groups = dao.getGroupCounts(contentType).map { GroupInfo(it.name, it.count) }
    buildList {
      add(GroupInfo("ALL", total))
      add(GroupInfo("المفضلة", dao.getFavorites().size))
      addAll(groups)
    }
  }

  suspend fun loadPage(
    group: String = "All",
    query: String = "",
    page: Int = 0,
    contentType: String = "live"
  ): List<Channel> = withContext(Dispatchers.IO) {
    val offset = page * PAGE_SIZE
    val entities = when {
      query.isNotBlank() && contentType == "live" -> dao.searchLive(query, PAGE_SIZE, offset)
      query.isNotBlank() -> dao.searchByType(contentType, query, PAGE_SIZE, offset)
      contentType != "live" -> dao.getByTypePaged(contentType, PAGE_SIZE, offset)
      group == "All" -> dao.getLivePaged(PAGE_SIZE, offset)
      else -> dao.getLiveByGroupPaged(group, PAGE_SIZE, offset)
    }
    entities.map { it.toChannel() }
  }

  fun favoritesFlow(): Flow<List<Channel>> =
    dao.getFavoritesFlow().map { list -> list.map { it.toChannel() } }

  suspend fun getFavorites(): List<Channel> = withContext(Dispatchers.IO) {
    dao.getFavorites().map { it.toChannel() }
  }

  suspend fun searchAll(query: String, page: Int = 0): List<Channel> = withContext(Dispatchers.IO) {
    if (query.isBlank()) return@withContext emptyList()
    dao.searchAll(query.trim(), PAGE_SIZE, page * PAGE_SIZE).map { it.toChannel() }
  }

  suspend fun countSearch(query: String): Int = withContext(Dispatchers.IO) {
    if (query.isBlank()) 0 else dao.countSearch(query.trim())
  }

  suspend fun toggleFavorite(channelId: String): Boolean = withContext(Dispatchers.IO) {
    val channel = dao.getChannelById(channelId) ?: return@withContext false
    val newValue = !channel.isFavorite
    dao.setFavorite(channelId, newValue)
    if (newValue) dao.insertFavorite(com.hyiptv.player.data.local.FavoriteEntity(channelId))
    else dao.removeFavorite(channelId)
    newValue
  }

  suspend fun markWatched(channelId: String) = withContext(Dispatchers.IO) {
    val channel = dao.getChannelById(channelId) ?: return@withContext
    val now = System.currentTimeMillis()
    dao.updateLastWatched(channel.id, now)
    dao.insertRecent(RecentEntity(channelId = channel.id, watchedAt = now))
  }

  suspend fun markWatchedByUrl(streamUrl: String) = withContext(Dispatchers.IO) {
    val channel = dao.getByStreamUrl(streamUrl) ?: return@withContext
    markWatched(channel.id)
  }

  suspend fun getLastWatchedChannel(): Channel? = withContext(Dispatchers.IO) {
    val recent = dao.getRecent(1).firstOrNull() ?: return@withContext null
    dao.getChannelById(recent.channelId)?.let {
      Channel(
        id = it.id,
        name = it.name,
        streamUrl = it.streamUrl,
        logoUrl = it.logoUrl,
        group = it.groupName,
        epgId = it.epgId,
        isFavorite = it.isFavorite,
        contentType = it.contentType
      )
    }
  }

  suspend fun replaceChannels(channels: List<Channel>, sourceType: String = "m3u"): Int =
    withContext(Dispatchers.IO) {
      if (favoriteSnapshot == null) {
        snapshotUserState { it == sourceType }
      }
      dao.clearBySource(sourceType)
      val favIds = favoriteSnapshot.orEmpty().map { it.id }.toSet()
      val favUrls = favoriteSnapshot.orEmpty().map { it.streamUrl }.toSet()
      // Group by the exact trimmed stream URL (paths may be case-sensitive).
      // Keep the first provider entry, but never lose a favorite flag from a duplicate.
      val uniqueChannels = channels
        .filter { it.streamUrl.isNotBlank() }
        .groupBy { it.streamUrl.trim() }
        .values
        .map { duplicates ->
          val first = duplicates.first()
          first.copy(isFavorite = duplicates.any { it.isFavorite })
        }
      val entities = uniqueChannels.map { ch ->
        val type = ch.contentType.ifBlank {
          classifyContentType(ch.group, ch.name)
        }
        ch.copy(
          contentType = type,
          isFavorite = ch.isFavorite || ch.id in favIds || ch.streamUrl in favUrls
        ).toEntity(sourceType)
      }
      entities.chunked(1500).forEach { dao.insertChannels(it) }
      favoriteSnapshot.orEmpty().forEach { dao.removeFavorite(it.id) }
      entities.filter { it.isFavorite }.forEach { entity ->
        dao.insertFavorite(com.hyiptv.player.data.local.FavoriteEntity(entity.id))
      }
      recentSnapshot.orEmpty().forEach { snap ->
        val restored = dao.getByStreamUrl(snap.streamUrl) ?: return@forEach
        dao.insertRecent(
          RecentEntity(
            channelId = restored.id,
            watchedAt = snap.watchedAt,
            positionMs = snap.positionMs
          )
        )
      }
      favoriteSnapshot = null
      recentSnapshot = null
      entities.size
    }

  suspend fun clearAll() = withContext(Dispatchers.IO) {
    dao.clearAllChannels()
    dao.clearFavorites()
    dao.clearRecent()
  }

  suspend fun removeSource(sourceType: String) = withContext(Dispatchers.IO) {
    dao.clearBySource(sourceType)
  }

  suspend fun clearPlaylistSources() = withContext(Dispatchers.IO) {
    snapshotUserState { source ->
      source.startsWith("playlist_") || source == "m3u" || source == "xtream"
    }
    dao.clearPlaylistSources()
  }

  private suspend fun snapshotUserState(sourcePredicate: (String) -> Boolean) {
    if (favoriteSnapshot == null) {
      favoriteSnapshot = dao.getFavorites().filter { sourcePredicate(it.sourceType) }
    }
    if (recentSnapshot == null) {
      recentSnapshot = dao.getRecent(50).mapNotNull { recent ->
        val channel = dao.getChannelById(recent.channelId) ?: return@mapNotNull null
        if (!sourcePredicate(channel.sourceType)) return@mapNotNull null
        RecentSnap(channel.streamUrl, recent.watchedAt, recent.positionMs)
      }
    }
  }

  private fun ChannelEntity.toChannel() = Channel(
    id = id,
    name = name,
    streamUrl = streamUrl,
    logoUrl = logoUrl,
    group = groupName,
    epgId = epgId,
    isFavorite = isFavorite,
    contentType = contentType
  )

  private fun Channel.toEntity(sourceType: String) = ChannelEntity(
    id = id,
    name = name,
    streamUrl = streamUrl,
    logoUrl = logoUrl,
    groupName = group,
    epgId = epgId,
    isFavorite = isFavorite,
    sourceType = sourceType,
    contentType = contentType.ifBlank { classifyContentType(group, name) }
  )
}
