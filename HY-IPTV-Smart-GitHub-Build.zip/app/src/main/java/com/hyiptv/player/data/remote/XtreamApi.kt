package com.hyiptv.player.data.remote

import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.model.Movie
import com.hyiptv.player.data.model.Series
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

class XtreamApi {

  private val client = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .build()

  data class XtreamConfig(
    val serverUrl: String,
    val username: String,
    val password: String
  ) {
    fun base(): String {
      var u = serverUrl.trim()
        .removeSuffix("/player_api.php")
        .removeSuffix("/get.php")
        .trimEnd('/')
      if (!u.startsWith("http://", ignoreCase = true) && !u.startsWith("https://", ignoreCase = true)) {
        u = "http://$u"
      }
      return u
    }

    private fun encode(value: String): String =
      URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")

    fun api(action: String, extra: String = ""): String {
      return "${base()}/player_api.php?username=${encode(username)}&password=${encode(password)}&action=${encode(action)}$extra"
    }

    fun liveStreamUrl(streamId: String, ext: String = "ts"): String {
      val safeExt = ext.ifBlank { "ts" }.removePrefix(".")
      return "${base()}/live/${encode(username)}/${encode(password)}/${encode(streamId)}.$safeExt"
    }

    fun movieStreamUrl(streamId: String, ext: String = "mp4"): String {
      return "${base()}/movie/${encode(username)}/${encode(password)}/${encode(streamId)}.$ext"
    }

    fun seriesStreamUrl(streamId: String, ext: String = "mp4"): String {
      return "${base()}/series/${encode(username)}/${encode(password)}/${encode(streamId)}.$ext"
    }
  }

  suspend fun testConnection(config: XtreamConfig): Result<JSONObject> = withContext(Dispatchers.IO) {
    try {
      val url = "${config.base()}/player_api.php?username=${URLEncoder.encode(config.username, StandardCharsets.UTF_8.name())}&password=${URLEncoder.encode(config.password, StandardCharsets.UTF_8.name())}"
      val body = get(url) ?: return@withContext Result.failure(Exception("Empty response"))
      val json = JSONObject(body)
      if (json.has("user_info")) {
        Result.success(json)
      } else {
        Result.failure(Exception("Invalid credentials or server"))
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun getLiveStreams(config: XtreamConfig): Result<List<Channel>> = withContext(Dispatchers.IO) {
    try {
      val categories = loadCategories(config, "get_live_categories")
      val body = get(config.api("get_live_streams"))
        ?: return@withContext Result.failure(Exception("Failed to load live streams"))
      val arr = responseArray(
        body, "data", "results", "available_channels", "live_streams",
        "channels", "streams", "items", "result"
      )
        ?: return@withContext Result.failure(Exception("Live: unsupported format"))
      val list = mutableListOf<Channel>()
      for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawId = o.optString("stream_id").ifBlank {
          o.optString("channel_id").ifBlank { o.optString("id") }
        }
        if (rawId.isBlank() || rawId == "null") continue
        val ext = o.optString("container_extension").ifBlank {
          val kind = o.optString("stream_type")
          if (kind.contains("hls", true) || kind.contains("m3u8", true)) "m3u8" else "ts"
        }
        val direct = o.optString("direct_source").ifBlank { o.optString("stream_url", "") }
        val streamUrl = if (direct.startsWith("http://", true) || direct.startsWith("https://", true)) {
          direct
        } else config.liveStreamUrl(rawId, ext)
        val id = "live_$rawId"
        val name = o.optString("name").ifBlank { o.optString("title").ifBlank { "Channel $rawId" } }
        val logo = o.optString("stream_icon", null)
        val catId = o.optString("category_id", "")
        val group = categories[catId] ?: "Live"
        val epg = o.optString("epg_channel_id", null)
        list.add(
          Channel(
            id = id,
            name = name,
            streamUrl = streamUrl,
            logoUrl = logo?.ifBlank { null },
            group = group,
            epgId = epg?.ifBlank { null }
          )
        )
      }
      Result.success(list)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun getVodStreams(config: XtreamConfig): Result<List<Movie>> = withContext(Dispatchers.IO) {
    try {
      val categories = loadCategories(config, "get_vod_categories")
      val body = get(config.api("get_vod_streams"))
        ?: return@withContext Result.failure(Exception("Failed to load VOD"))
      val arr = responseArray(body, "data", "results", "movies", "vod", "items", "result")
        ?: return@withContext Result.failure(Exception("VOD: unsupported format"))
      val list = mutableListOf<Movie>()
      for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawId = o.optString("stream_id").ifBlank { o.optString("id") }
        if (rawId.isBlank()) continue
        val name = o.optString("name").ifBlank { o.optString("title").ifBlank { "Movie $rawId" } }
        val logo = o.optString("stream_icon", null)
        val catId = o.optString("category_id", "")
        val group = categories[catId] ?: "Movies"
        val ext = o.optString("container_extension", "mp4")
        val streamUrl = config.movieStreamUrl(rawId, ext)
        list.add(Movie(id = "vod_$rawId", name = name, streamUrl = streamUrl, logoUrl = logo, group = group))
      }
      Result.success(list)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun getSeries(config: XtreamConfig): Result<List<Series>> = withContext(Dispatchers.IO) {
    try {
      val categories = loadCategories(config, "get_series_categories")
      val body = get(config.api("get_series"))
        ?: return@withContext Result.failure(Exception("Failed to load series"))
      val arr = responseArray(body, "data", "results", "series", "items", "result")
        ?: return@withContext Result.failure(Exception("Series: unsupported format"))
      val list = mutableListOf<Series>()
      for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawId = o.optString("series_id").ifBlank { o.optString("id") }
        if (rawId.isBlank()) continue
        val name = o.optString("name").ifBlank { o.optString("title").ifBlank { "Series $rawId" } }
        val logo = o.optString("cover", null)
        val catId = o.optString("category_id", "")
        val group = categories[catId] ?: "Series"
        list.add(Series(id = "series_$rawId", name = name, logoUrl = logo, group = group))
      }
      Result.success(list)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private suspend fun loadCategories(config: XtreamConfig, action: String): Map<String, String> = withContext(Dispatchers.IO) {
    try {
      val body = get(config.api(action)) ?: return@withContext emptyMap()
      val arr = responseArray(body, "data", "results", "categories", "items", "result") ?: return@withContext emptyMap()
      val map = mutableMapOf<String, String>()
      for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val id = o.optString("category_id").ifBlank { o.optString("id") }
        if (id.isBlank()) continue
        map[id] = o.optString("category_name").ifBlank { o.optString("name", "Other") }
      }
      map
    } catch (_: Exception) {
      emptyMap()
    }
  }

  private fun responseArray(body: String, vararg keys: String): JSONArray? {
    val wrapperKeys = (keys.toList() + listOf(
      "js", "data", "result", "results", "response", "payload",
      "live_streams", "channels", "streams", "items", "categories",
      "movies", "vod", "series"
    )).distinct()

    fun findArray(value: Any?, depth: Int): JSONArray? {
      if (depth > 6) return null
      when (value) {
        is JSONArray -> return value
        is JSONObject -> {
          // Prefer known API wrapper keys so unrelated metadata arrays are ignored.
          for (key in wrapperKeys) {
            if (value.has(key)) {
              val found = findArray(value.opt(key), depth + 1)
              if (found != null) return found
            }
          }
          // Some providers add one or more unnamed wrapper objects.
          val iterator = value.keys()
          while (iterator.hasNext()) {
            val found = findArray(value.opt(iterator.next()), depth + 1)
            if (found != null) return found
          }
        }
      }
      return null
    }

    return try {
      val trimmed = body.trim().removePrefix("\uFEFF")
      if (trimmed.isEmpty()) null else findArray(
        if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed),
        0
      )
    } catch (_: Exception) {
      null
    }
  }


  suspend fun getSeriesEpisodes(
    config: XtreamConfig,
    seriesId: String
  ): Result<List<com.hyiptv.player.data.model.Episode>> = withContext(Dispatchers.IO) {
    try {
      val encodedId = URLEncoder.encode(seriesId, StandardCharsets.UTF_8.name())
      val body = get("${config.base()}/player_api.php?username=${URLEncoder.encode(config.username, StandardCharsets.UTF_8.name())}&password=${URLEncoder.encode(config.password, StandardCharsets.UTF_8.name())}&action=get_series_info&series_id=$encodedId")
        ?: return@withContext Result.failure(Exception("Failed to load series episodes"))
      val root = JSONObject(body)
      val episodesObject = root.optJSONObject("episodes")
        ?: return@withContext Result.failure(Exception("Series episodes: unsupported format"))
      val episodes = mutableListOf<com.hyiptv.player.data.model.Episode>()
      val seasonKeys = episodesObject.keys()
      while (seasonKeys.hasNext()) {
        val seasonKey = seasonKeys.next()
        val seasonArray = episodesObject.optJSONArray(seasonKey) ?: continue
        for (i in 0 until seasonArray.length()) {
          val item = seasonArray.optJSONObject(i) ?: continue
          val id = item.optString("id").ifBlank { item.optString("episode_id") }
          if (id.isBlank() || id == "null") continue
          val episodeNumber = item.optInt("episode_num", i + 1)
          val seasonNumber = item.optInt("season", seasonKey.toIntOrNull() ?: 0)
          val extension = item.optString("container_extension").ifBlank { "mp4" }
          val direct = item.optString("direct_source")
          val streamUrl = if (direct.startsWith("http://", true) || direct.startsWith("https://", true)) {
            direct
          } else {
            "${config.base()}/series/${URLEncoder.encode(config.username, StandardCharsets.UTF_8.name())}/${URLEncoder.encode(config.password, StandardCharsets.UTF_8.name())}/${URLEncoder.encode(id, StandardCharsets.UTF_8.name())}.$extension"
          }
          val info = item.optJSONObject("info")
          episodes.add(
            com.hyiptv.player.data.model.Episode(
              id = id,
              name = item.optString("title").ifBlank { "Episode $episodeNumber" },
              streamUrl = streamUrl,
              episodeNumber = episodeNumber,
              seasonNumber = seasonNumber,
              plot = info?.optString("plot")?.takeIf { !it.isNullOrBlank() }
            )
          )
        }
      }
      Result.success(episodes.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber })))
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun get(url: String): String? {
    val request = Request.Builder()
      .url(url)
      .header("User-Agent", "HY-IPTV-Player/1.0")
      .get()
      .build()
    return try {
      client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) null else response.body?.string()
      }
    } catch (_: Exception) {
      null
    }
  }
}
