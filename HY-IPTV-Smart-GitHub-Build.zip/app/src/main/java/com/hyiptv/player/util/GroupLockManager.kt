package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Secret PIN lock for selected channel groups.
 * Default PIN is empty until user sets one.
 */
class GroupLockManager(context: Context) {
  private val unlockedForSession = mutableSetOf<String>()
  private val prefs: SharedPreferences =
    context.getSharedPreferences("hy_group_locks", Context.MODE_PRIVATE)

  companion object {
    private const val KEY_PIN = "pin"
    private const val KEY_LOCKED = "locked_groups"
    private const val KEY_LOCKED_CHANNELS = "locked_channels"
    private const val KEY_PIN_SET = "pin_set"
  }

  fun hasPin(): Boolean = prefs.getBoolean(KEY_PIN_SET, false)

  fun setPin(pin: String) {
    require(pin.length >= 4 && pin.length <= 8 && pin.all(Char::isDigit)) {
      "PIN must contain 4 to 8 digits"
    }
    prefs.edit()
      .putString(KEY_PIN, pin)
      .putBoolean(KEY_PIN_SET, true)
      .apply()
  }

  /** Never treats an unset PIN as a successful authentication. */
  fun checkPin(pin: String): Boolean {
    if (!hasPin() || pin.isEmpty()) return false
    return prefs.getString(KEY_PIN, null) == pin
  }

  fun getLockedGroups(): Set<String> {
    return prefs.getStringSet(KEY_LOCKED, emptySet())?.toSet() ?: emptySet()
  }

  fun isGroupLocked(groupName: String): Boolean {
    return getLockedGroups().contains(groupName) && !isUnlockedForSession(groupName)
  }

  /** Unlocks a group until this manager instance/session is cleared. */
  @Synchronized
  fun unlockForSession(groupName: String) {
    if (groupName.isNotBlank()) unlockedForSession.add(groupName)
  }

  @Synchronized
  fun isUnlockedForSession(groupName: String): Boolean =
    unlockedForSession.contains(groupName)

  @Synchronized
  fun clearSession() {
    unlockedForSession.clear()
  }

  @Synchronized
  fun lockGroup(groupName: String) {
    unlockedForSession.remove(groupName)
    val set = getLockedGroups().toMutableSet()
    set.add(groupName)
    prefs.edit().putStringSet(KEY_LOCKED, set).apply()
  }

  @Synchronized
  fun unlockGroup(groupName: String) {
    unlockedForSession.remove(groupName)
    val set = getLockedGroups().toMutableSet()
    set.remove(groupName)
    prefs.edit().putStringSet(KEY_LOCKED, set).apply()
  }

  fun toggleGroup(groupName: String) {
    // Toggle persisted state, not session-visible state.
    if (getLockedGroups().contains(groupName)) unlockGroup(groupName) else lockGroup(groupName)
  }

  fun getLockedChannels(): Set<String> =
    prefs.getStringSet(KEY_LOCKED_CHANNELS, emptySet())?.toSet() ?: emptySet()

  fun isChannelLocked(channelId: String): Boolean =
    getLockedChannels().contains(channelId)

  @Synchronized
  fun lockChannel(channelId: String) {
    if (channelId.isBlank()) return
    val set = getLockedChannels().toMutableSet()
    set.add(channelId)
    prefs.edit().putStringSet(KEY_LOCKED_CHANNELS, set).apply()
  }

  @Synchronized
  fun unlockChannel(channelId: String) {
    val set = getLockedChannels().toMutableSet()
    set.remove(channelId)
    prefs.edit().putStringSet(KEY_LOCKED_CHANNELS, set).apply()
  }
}
