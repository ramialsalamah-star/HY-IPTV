
package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Requirement: Save last viewed group and channel so when user exits and returns,
 * it stays on the group/channel he chose, not MBC default
 */
class LiveTvStateManager(context: Context) {
  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("live_tv_state", Context.MODE_PRIVATE)

  companion object {
    private const val KEY_LAST_GROUP = "last_group"
    private const val KEY_LAST_CHANNEL_ID = "last_channel_id"
    private const val KEY_LAST_CHANNEL_NAME = "last_channel_name"
    private const val KEY_LAST_CHANNEL_URL = "last_channel_url"
    private const val KEY_SCROLL_INDEX = "scroll_index"
  }

  fun saveGroup(groupName: String) {
    if (groupName.isNotBlank() && groupName != "ALL" && groupName != "المفضلة") {
      prefs.edit().putString(KEY_LAST_GROUP, groupName).apply()
    }
  }

  fun getLastGroup(): String? {
    return prefs.getString(KEY_LAST_GROUP, null)?.takeIf { it.isNotBlank() }
  }

  fun saveChannel(channelId: String, channelName: String, streamUrl: String, group: String) {
    if (channelId.isBlank()) return
    prefs.edit()
      .putString(KEY_LAST_CHANNEL_ID, channelId)
      .putString(KEY_LAST_CHANNEL_NAME, channelName)
      .putString(KEY_LAST_CHANNEL_URL, streamUrl)
      .putString(KEY_LAST_GROUP, group)
      .apply()
  }

  fun getLastChannelId(): String? = prefs.getString(KEY_LAST_CHANNEL_ID, null)
  fun getLastChannelInfo(): Triple<String, String, String>? {
    val id = prefs.getString(KEY_LAST_CHANNEL_ID, null) ?: return null
    val name = prefs.getString(KEY_LAST_CHANNEL_NAME, id) ?: id
    val url = prefs.getString(KEY_LAST_CHANNEL_URL, "") ?: ""
    return Triple(id, name, url)
  }

  fun saveScrollIndex(index: Int) {
    prefs.edit().putInt(KEY_SCROLL_INDEX, index).apply()
  }

  fun getScrollIndex(): Int = prefs.getInt(KEY_SCROLL_INDEX, 0)

  fun clear() {
    prefs.edit().clear().apply()
  }
}
