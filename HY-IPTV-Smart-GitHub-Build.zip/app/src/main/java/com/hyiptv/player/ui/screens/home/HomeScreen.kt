package com.hyiptv.player.ui.screens.home

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.hyiptv.player.R
import com.hyiptv.player.data.repository.ChannelRepository
import androidx.compose.ui.focus.FocusDirection

private val LuxuryBlack = Color(0xFF101010)
private val DarkPanel = Color(0xFF1C1C1C)
private val Gold = Color(0xFFD4AF37)
private val FocusGreen = Color(0xFF39E600)
private val Muted = Color(0xFFAAAAAA)

@Composable
fun HomeScreen(
  onNavigateToLive: () -> Unit,
  onNavigateToMovies: () -> Unit,
  onNavigateToSeries: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onNavigateToPlaylist: () -> Unit = {},
  onNavigateToStalker: () -> Unit = {},
  onNavigateToXtream: () -> Unit = {},
  onNavigateToFavorites: () -> Unit = {},
  onNavigateToSearch: () -> Unit = {},
  onNavigateToHistory: () -> Unit = {}
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val channelRepo = remember { ChannelRepository(context) }
  val isWide = LocalConfiguration.current.screenWidthDp >= 600
  var liveCount by remember { mutableIntStateOf(0) }
  var movieCount by remember { mutableIntStateOf(0) }
  var seriesCount by remember { mutableIntStateOf(0) }
  var showExitDialog by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    val total = channelRepo.getChannelCount()
    movieCount = channelRepo.getMovieCount()
    seriesCount = channelRepo.getSeriesCount()
    liveCount = (total - movieCount - seriesCount).coerceAtLeast(0)
  }

  BackHandler { showExitDialog = true }

  // FocusRequesters for TV remote navigation
  val firstCardFocus = remember { FocusRequester() }
  val settingsFocus = remember { FocusRequester() }
  
  Box(
    Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          listOf(Color(0xFF0A0A0A), LuxuryBlack, Color(0xFF050505))
        )
      )
      .padding(12.dp) // TV overscan safe padding
  ) {
    // Subtle gold ambient light
    Box(
      Modifier
        .align(Alignment.TopCenter)
        .size(if (isWide) 420.dp else 220.dp)
        .background(Brush.radialGradient(listOf(Gold.copy(alpha = 0.18f), Color.Transparent)))
    )

    Column(
      Modifier.fillMaxSize(),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // FIX 1: Header visible with safe top padding and background
      Spacer(Modifier.height(if (isWide) 12.dp else 8.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
          .padding(vertical = 8.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "رَامِي السَّلَامَة أَبُو يَعْرَب",
            color = Gold,
            fontSize = if (isWide) 34.sp else 26.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            textAlign = TextAlign.Center
          )
          Spacer(Modifier.height(6.dp))
          Box(
            Modifier
              .width(if (isWide) 280.dp else 180.dp)
              .height(2.dp)
              .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent)))
          )
          Spacer(Modifier.height(6.dp))
          Text(
            text = "عالم الترفيه بين يديك",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = if (isWide) 18.sp else 15.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      Spacer(Modifier.height(16.dp))

      // FIX 1 & 2: Cards with proper focus and not covering header
      BoxWithConstraints(
        Modifier
          .fillMaxWidth()
          .weight(1f, fill = true)
          .padding(horizontal = if (isWide) 16.dp else 8.dp)
          .clip(RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
      ) {
        // Keep the artwork and its three touch/focus zones at the same 16:9 ratio.
        // This prevents the green focus frame drifting away from its gold label plaque.
        val artworkAspect = 1648f / 928f
        val containerAspect = maxWidth / maxHeight
        val artworkWidth = if (containerAspect > artworkAspect) maxHeight * artworkAspect else maxWidth
        val artworkHeight = if (containerAspect > artworkAspect) maxHeight else maxWidth / artworkAspect
        Box(Modifier.width(artworkWidth).height(artworkHeight)) {
          Image(
            painter = painterResource(R.drawable.home_cards_reference),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
          )
          androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize()) {
            var liveFocused by remember { mutableStateOf(false) }
          var moviesFocused by remember { mutableStateOf(false) }
          var seriesFocused by remember { mutableStateOf(false) }
          val liveInteraction = remember { MutableInteractionSource() }
          val moviesInteraction = remember { MutableInteractionSource() }
          val seriesInteraction = remember { MutableInteractionSource() }

          Box(
            Modifier
              .weight(1f)
              .fillMaxHeight()
              .onFocusChanged { liveFocused = it.isFocused }
              .clip(RoundedCornerShape(12.dp))
              .clickable(interactionSource = liveInteraction, indication = null) { onNavigateToLive() }
              .focusRequester(firstCardFocus),
            contentAlignment = Alignment.Center
          ) {
            if (liveFocused) {
              Box(
                Modifier
                  .align(Alignment.BottomCenter)
                  .fillMaxWidth(0.88f)
                  .height(artworkHeight * 0.16f)
                  .offset(y = -(artworkHeight * 0.20f))
                  .border(2.dp, FocusGreen, RoundedCornerShape(14.dp))
              )
            }
          }
          Box(
            Modifier
              .weight(1f)
              .fillMaxHeight()
              .onFocusChanged { moviesFocused = it.isFocused }
              .clip(RoundedCornerShape(12.dp))
              .clickable(interactionSource = moviesInteraction, indication = null) { onNavigateToMovies() },
            contentAlignment = Alignment.Center
          ) {
            if (moviesFocused) {
              Box(
                Modifier
                  .align(Alignment.BottomCenter)
                  .fillMaxWidth(0.88f)
                  .height(artworkHeight * 0.16f)
                  .offset(y = -(artworkHeight * 0.20f))
                  .border(2.dp, FocusGreen, RoundedCornerShape(14.dp))
              )
            }
          }
          Box(
            Modifier
              .weight(1f)
              .fillMaxHeight()
              .onFocusChanged { seriesFocused = it.isFocused }
              .clip(RoundedCornerShape(12.dp))
              .clickable(interactionSource = seriesInteraction, indication = null) { onNavigateToSeries() },
            contentAlignment = Alignment.Center
          ) {
            if (seriesFocused) {
              Box(
                Modifier
                  .align(Alignment.BottomCenter)
                  .fillMaxWidth(0.88f)
                  .height(artworkHeight * 0.16f)
                  .offset(y = -(artworkHeight * 0.20f))
                  .border(2.dp, FocusGreen, RoundedCornerShape(14.dp))
              )
            }
            }
            }
          }
        }
      }

      Spacer(Modifier.height(16.dp))

      // FIX 2: Bottom buttons with proper TV focus - same green border system as cards
      Row(
        Modifier
          .fillMaxWidth()
          .padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Settings
        var settingsFocused by remember { mutableStateOf(false) }
        Box(
          Modifier
            .weight(1f)
            .padding(4.dp)
            .onFocusChanged { settingsFocused = it.isFocused }
            .border(
              width = 1.dp,
              color = Gold.copy(alpha = 0.4f),
              shape = RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(DarkPanel)
            .clickable { onNavigateToSettings() }
            .focusRequester(settingsFocus)
            .padding(vertical = 12.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("الإعدادات", color = if (settingsFocused) FocusGreen else Gold, fontSize = if (isWide) 20.sp else 18.sp, fontWeight = FontWeight.Bold)
        }

        // Connections (Playlist)
        var playlistFocused by remember { mutableStateOf(false) }
        Box(
          Modifier
            .weight(1f)
            .padding(4.dp)
            .onFocusChanged { playlistFocused = it.isFocused }
            .border(
              width = 1.dp,
              color = Gold.copy(alpha = 0.4f),
              shape = RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(DarkPanel)
            .clickable { onNavigateToPlaylist() }
            .padding(vertical = 12.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("الاتصالات", color = if (playlistFocused) FocusGreen else Gold, fontSize = if (isWide) 20.sp else 18.sp, fontWeight = FontWeight.Bold)
        }

        // Exit
        var exitFocused by remember { mutableStateOf(false) }
        Box(
          Modifier
            .weight(1f)
            .padding(4.dp)
            .onFocusChanged { exitFocused = it.isFocused }
            .border(
              width = 1.dp,
              color = Color.White.copy(alpha = 0.3f),
              shape = RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(DarkPanel)
            .clickable { showExitDialog = true }
            .padding(vertical = 12.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("خروج", color = if (exitFocused) FocusGreen else Color.White.copy(0.8f), fontSize = if (isWide) 20.sp else 18.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }

  LaunchedEffect(Unit) {
    // Request focus on first card for TV remote
    kotlinx.coroutines.delay(300)
    try { firstCardFocus.requestFocus() } catch (_: Exception) {}
  }

  if (showExitDialog) {
    AlertDialog(
      onDismissRequest = { showExitDialog = false },
      title = { Text("خروج", color = Color.White) },
      text = { Text("هل تريد الخروج من التطبيق؟", color = Muted) },
      confirmButton = {
        TextButton(onClick = { showExitDialog = false; activity?.finishAffinity() }) {
          Text("نعم", color = Gold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showExitDialog = false }) {
          Text("لا", color = Muted)
        }
      },
      containerColor = DarkPanel
    )
  }
}
