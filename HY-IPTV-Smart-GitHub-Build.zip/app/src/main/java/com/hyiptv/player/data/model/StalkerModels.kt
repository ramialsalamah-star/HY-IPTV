package com.hyiptv.player.data.model

data class StalkerProfile(
  val id: String,
  val name: String,
  val macAddress: String,
  val portalUrl: String,
  val createdAt: Long = System.currentTimeMillis()
)

data class StalkerHandshakeResponse(
  val js: StalkerJsData? = null,
  val text: String? = null
)

data class StalkerJsData(
  val token: String? = null,
  val random: String? = null,
  val not_valid: Int? = null
)

data class StalkerProfileInfo(
  val id: String? = null,
  val name: String? = null,
  val login: String? = null,
  val parent_password: String? = null
)
