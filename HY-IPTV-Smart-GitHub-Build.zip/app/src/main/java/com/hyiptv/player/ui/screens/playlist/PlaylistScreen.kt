package com.hyiptv.player.ui.screens.playlist

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hyiptv.player.R
import com.hyiptv.player.data.repository.PlaylistRepository
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistScreen(
  onBack: () -> Unit,
  onPlaylistLoaded: () -> Unit = {}
) {
  val context = LocalContext.current
  val repository = remember { PlaylistRepository(context) }
  val scope = rememberCoroutineScope()
  val savedPlaylists by repository.playlistsFlow.collectAsState(initial = emptyList())
  var playlistToDelete by remember { mutableStateOf<String?>(null) }
  var playlistToRename by remember { mutableStateOf<String?>(null) }
  var renameValue by remember { mutableStateOf("") }

  var playlistName by remember { mutableStateOf("My Playlist") }
  var isLoading by remember { mutableStateOf(false) }
  var activatingId by remember { mutableStateOf<String?>(null) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }

  fun importSelectedUri(uri: Uri?) {
    if (uri == null) {
      message = "لم يتم اختيار ملف أو تم الإلغاء"
      isError = true
      return
    }
    try {
      context.contentResolver.takePersistableUriPermission(
        uri,
        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
      )
    } catch (_: Exception) {}
    isLoading = true
    message = "جاري قراءة الملف..."
    isError = false
    scope.launch {
      val name = playlistName.ifBlank { "Local M3U" }
      val result = repository.loadM3uFromUri(uri, name)
      isLoading = false
      result.onSuccess { count ->
        message = "تم استيراد $count قناة من الملف بنجاح - تم تفعيلها تلقائيا"
        isError = false
        onPlaylistLoaded()
      }.onFailure { e ->
        message = e.message ?: "فشل استيراد الملف - قد تكون صلاحية الملف انتهت، حاول مرة أخرى"
        isError = true
      }
    }
  }

  val contentPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent(),
    onResult = ::importSelectedUri
  )
  val filePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
    onResult = ::importSelectedUri
  )

  fun activatePlaylist(playlistId: String, playlistName: String) {
    if (isLoading) return
    activatingId = playlistId
    isLoading = true
    message = "جاري تفعيل $playlistName..."
    isError = false
    scope.launch {
      val result = repository.activatePlaylist(playlistId)
      isLoading = false
      activatingId = null
      result.onSuccess { count ->
        message = "تم تفعيل $playlistName — $count عنصر جاهز للمشاهدة"
        isError = false
        onPlaylistLoaded()
      }.onFailure { error ->
        val errMsg = error.message ?: "تعذر تفعيل القائمة"
        message = when {
          errMsg.contains("غير صالح", true) || errMsg.contains("صلاحية", true) -> "تعذر قراءة ملف هذه القائمة. قد تكون صلاحية الملف انتهت. أعد استيراد الملف من جديد."
          errMsg.contains("Connection", true) || errMsg.contains("Failed", true) -> "فشل الاتصال بخادم Xtream. تأكد من الإنترنت وبيانات السيرفر."
          else -> errMsg
        }
        isError = true
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text(
          text = stringResource(R.string.playlists),
          color = GoldPrimary,
          fontWeight = FontWeight.Bold
        )
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = null,
            tint = GoldPrimary
          )
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(
        containerColor = CharcoalSurface
      )
    )

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (savedPlaylists.isNotEmpty()) {
        Card(
          modifier = Modifier.fillMaxWidth().border(1.dp, GoldPrimary.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = CardBackground)
        ) {
          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(Icons.Default.CheckCircle, null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
              Text("القوائم المحفوظة - اختر واحدة لتفعيلها", color = GoldPrimary, fontWeight = FontWeight.Bold)
            }
            Text("اضغط على القائمة لتفعيلها، أو اضغط ▶ للدخول المباشر", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(4.dp))

            savedPlaylists.forEach { playlist ->
              val isActive = playlist.isActive
              val isActivatingThis = activatingId == playlist.id
              var isFocused by remember { mutableStateOf(false) }
              val focusRequester = remember { FocusRequester() }

              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .focusRequester(focusRequester)
                  .onFocusChanged { isFocused = it.isFocused }
                  .focusable()
                  .border(
                    width = when {
                      isFocused -> 3.dp
                      isActive -> 2.dp
                      else -> 1.dp
                    },
                    color = when {
                      isFocused -> Color(0xFF39E600)
                      isActive -> GoldPrimary
                      else -> DividerColor
                    },
                    shape = RoundedCornerShape(12.dp)
                  )
                  .clickable(enabled = !isLoading) {
                    if (isActive) {
                      onPlaylistLoaded()
                    } else {
                      activatePlaylist(playlist.id, playlist.name)
                    }
                  },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (isActive) GoldPrimary.copy(alpha = 0.12f) else CardBackground.copy(alpha = 0.9f)
                )
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    Icon(
                      imageVector = if (isActive) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                      contentDescription = null,
                      tint = if (isActive) GoldPrimary else TextMuted,
                      modifier = Modifier.size(22.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                      Text(playlist.name, color = TextPrimary, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                      Text(
                        text = when (playlist.type) {
                          com.hyiptv.player.data.model.PlaylistType.XTREAM -> "Xtream - ${playlist.username}"
                          com.hyiptv.player.data.model.PlaylistType.M3U -> if (playlist.url.startsWith("content://")) "M3U - ملف محلي" else "M3U - رابط"
                          else -> playlist.type.name
                        },
                        color = TextMuted,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                      )
                      if (isActive) {
                        Text("نشط الآن - اضغط للدخول", color = GoldPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (isActive) {
                      IconButton(
                        onClick = { onPlaylistLoaded() },
                        modifier = Modifier.size(40.dp)
                      ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل", tint = GoldPrimary, modifier = Modifier.size(28.dp))
                      }
                    } else {
                      Button(
                        onClick = { activatePlaylist(playlist.id, playlist.name) },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BlackBackground),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                      ) {
                        if (isActivatingThis) {
                          CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = BlackBackground)
                        } else {
                          Text("تفعيل", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                      }
                    }
                    IconButton(onClick = { playlistToRename = playlist.id; renameValue = playlist.name }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Edit, null, tint = TextMuted, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { playlistToDelete = playlist.id }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Delete, null, tint = ErrorRed.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Import section
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.FolderOpen, null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
            Text("من الجهاز M3U استيراد ملف", color = TextPrimary, fontWeight = FontWeight.Bold)
          }
          OutlinedTextField(
            value = playlistName,
            onValueChange = { playlistName = it },
            label = { Text("اسم القائمة") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, focusedLabelColor = GoldPrimary)
          )
          Button(
            onClick = {
              try { filePicker.launch(arrayOf("*/*")) } catch (_: Exception) { contentPicker.launch("*/*") }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BlackBackground)
          ) {
            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("اختيار ملف M3U / M3U8", fontWeight = FontWeight.Bold)
          }
          Text("من الملفات أو التنزيلات - يدعم .m3u و .m3u8", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
      }

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Link, null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
            Text("إضافة رابط M3U", color = TextPrimary, fontWeight = FontWeight.Bold)
          }
          var urlValue by remember { mutableStateOf("") }
          OutlinedTextField(
            value = urlValue,
            onValueChange = { urlValue = it },
            label = { Text("رابط M3U") },
            placeholder = { Text("https://...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, focusedLabelColor = GoldPrimary)
          )
          Button(
            onClick = {
              if (urlValue.isBlank()) {
                message = "أدخل رابط M3U أولاً"
                isError = true
                return@Button
              }
              isLoading = true
              message = "جاري تحميل القائمة من الرابط..."
              isError = false
              scope.launch {
                val result = repository.loadM3uPlaylist(urlValue.trim(), playlistName.ifBlank { "M3U Link" })
                isLoading = false
                result.onSuccess { count ->
                  message = "تم تحميل $count قناة بنجاح"
                  isError = false
                  urlValue = ""
                  onPlaylistLoaded()
                }.onFailure { e ->
                  message = e.message ?: "فشل التحميل"
                  isError = true
                }
              }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BlackBackground)
          ) {
            Text("تحميل من الرابط", fontWeight = FontWeight.Bold)
          }
        }
      }

      if (message != null) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = if (isError) ErrorRed.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.15f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(message!!, modifier = Modifier.padding(12.dp), color = if (isError) ErrorRed else SuccessGreen, style = MaterialTheme.typography.bodySmall)
        }
      }

      if (isLoading) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
          CircularProgressIndicator(color = GoldPrimary)
        }
      }
    }
  }

  if (playlistToDelete != null) {
    AlertDialog(
      onDismissRequest = { playlistToDelete = null },
      title = { Text("حذف القائمة؟") },
      text = { Text("هل أنت متأكد من حذف هذه القائمة؟ سيتم حذف قنواتها أيضا.") },
      confirmButton = {
        TextButton(onClick = {
          val id = playlistToDelete!!
          playlistToDelete = null
          scope.launch { repository.deletePlaylist(id) }
        }) { Text("حذف", color = ErrorRed) }
      },
      dismissButton = { TextButton(onClick = { playlistToDelete = null }) { Text("إلغاء") } }
    )
  }

  if (playlistToRename != null) {
    AlertDialog(
      onDismissRequest = { playlistToRename = null },
      title = { Text("إعادة تسمية") },
      text = {
        OutlinedTextField(value = renameValue, onValueChange = { renameValue = it }, label = { Text("الاسم الجديد") }, singleLine = true, modifier = Modifier.fillMaxWidth())
      },
      confirmButton = {
        TextButton(onClick = {
          val id = playlistToRename!!
          val newName = renameValue.trim()
          playlistToRename = null
          if (newName.isNotBlank()) { scope.launch { repository.renamePlaylist(id, newName) } }
        }) { Text("حفظ") }
      },
      dismissButton = { TextButton(onClick = { playlistToRename = null }) { Text("إلغاء") } }
    )
  }
}
