package com.hyiptv.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.hyiptv.player.ui.navigation.AppNavigation
import com.hyiptv.player.ui.theme.BlackBackground
import com.hyiptv.player.ui.theme.HYIPTVTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      HYIPTVTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = BlackBackground
        ) {
          AppNavigation()
        }
      }
    }
  }
}
