package com.hyiptv.player.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hyiptv.player.R
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.ui.theme.*
import com.hyiptv.player.util.DeviceIdManager
import com.hyiptv.player.util.DeviceModeManager
import com.hyiptv.player.util.GroupLockManager
import com.hyiptv.player.util.WatchProgressManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  onBack: () -> Unit,
  onNavigateToBackup: () -> Unit = {},
  onNavigateToPlaylist: () -> Unit = {},
  onNavigateToVpn: () -> Unit = {}
) {
  val context = LocalContext.current
  val deviceIdManager = remember { DeviceIdManager(context) }
  val modeManager = remember { DeviceModeManager(context) }
  val lockManager = remember { GroupLockManager(context) }
  val watchProgressManager = remember { WatchProgressManager(context) }
  val channelRepo = remember { ChannelRepository(context) }
  val scope = rememberCoroutineScope()

  var deviceId by remember { mutableStateOf("") }
  var showAbout by remember { mutableStateOf(false) }
  var showClearConfirm by remember { mutableStateOf(false) }
  var showClearHistoryConfirm by remember { mutableStateOf(false) }
  var showModeDialog by remember { mutableStateOf(false) }
  var showChangePin by remember { mutableStateOf(false) }
  var pinField by remember { mutableStateOf("") }
  var deviceMode by remember { mutableStateOf(DeviceModeManager.MODE_PHONE) }

  LaunchedEffect(Unit) {
    deviceId = deviceIdManager.getDeviceId()
    deviceMode = modeManager.getMode()
  }

  Column(
    Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text(stringResource(R.string.settings), color = GoldPrimary, fontWeight = FontWeight.Bold)
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    Column(
      Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

      SettingsSection(title = "نوع الجهاز") {
        SettingsItem(
          icon = Icons.Filled.Tv,
          title = "موبايل / TV Box",
          subtitle = if (deviceMode == DeviceModeManager.MODE_TV) "TV Box" else "موبايل",
          onClick = { showModeDialog = true }
        )
      }

      SettingsSection(title = "القفل السري للقوائم") {
        SettingsItem(
          icon = Icons.Filled.Lock,
          title = if (lockManager.hasPin()) "تغيير الرمز السري" else "تعيين رمز سري",
          subtitle = if (lockManager.hasPin()) "محمي" else "غير مفعّل",
          onClick = { showChangePin = true; pinField = "" }
        )
        SettingsItem(
          icon = Icons.Filled.Info,
          title = "طريقة الاستخدام",
          subtitle = "من البث المباشر اضغط أيقونة القفل ثم اختر المجموعات"
        )
      }

      SettingsSection(title = stringResource(R.string.language)) {
        SettingsItem(
          icon = Icons.Filled.Language,
          title = stringResource(R.string.language),
          subtitle = "العربية / English (حسب لغة الجهاز)",
          onClick = {
            Toast.makeText(
              context,
              "اللغة تتبع إعدادات نظام أندرويد",
              Toast.LENGTH_SHORT
            ).show()
          }
        )
      }

      SettingsSection(title = stringResource(R.string.player_settings)) {
        SettingsItem(
          icon = Icons.Filled.PlayCircle,
          title = stringResource(R.string.player_settings),
          subtitle = "Adaptive + 4K + User-Agent IPTV",
          onClick = {
            Toast.makeText(
              context,
              "المشغل مضبوط تلقائياً للتكيف مع الشبكة و4K",
              Toast.LENGTH_LONG
            ).show()
          }
        )
        SettingsItem(
          icon = Icons.Filled.PlaylistPlay,
          title = stringResource(R.string.playlist_management),
          subtitle = "إضافة / استيراد M3U",
          onClick = onNavigateToPlaylist
        )
        SettingsItem(
          icon = Icons.Filled.VpnKey,
          title = "إعدادات VPN الأسبوعي",
          subtitle = "ملفك الحالي: fr1.vpnjantit.com - يتغير كل أسبوع",
          onClick = onNavigateToVpn
        )
        SettingsItem(
          icon = Icons.Filled.CalendarMonth,
          title = stringResource(R.string.epg_settings),
          subtitle = "قريباً",
          onClick = {
            Toast.makeText(context, "دليل البرامج — قريباً", Toast.LENGTH_SHORT).show()
          }
        )
      }

      SettingsSection(title = stringResource(R.string.cache_management)) {
        SettingsItem(
          icon = Icons.Filled.DeleteSweep,
          title = stringResource(R.string.clear_cache),
          subtitle = "حذف القنوات المحفوظة محلياً",
          onClick = { showClearConfirm = true }
        )
        SettingsItem(
          icon = Icons.Filled.History,
          title = "مسح سجل المشاهدة والتقدم",
          subtitle = "حذف مواضع الاستئناف المحفوظة",
          onClick = { showClearHistoryConfirm = true }
        )
        SettingsItem(
          icon = Icons.Filled.SettingsBackupRestore,
          title = stringResource(R.string.backup_restore),
          subtitle = stringResource(R.string.export_import),
          onClick = onNavigateToBackup
        )
      }

      SettingsSection(title = stringResource(R.string.about)) {
        SettingsItem(
          icon = Icons.Filled.Info,
          title = stringResource(R.string.about_app),
          subtitle = "HY IPTV Player v1.0.0",
          onClick = { showAbout = true }
        )
        SettingsItem(
          icon = Icons.Filled.Policy,
          title = stringResource(R.string.privacy_policy),
          onClick = {
            Toast.makeText(
              context,
              "البيانات تُحفظ على جهازك فقط",
              Toast.LENGTH_LONG
            ).show()
          }
        )
        SettingsItem(
          icon = Icons.Filled.Description,
          title = stringResource(R.string.terms_of_service),
          onClick = {
            Toast.makeText(
              context,
              "للاستخدام الشخصي وفق القوانين المحلية",
              Toast.LENGTH_LONG
            ).show()
          }
        )
        SettingsItem(
          icon = Icons.Filled.SupportAgent,
          title = stringResource(R.string.contact_support),
          subtitle = "00971555575145",
          onClick = {
            try {
              val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:00971555575145"))
              context.startActivity(intent)
            } catch (_: Exception) {
              Toast.makeText(context, "00971555575145", Toast.LENGTH_LONG).show()
            }
          }
        )
      }

      Spacer(Modifier.height(8.dp))
      Text(
        stringResource(R.string.developer_full),
        style = MaterialTheme.typography.bodySmall,
        color = TextMuted,
        modifier = Modifier.align(Alignment.CenterHorizontally)
      )
    }
  }

  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      title = { Text("مسح البيانات", color = TextPrimary) },
      text = { Text("سيتم حذف جميع القنوات المحفوظة. المتابعة؟", color = TextSecondary) },
      confirmButton = {
        TextButton(onClick = {
          showClearConfirm = false
          scope.launch {
            channelRepo.clearAll()
            Toast.makeText(context, "تم المسح", Toast.LENGTH_SHORT).show()
          }
        }) { Text("نعم", color = GoldPrimary) }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) {
          Text("إلغاء", color = TextMuted)
        }
      },
      containerColor = Color(0xFF1A1A1A)
    )
  }

  if (showClearHistoryConfirm) {
    AlertDialog(
      onDismissRequest = { showClearHistoryConfirm = false },
      title = { Text("مسح سجل المشاهدة", color = TextPrimary) },
      text = { Text("سيتم حذف تقدم المشاهدة المحفوظ لكل العناصر. لا يمكن التراجع.", color = TextSecondary) },
      confirmButton = {
        TextButton(onClick = {
          watchProgressManager.clearAll()
          showClearHistoryConfirm = false
          Toast.makeText(context, "تم مسح تقدم المشاهدة", Toast.LENGTH_SHORT).show()
        }) { Text("مسح", color = GoldPrimary) }
      },
      dismissButton = {
        TextButton(onClick = { showClearHistoryConfirm = false }) { Text("إلغاء", color = TextMuted) }
      },
      containerColor = Color(0xFF1A1A1A)
    )
  }

  if (showAbout) {
    AlertDialog(
      onDismissRequest = { showAbout = false },
      title = { Text("حول التطبيق", color = GoldPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("HY IPTV Player v1.0.0", color = TextPrimary)
          Spacer(Modifier.height(8.dp))
          Text("المطور: رامي السلامة أبو يعرب", color = TextSecondary)
          Text("الإمارات العربية المتحدة — أبوظبي", color = TextSecondary)
          Text("موبايل: 00971555575145", color = GoldAccent)
        }
      },
      confirmButton = {
        TextButton(onClick = { showAbout = false }) {
          Text("حسناً", color = GoldPrimary)
        }
      },
      containerColor = Color(0xFF1A1A1A)
    )
  }

  if (showChangePin) {
    AlertDialog(
      onDismissRequest = { showChangePin = false },
      title = { Text("الرمز السري", color = GoldPrimary) },
      text = {
        OutlinedTextField(
          value = pinField,
          onValueChange = { pinField = it.filter(Char::isDigit).take(8) },
          label = { Text("أدخل رمزاً (4+)", color = TextSecondary) },
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DividerColor,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = GoldPrimary,
            focusedContainerColor = DarkSurface,
            unfocusedContainerColor = DarkSurface
          )
        )
      },
      confirmButton = {
        TextButton(onClick = {
          if (pinField.length >= 4) {
            lockManager.setPin(pinField)
            showChangePin = false
            Toast.makeText(context, "تم حفظ الرمز", Toast.LENGTH_SHORT).show()
          }
        }) { Text("حفظ", color = GoldPrimary) }
      },
      dismissButton = {
        TextButton(onClick = { showChangePin = false }) {
          Text("إلغاء", color = TextMuted)
        }
      },
      containerColor = Color(0xFF1A1A1A)
    )
  }

  if (showModeDialog) {
    AlertDialog(
      onDismissRequest = { showModeDialog = false },
      title = { Text("نوع الجهاز", color = TextPrimary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = {
              modeManager.setMode(DeviceModeManager.MODE_PHONE)
              deviceMode = DeviceModeManager.MODE_PHONE
              showModeDialog = false
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
              containerColor = GoldPrimary,
              contentColor = BlackBackground
            )
          ) { Text("موبايل / تابلت") }
          OutlinedButton(
            onClick = {
              modeManager.setMode(DeviceModeManager.MODE_TV)
              deviceMode = DeviceModeManager.MODE_TV
              showModeDialog = false
            },
            modifier = Modifier.fillMaxWidth()
          ) { Text("TV Box / تلفزيون", color = TextPrimary) }
        }
      },
      confirmButton = {},
      containerColor = Color(0xFF1A1A1A)
    )
  }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
  Column {
    Text(
      title,
      color = GoldAccent,
      style = MaterialTheme.typography.titleSmall,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
    )
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardBackground),
      modifier = Modifier.border(1.dp, DividerColor, RoundedCornerShape(14.dp))
    ) {
      Column(Modifier.padding(vertical = 4.dp), content = content)
    }
  }
}

@Composable
private fun SettingsItem(
  icon: ImageVector,
  title: String,
  subtitle: String? = null,
  onClick: (() -> Unit)? = null
) {
  var focused by remember { mutableStateOf(false) }
  val interactionSource = remember { MutableInteractionSource() }
  Row(
    Modifier
      .fillMaxWidth()
      .onFocusChanged { focused = it.isFocused }
      .then(
        if (onClick != null) Modifier
          .clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
          )
        else Modifier
      )
      .then(
        if (focused) Modifier.border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
        else Modifier
      )
      .padding(horizontal = 14.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
    Spacer(Modifier.width(14.dp))
    Column(Modifier.weight(1f)) {
      Text(title, color = TextPrimary, fontWeight = FontWeight.Medium)
      if (subtitle != null) {
        Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
      }
    }
    if (onClick != null) {
      Icon(
        Icons.AutoMirrored.Filled.ArrowForwardIos,
        null,
        tint = TextMuted,
        modifier = Modifier.size(14.dp)
      )
    }
  }
}
