
package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences

class LastChannelManager(context: Context) {
  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("last_channel", Context.MODE_PRIVATE)

  companion object {
    private const val KEY_URL = "last_url"
    private const val KEY_TITLE = "last_title"
    private const val KEY_USER_SELECTED = "user_selected"
    private const val KEY_TIMESTAMP = "timestamp"
  }

  /**
   * Save only when user manually selects a live channel
   * Requirement: fix 7 - auto-play only for Live TV and only when user selected
   */
  fun save(url: String, title: String, userSelected: Boolean = false) {
    if (url.isBlank()) return
    // Only save if user explicitly selected (not auto preview)
    if (!userSelected) return
    prefs.edit()
      .putString(KEY_URL, url)
      .putString(KEY_TITLE, title)
      .putBoolean(KEY_USER_SELECTED, true)
      .putLong(KEY_TIMESTAMP, System.currentTimeMillis())
      .apply()
  }

  fun get(): Pair<String, String>? {
    val url = prefs.getString(KEY_URL, null) ?: return null
    if (url.isBlank()) return null
    val title = prefs.getString(KEY_TITLE, url) ?: url
    return Pair(url, title)
  }

  fun clear() {
    prefs.edit().clear().apply()
  }

  fun hasUserSelected(): Boolean {
    return prefs.getBoolean(KEY_USER_SELECTED, false)
  }
}
