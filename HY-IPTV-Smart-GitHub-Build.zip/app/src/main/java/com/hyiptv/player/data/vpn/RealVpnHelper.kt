package com.hyiptv.player.data.vpn

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import java.io.File
import java.io.FileOutputStream

class RealVpnHelper(private val context: Context) {

  companion object {
    @Volatile var isRunning = false
    var currentServerInfo: String = ""
  }

  private fun getPrefs(): SharedPreferences {
    return context.getSharedPreferences("real_vpn_prefs", Context.MODE_PRIVATE)
  }

  fun parseServerFromOvpn(path: String): String {
    return try {
      val text = File(path).readText()
      val remoteLine = text.lines().firstOrNull { it.trim().startsWith("remote ") }?.trim() ?: "fr1.vpnjantit.com 2501"
      val parts = remoteLine.removePrefix("remote ").trim().split(" ").filter { it.isNotBlank() }
      if (parts.size >= 2) "${parts[0]} ${parts[1]}" else parts.firstOrNull() ?: "fr1.vpnjantit.com 2501"
    } catch (_: Exception) {
      "fr1.vpnjantit.com 2501"
    }
  }

  fun startRealVpn(configPath: String): Boolean {
    return try {
      val configFile = File(configPath)
      if (!configFile.exists() || configFile.length() < 100) {
        return false
      }

      val serverInfo = parseServerFromOvpn(configPath)
      currentServerInfo = serverInfo

      getPrefs().edit().putString("last_config_path", configPath).apply()
      getPrefs().edit().putString("last_server_info", serverInfo).apply()

      // شغل عبر NativeVpnService
      val intent = Intent(context, NativeVpnService::class.java).apply {
        action = NativeVpnService.ACTION_START
        putExtra(NativeVpnService.EXTRA_CONFIG_PATH, configPath)
      }
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          context.startForegroundService(intent)
        } else {
          context.startService(intent)
        }
        // Do not report success just because Android accepted the service start.
        // Wait for OpenVPN's Initialization Sequence Completed event.
        val deadline = System.currentTimeMillis() + 30_000L
        while (System.currentTimeMillis() < deadline) {
          if (NativeVpnService.isConnected && NativeVpnService.isRunning) {
            isRunning = true
            return true
          }
          if (!NativeVpnService.isRunning && !NativeVpnService.isConnected &&
              System.currentTimeMillis() > deadline - 27_000L) {
            // Give the service a short startup window before checking for failure.
          }
          Thread.sleep(250)
        }
        stopRealVpn()
        false
      } catch (e: Exception) {
        e.printStackTrace()
        false
      }
    } catch (e: Exception) {
      e.printStackTrace()
      false
    }
  }

  fun stopRealVpn(): Boolean {
    return try {
      val intent = Intent(context, NativeVpnService::class.java).apply {
        action = NativeVpnService.ACTION_STOP
      }
      try {
        context.startService(intent)
      } catch (_: Exception) {}
      isRunning = false
      currentServerInfo = ""
      true
    } catch (e: Exception) {
      e.printStackTrace()
      isRunning = false
      currentServerInfo = ""
      false
    }
  }
  
  fun isVpnRunning(): Boolean {
    return try {
      NativeVpnService.isConnected && NativeVpnService.isRunning
    } catch (_: Exception) {
      isRunning
    }
  }
}
