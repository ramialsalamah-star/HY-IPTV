package com.hyiptv.player.data.model

data class Playlist(
  val id: String,
  val name: String,
  val type: PlaylistType,
  val url: String = "",
  val username: String = "",
  val password: String = "",
  val serverUrl: String = "",
  val isActive: Boolean = false
)

enum class PlaylistType {
  M3U, M3U_PLUS, XTREAM
}

data class Channel(
  val id: String,
  val name: String,
  val streamUrl: String,
  val logoUrl: String? = null,
  val group: String = "Uncategorized",
  val epgId: String? = null,
  val isFavorite: Boolean = false,
  val contentType: String = "live" // live | movie | series
)

data class Movie(
  val id: String,
  val name: String,
  val streamUrl: String,
  val posterUrl: String? = null,
  val plot: String? = null,
  val year: String? = null,
  val genre: String? = null,
  val rating: String? = null
)

data class Series(
  val id: String,
  val name: String,
  val posterUrl: String? = null,
  val plot: String? = null,
  val genre: String? = null,
  val seasons: List<Season> = emptyList()
)

data class Season(
  val seasonNumber: Int,
  val episodes: List<Episode> = emptyList()
)

data class Episode(
  val id: String,
  val name: String,
  val streamUrl: String,
  val episodeNumber: Int,
  val seasonNumber: Int = 0,
  val plot: String? = null
)

data class Category(
  val id: String,
  val name: String,
  val type: ContentType
)

enum class ContentType {
  LIVE, MOVIE, SERIES
}
