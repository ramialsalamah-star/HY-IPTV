package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONObject

 data class WatchProgressEntry(
  val mediaId: String,
  val title: String,
  val positionMs: Long,
  val durationMs: Long,
  val updatedAt: Long
)

/** Persists playback position and duration independently from the playlist database. */
class WatchProgressManager(context: Context) {
  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("watch_progress", Context.MODE_PRIVATE)

  @Synchronized
  fun saveProgress(mediaId: String, positionMs: Long, durationMs: Long, title: String = "") {
    if (mediaId.isBlank()) return
    val safePosition = positionMs.coerceAtLeast(0L)
    val safeDuration = durationMs.coerceAtLeast(0L)
    val value = JSONObject()
      .put("mediaId", mediaId)
      .put("title", title)
      .put("position", safePosition)
      .put("duration", safeDuration)
      .put("updatedAt", System.currentTimeMillis())
    prefs.edit().putString(key(mediaId), value.toString()).apply()
  }

  fun getProgress(mediaId: String): Long = read(mediaId)?.optLong("position", 0L) ?: 0L

  fun getDuration(mediaId: String): Long = read(mediaId)?.optLong("duration", 0L) ?: 0L

  fun getProgressPercent(mediaId: String): Int {
    val duration = getDuration(mediaId)
    if (duration <= 0L) return 0
    return ((getProgress(mediaId).toDouble() / duration.toDouble()) * 100.0)
      .toInt().coerceIn(0, 100)
  }

  fun clearProgress(mediaId: String) {
    prefs.edit().remove(key(mediaId)).apply()
  }

  fun clearAll() {
    prefs.edit().clear().apply()
  }

  fun getAllProgress(): List<WatchProgressEntry> = prefs.all.mapNotNull { (storedKey, raw) ->
    if (!storedKey.startsWith(PREFIX) || raw !is String) return@mapNotNull null
    try {
      val json = JSONObject(raw)
      val mediaId = json.optString("mediaId").ifBlank { decodeKey(storedKey) }
      WatchProgressEntry(
        mediaId = mediaId,
        title = json.optString("title").ifBlank { mediaId },
        positionMs = json.optLong("position", 0L),
        durationMs = json.optLong("duration", 0L),
        updatedAt = json.optLong("updatedAt", 0L)
      )
    } catch (_: Exception) {
      null
    }
  }.sortedByDescending { it.updatedAt }

  private fun read(mediaId: String): JSONObject? {
    if (mediaId.isBlank()) return null
    return try {
      prefs.getString(key(mediaId), null)?.let(::JSONObject)
    } catch (_: Exception) {
      null
    }
  }

  private fun key(mediaId: String): String =
    PREFIX + Base64.encodeToString(mediaId.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

  private fun decodeKey(storedKey: String): String = try {
    String(Base64.decode(storedKey.removePrefix(PREFIX), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8)
  } catch (_: Exception) {
    storedKey.removePrefix(PREFIX)
  }

  private companion object {
    const val PREFIX = "media_"
  }
}
