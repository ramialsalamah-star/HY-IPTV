package com.hyiptv.player.ui.screens.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.key.*
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.runtime.rememberCoroutineScope
import com.hyiptv.player.player.PlayerSession
import com.hyiptv.player.player.StreamUrlResolver
import com.hyiptv.player.data.model.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.hyiptv.player.player.PlayerFactory
import com.hyiptv.player.util.WatchProgressManager
import com.hyiptv.player.util.LastChannelManager
import com.hyiptv.player.util.LiveTvStateManager
import com.hyiptv.player.ui.theme.BlackBackground
import com.hyiptv.player.ui.theme.GoldPrimary
import com.hyiptv.player.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
  streamUrl: String,
  title: String,
  source: String = "default",
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val view = LocalView.current
  val audioManager = remember { context.getSystemService(AudioManager::class.java) }

  var isPlaying by remember { mutableStateOf(true) }
  var showControls by remember { mutableStateOf(true) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isBuffering by remember { mutableStateOf(true) }
  var currentPositionMs by remember { mutableLongStateOf(0L) }
  var totalDurationMs by remember { mutableLongStateOf(0L) }
  var isSeeking by remember { mutableStateOf(false) }
  var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
  var isFullscreen by rememberSaveable { mutableStateOf(false) }

  LaunchedEffect(isFullscreen) {
    resizeMode = if (isFullscreen) AspectRatioFrameLayout.RESIZE_MODE_FILL else AspectRatioFrameLayout.RESIZE_MODE_FIT
  }
  var locked by remember { mutableStateOf(false) }
  var currentQuality by remember { mutableStateOf<String?>(null) }
  var loadGeneration by remember { mutableIntStateOf(0) }
  var showAudioDialog by remember { mutableStateOf(false) }
  var showSubtitleDialog by remember { mutableStateOf(false) }
  var showAspectDialog by remember { mutableStateOf(false) }
  var audioTracks by remember { mutableStateOf<List<Pair<String, () -> Unit>>>(emptyList()) }
  var subtitleTracks by remember { mutableStateOf<List<Pair<String, () -> Unit>>>(emptyList()) }
  var brightnessHint by remember { mutableStateOf<String?>(null) }
  var volumeHint by remember { mutableStateOf<String?>(null) }
  var channelTitle by remember { mutableStateOf(title) }
  var activeUrl by remember { mutableStateOf(streamUrl) }
  var zapHint by remember { mutableStateOf<String?>(null) }
  val focusRequester = remember { FocusRequester() }
  val scope = rememberCoroutineScope()
  val progressManager = remember { WatchProgressManager(context) }
  val lastChannelManager = remember { LastChannelManager(context) }
  // Fix: Save only for live and only when manually selected - preview should not save
  LaunchedEffect(source, activeUrl, channelTitle) {
    if (source == "live" && activeUrl.isNotBlank()) {
      // AppNavigation already saves with userSelected=true when user clicks
      // This is fallback for direct intents - only save if not empty
      // Do not overwrite with empty or preview
    }
  }
  val savedPositionMs = remember(streamUrl) { progressManager.getProgress(streamUrl) }
  var showResumeDialog by remember(streamUrl) { mutableStateOf(savedPositionMs > 10_000L) }

  val exoPlayer = remember {
    PlayerFactory.createPlayer(context).apply {
      videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
      playWhenReady = !showResumeDialog

      addListener(object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
          isBuffering = state == Player.STATE_BUFFERING
          if (state == Player.STATE_ENDED) isPlaying = false
          if (state == Player.STATE_READY) errorMessage = null
        }

        override fun onIsPlayingChanged(playing: Boolean) {
          isPlaying = playing
        }

        override fun onPlayerError(error: PlaybackException) {
          // A different User-Agent is not a different decoder/player; report the real failure.
          errorMessage = friendlyError(error)
        }

        override fun onTracksChanged(tracks: Tracks) {
          // Quality label
          for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
              if (!group.isTrackSelected(i)) continue
              currentQuality = qualityLabel(group.getTrackFormat(i))
            }
          }
          // Audio / subtitle lists
          val audios = mutableListOf<Pair<String, () -> Unit>>()
          val subs = mutableListOf<Pair<String, () -> Unit>>()
          tracks.groups.forEachIndexed { _, group ->
            if (!group.isSupported) return@forEachIndexed
            when (group.type) {
              C.TRACK_TYPE_AUDIO -> {
                for (i in 0 until group.length) {
                  val f = group.getTrackFormat(i)
                  val label = trackLabel(f, "صوت ${i + 1}")
                  audios += label to {
                    trackSelectionParameters = trackSelectionParameters
                      .buildUpon()
                      .setOverrideForType(
                        TrackSelectionOverride(group.mediaTrackGroup, i)
                      )
                      .build()
                  }
                }
              }
              C.TRACK_TYPE_TEXT -> {
                for (i in 0 until group.length) {
                  val f = group.getTrackFormat(i)
                  val label = trackLabel(f, "ترجمة ${i + 1}")
                  subs += label to {
                    trackSelectionParameters = trackSelectionParameters
                      .buildUpon()
                      .setOverrideForType(
                        TrackSelectionOverride(group.mediaTrackGroup, i)
                      )
                      .build()
                  }
                }
              }
            }
          }
          if (subs.isNotEmpty()) {
            subs.add(0, "إيقاف الترجمة" to {
              trackSelectionParameters = trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            })
          }
          audioTracks = audios
          subtitleTracks = subs
        }
      })
    }
  }

  fun loadStream(url: String, resumePlayback: Boolean = true) {
    val requestGeneration = ++loadGeneration
    errorMessage = null
    isBuffering = true
    scope.launch {
      try {
        // Stalker portal commands must be resolved off the main thread.
        val resolvedUrl = withContext(Dispatchers.IO) {
          StreamUrlResolver.resolve(context, url)
        }
        // Ignore slow resolver results if the user has already switched channels.
        if (requestGeneration == loadGeneration) {
          exoPlayer.setMediaSource(PlayerFactory.createMediaSource(resolvedUrl))
          exoPlayer.prepare()
          exoPlayer.playWhenReady = resumePlayback
        }
      } catch (e: Exception) {
        if (requestGeneration == loadGeneration) {
          isBuffering = false
          errorMessage = e.message ?: "تعذر تجهيز رابط البث"
        }
      }
    }
  }

  LaunchedEffect(streamUrl) {
    loadStream(streamUrl, resumePlayback = !showResumeDialog)
  }

  fun playChannel(ch: Channel) {
    channelTitle = ch.name
    activeUrl = ch.streamUrl
    errorMessage = null
    loadStream(ch.streamUrl)
    zapHint = ch.name
  }

  fun channelUp() {
    PlayerSession.next()?.let { playChannel(it) }
  }

  fun channelDown() {
    PlayerSession.previous()?.let { playChannel(it) }
  }

  DisposableEffect(Unit) {
    activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    val window = activity?.window
    if (window != null) {
      val c = WindowCompat.getInsetsController(window, view)
      c.hide(WindowInsetsCompat.Type.systemBars())
      c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
    onDispose {
      // Persist the final position before releasing the player. This ensures
      // short episodes and fast Back navigation are not lost between ticks.
      val finalPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
      val finalDuration = exoPlayer.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
      if (activeUrl.isNotBlank() && finalPosition > 0L && finalDuration > 0L) {
        progressManager.saveProgress(activeUrl, finalPosition, finalDuration, channelTitle)
      }
      exoPlayer.release()
      activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
      if (window != null) {
        WindowCompat.getInsetsController(window, view)
          .show(WindowInsetsCompat.Type.systemBars())
      }
    }
  }

  LaunchedEffect(showControls, isPlaying, locked) {
    if (showControls && isPlaying && !locked && errorMessage == null) {
      delay(5000)
      showControls = false
    }
  }

  LaunchedEffect(brightnessHint, volumeHint) {
    if (brightnessHint != null || volumeHint != null) {
      delay(800)
      brightnessHint = null
      volumeHint = null
    }
  }

  LaunchedEffect(activeUrl) {
    while (true) {
      val position = exoPlayer.currentPosition.coerceAtLeast(0L)
      val duration = exoPlayer.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
      if (!isSeeking) currentPositionMs = position
      totalDurationMs = duration
      if (position > 0L && duration > 0L) {
        progressManager.saveProgress(activeUrl, position, duration, channelTitle)
      }
      delay(1_000L)
    }
  }

  if (showResumeDialog) {
    AlertDialog(
      onDismissRequest = {
        showResumeDialog = false
        exoPlayer.seekTo(0L)
        exoPlayer.play()
      },
      title = { Text("تكمل من وين وقفت؟", color = TextPrimary) },
      text = {
        Text(
          "يوجد تقدم محفوظ: ${formatResumeTime(savedPositionMs)}. هل تريد المتابعة؟",
          color = Color.LightGray
        )
      },
      confirmButton = {
        TextButton(onClick = {
          exoPlayer.seekTo(savedPositionMs)
          showResumeDialog = false
          exoPlayer.play()
        }) { Text("استئناف", color = GoldPrimary) }
      },
      dismissButton = {
        TextButton(onClick = {
          progressManager.clearProgress(streamUrl)
          exoPlayer.seekTo(0L)
          showResumeDialog = false
          exoPlayer.play()
        }) { Text("من البداية", color = TextPrimary) }
      },
      containerColor = Color(0xFF1A1A1A)
    )
  }

  BackHandler {
    if (isFullscreen) {
      isFullscreen = false
    } else if (locked) {
      locked = false
      showControls = true
    } else onBack()
  }

  LaunchedEffect(Unit) { focusRequester.requestFocus() }
  LaunchedEffect(zapHint) {
    if (zapHint != null) {
      delay(1200)
      zapHint = null
    }
  }

  Box(
    Modifier
      .fillMaxSize()
      .background(Color.Black)
      .focusRequester(focusRequester)
      .focusable()
      .onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (event.key) {
          Key.DirectionUp, Key.ChannelUp, Key.PageUp -> {
            // Channel zapping is a live-TV-only action. On movies/series,
            // consume the key locally so it cannot trigger navigation to Live TV.
            if (!locked && source == "live") channelUp()
            else if (!locked) showControls = true
            true
          }
          Key.DirectionDown, Key.ChannelDown, Key.PageDown -> {
            // DPAD Down must never switch a series/movie player to live channels.
            if (!locked && source == "live") channelDown()
            else if (!locked) showControls = true
            true
          }
          Key.DirectionLeft -> {
            if (!locked) exoPlayer.seekBack()
            true
          }
          Key.DirectionRight -> {
            if (!locked) exoPlayer.seekForward()
            true
          }
          Key.DirectionCenter, Key.Enter, Key.Spacebar, Key.MediaPlayPause -> {
            if (!locked) {
              if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
              showControls = true
            }
            true
          }
          Key.Back, Key.Escape -> {
            if (locked) {
              locked = false
              true
            } else false
          }
          Key.Menu, Key.Info -> {
            showControls = !showControls
            true
          }
          else -> false
        }
      }
      .pointerInput(locked) {
        detectTapGestures(
          onTap = {
            if (!locked) showControls = !showControls
            else showControls = !showControls
          },
          onDoubleTap = {
            if (!locked) {
              if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
            }
          }
        )
      }
      // Left half: brightness, Right half: volume
      .pointerInput(locked) {
        if (locked) return@pointerInput
        detectVerticalDragGestures { change, dragAmount ->
          change.consume()
          val x = change.position.x
          val w = size.width
          if (x < w / 2f) {
            // Brightness
            val window = activity?.window ?: return@detectVerticalDragGestures
            val lp = window.attributes
            val cur = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
            val next = (cur - dragAmount / size.height).coerceIn(0.01f, 1f)
            lp.screenBrightness = next
            window.attributes = lp
            brightnessHint = "السطوع ${(next * 100).toInt()}%"
          } else {
            // Volume
            val max = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
            val cur = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
            if (abs(dragAmount) > 20) {
              if (dragAmount < 0 && cur < max) {
                audioManager?.adjustStreamVolume(
                  AudioManager.STREAM_MUSIC,
                  AudioManager.ADJUST_RAISE,
                  0
                )
              } else if (dragAmount > 0 && cur > 0) {
                audioManager?.adjustStreamVolume(
                  AudioManager.STREAM_MUSIC,
                  AudioManager.ADJUST_LOWER,
                  0
                )
              }
              val now = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: cur
              volumeHint = "الصوت ${((now * 100f) / max).toInt()}%"
            }
          }
        }
      }
  ) {
    AndroidView(
      factory = { ctx ->
        PlayerView(ctx).apply {
          player = exoPlayer
          useController = false
          this.resizeMode = resizeMode
          layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
        }
      },
      update = { view ->
        view.resizeMode = resizeMode
        view.requestLayout()
        view.invalidate()
      },
      modifier = Modifier.fillMaxSize()
    )

    if (isBuffering && errorMessage == null) {
      CircularProgressIndicator(
        Modifier.align(Alignment.Center),
        color = GoldPrimary,
        strokeWidth = 3.dp
      )
    }

    // Gesture hints
    brightnessHint?.let {
      HintChip(it, Modifier.align(Alignment.CenterStart).padding(24.dp))
    }
    volumeHint?.let {
      HintChip(it, Modifier.align(Alignment.CenterEnd).padding(24.dp))
    }
    zapHint?.let {
      HintChip("📺 $it", Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 72.dp))
    }

    errorMessage?.let { msg ->
      Column(
        Modifier.align(Alignment.Center).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.Default.ErrorOutline, null, tint = Color.White, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text("تعذر التشغيل", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(msg, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Button(
            onClick = {
              errorMessage = null
              loadStream(activeUrl)
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
          ) { Text("إعادة", color = BlackBackground) }
          OutlinedButton(onClick = onBack) { Text("رجوع", color = Color.White) }
        }
      }
    }

    // LOCKED overlay
    if (locked && showControls) {
      Box(
        Modifier
          .fillMaxSize()
          .background(Color.Black.copy(0.35f)),
        contentAlignment = Alignment.Center
      ) {
        IconButton(
          onClick = { locked = false },
          modifier = Modifier
            .size(72.dp)
            .background(Color.Black.copy(0.5f), CircleShape)
        ) {
          Icon(Icons.Filled.Lock, "فتح القفل", tint = GoldPrimary, modifier = Modifier.size(36.dp))
        }
      }
    }

    AnimatedVisibility(
      visible = showControls && errorMessage == null && !locked,
      enter = fadeIn(),
      exit = fadeOut()
    ) {
      Box(Modifier.fillMaxSize()) {
        // Top gradient bar
        Row(
          Modifier
            .fillMaxWidth()
            .background(
              Brush.verticalGradient(
                listOf(Color.Black.copy(0.75f), Color.Transparent)
              )
            )
            .statusBarsPadding()
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .align(Alignment.TopCenter),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White)
          }
          Column(Modifier.weight(1f)) {
            Text(
              channelTitle,
              color = TextPrimary,
              style = MaterialTheme.typography.titleMedium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              fontWeight = FontWeight.SemiBold
            )
            currentQuality?.let {
              Text("تلقائي • $it", color = GoldPrimary, style = MaterialTheme.typography.labelSmall)
            }
          }
          ControlIcon(Icons.Filled.Lock, "قفل") { locked = true; showControls = true }
        }

        // Center transport
        Row(
          Modifier.align(Alignment.Center),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(28.dp)
        ) {
          IconButton(
            onClick = { exoPlayer.seekBack() },
            modifier = Modifier.size(56.dp).background(Color.Black.copy(0.35f), CircleShape)
          ) {
            Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(32.dp))
          }
          IconButton(
            onClick = {
              if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
            },
            modifier = Modifier.size(76.dp).background(GoldPrimary.copy(0.9f), CircleShape)
          ) {
            Icon(
              if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              null,
              tint = BlackBackground,
              modifier = Modifier.size(44.dp)
            )
          }
          IconButton(
            onClick = { exoPlayer.seekForward() },
            modifier = Modifier.size(56.dp).background(Color.Black.copy(0.35f), CircleShape)
          ) {
            Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(32.dp))
          }
        }

        // Bottom professional bar
        Column(
          Modifier
            .fillMaxWidth()
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color.Black.copy(0.8f))
              )
            )
            .navigationBarsPadding()
            .padding(bottom = 8.dp, top = 24.dp)
            .align(Alignment.BottomCenter)
        ) {
          if (totalDurationMs > 0L) {
            Row(
              Modifier.fillMaxWidth().padding(horizontal = 16.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(formatResumeTime(currentPositionMs), color = Color.White, style = MaterialTheme.typography.labelSmall)
              Text(formatResumeTime(totalDurationMs), color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
            Slider(
              value = currentPositionMs.coerceIn(0L, totalDurationMs).toFloat(),
              onValueChange = { value ->
                isSeeking = true
                currentPositionMs = value.toLong()
              },
              onValueChangeFinished = {
                exoPlayer.seekTo(currentPositionMs.coerceIn(0L, totalDurationMs))
                isSeeking = false
              },
              valueRange = 0f..totalDurationMs.toFloat(),
              colors = SliderDefaults.colors(
                thumbColor = Color.Red,
                activeTrackColor = Color.Red,
                inactiveTrackColor = Color.White.copy(alpha = 0.35f)
              ),
              modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
          }
          Row(
            Modifier
              .fillMaxWidth()
              .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (source == "live") {
              ControlIcon(Icons.Default.KeyboardArrowUp, "قناة+") { channelUp() }
              ControlIcon(Icons.Default.KeyboardArrowDown, "قناة-") { channelDown() }
            }
            ControlIcon(Icons.Default.AspectRatio, "العرض") { showAspectDialog = true }
            ControlIcon(Icons.Default.Audiotrack, "الصوت") {
              if (audioTracks.isNotEmpty()) showAudioDialog = true
            }
            ControlIcon(Icons.Default.ClosedCaption, "ترجمة") {
              if (subtitleTracks.isNotEmpty()) showSubtitleDialog = true
            }
            ControlIcon(
              if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              "تشغيل"
            ) {
              if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
            }
            ControlIcon(
              if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
              if (isFullscreen) "خروج ملء الشاشة" else "ملء الشاشة"
            ) {
              isFullscreen = !isFullscreen
            }
            ControlIcon(Icons.Default.Refresh, "تحديث") {
              errorMessage = null
              loadStream(activeUrl)
            }
          }
        }
      }
    }

    // Dialogs
    if (showAudioDialog) {
      TrackDialog("مسارات الصوت", audioTracks) { showAudioDialog = false }
    }
    if (showSubtitleDialog) {
      TrackDialog("الترجمة", subtitleTracks) { showSubtitleDialog = false }
    }
    if (showAspectDialog) {
      AlertDialog(
        onDismissRequest = { showAspectDialog = false },
        title = { Text("نسبة العرض", color = TextPrimary) },
        text = {
          Column {
            listOf(
              "ملائمة الشاشة" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
              "ملء الشاشة" to AspectRatioFrameLayout.RESIZE_MODE_FILL,
              "تكبير" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
              "عرض ثابت" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
            ).forEach { (label, mode) ->
              TextButton(
                onClick = { resizeMode = mode; showAspectDialog = false },
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  if (mode == resizeMode) "✓ $label" else label,
                  color = if (mode == resizeMode) GoldPrimary else TextPrimary
                )
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { showAspectDialog = false }) {
            Text("إغلاق", color = GoldPrimary)
          }
        },
        containerColor = Color(0xFF1A1A1A)
      )
    }
  }
}

@Composable
private fun ControlIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
  IconButton(onClick = onClick) {
    Icon(icon, desc, tint = Color.White, modifier = Modifier.size(26.dp))
  }
}

@Composable
private fun HintChip(text: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    color = Color.Black.copy(0.65f),
    shape = RoundedCornerShape(20.dp)
  ) {
    Text(
      text,
      color = Color.White,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
      style = MaterialTheme.typography.labelLarge
    )
  }
}

@Composable
private fun TrackDialog(
  title: String,
  tracks: List<Pair<String, () -> Unit>>,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title, color = TextPrimary) },
    text = {
      if (tracks.isEmpty()) {
        Text("لا توجد مسارات", color = Color.Gray)
      } else {
        LazyColumn {
          itemsIndexed(tracks) { _, item ->
            TextButton(
              onClick = { item.second(); onDismiss() },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(item.first, color = TextPrimary)
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("إغلاق", color = GoldPrimary) }
    },
    containerColor = Color(0xFF1A1A1A)
  )
}

@OptIn(UnstableApi::class)
private fun qualityLabel(f: Format): String {
  val h = f.height
  return when {
    h >= 2160 -> "4K"
    h >= 1440 -> "1440p"
    h >= 1080 -> "1080p"
    h >= 720 -> "720p"
    h >= 480 -> "480p"
    h > 0 -> "${h}p"
    f.bitrate > 0 -> "${f.bitrate / 1000} kbps"
    else -> f.sampleMimeType ?: "Auto"
  }
}

private fun trackLabel(f: Format, fallback: String): String {
  val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }
  val label = f.label?.takeIf { it.isNotBlank() }
  return listOfNotNull(label, lang, f.sampleMimeType?.substringAfter('/')).joinToString(" • ")
    .ifBlank { fallback }
}

private fun friendlyError(error: PlaybackException): String =
  when (error.errorCode) {
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
      "مشكلة شبكة أو السيرفر لا يستجيب"
    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
      "السيرفر رفض البث (قناة متوقفة أو تحتاج VPN)"
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
    PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ->
      "صيغة البث غير مدعومة أو الرابط تالف"
    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
    PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ->
      "تعذر فك الترميز على هذا الجهاز — جرب قناة أخرى"
    else -> error.message ?: "خطأ غير معروف (${error.errorCode})"
  }

private fun formatResumeTime(milliseconds: Long): String {
  val totalSeconds = (milliseconds / 1_000L).coerceAtLeast(0L)
  val hours = totalSeconds / 3_600L
  val minutes = (totalSeconds % 3_600L) / 60L
  val seconds = totalSeconds % 60L
  return if (hours > 0L) String.format("%d:%02d:%02d", hours, minutes, seconds)
  else String.format("%d:%02d", minutes, seconds)
}
