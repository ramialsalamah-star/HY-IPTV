package com.hyiptv.player.util

import android.content.Context
import com.hyiptv.player.data.model.Playlist
import com.hyiptv.player.data.repository.PlaylistRepository
import kotlinx.coroutines.flow.Flow

/** Playlist lifecycle facade. Playlist metadata is persisted by DataStore. */
class PlaylistManager(context: Context) {
  private val repository = PlaylistRepository(context.applicationContext)

  val playlists: Flow<List<Playlist>> get() = repository.playlistsFlow

  suspend fun getPlaylists(): List<Playlist> = repository.getPlaylists()

  suspend fun save(playlist: Playlist) = repository.savePlaylist(playlist)

  suspend fun delete(playlistId: String) = repository.deletePlaylist(playlistId)

  suspend fun activate(playlistId: String) = repository.activatePlaylist(playlistId)

  suspend fun rename(playlistId: String, name: String) = repository.renamePlaylist(playlistId, name)
}
