package com.hyiptv.player.ui.screens.vpn

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyiptv.player.data.vpn.RealVpnHelper
import com.hyiptv.player.data.vpn.VpnRepository
import com.hyiptv.player.ui.theme.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnScreen(onBack: () -> Unit) {
  val context = LocalContext.current
  val repo = remember { VpnRepository(context) }
  val realHelper = remember { RealVpnHelper(context) }
  var currentFile by remember { mutableStateOf(repo.getSavedVpnFile()) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }
  var remoteInfo by remember { mutableStateOf(currentFile?.let { repo.parseRemoteInfo(it) } ?: "لا يوجد ملف VPN مستورد") }
  var foundFiles by remember { mutableStateOf(listOf<File>()) }
  var isRunning by remember { mutableStateOf(RealVpnHelper.isRunning || EmbeddedVpnHelper.isRunning) }
  var internalInfo by remember { mutableStateOf(repo.getInternalFileInfo()) }

  fun refresh() {
    currentFile = repo.getSavedVpnFile()
    remoteInfo = currentFile?.let { repo.parseRemoteInfo(it) } ?: "لا يوجد ملف VPN مستورد"
    foundFiles = try { repo.scanForVpnFiles() } catch (_: Exception) { emptyList() }
    isRunning = realHelper.isVpnRunning()
    internalInfo = repo.getInternalFileInfo()
    if (isRunning && com.hyiptv.player.data.vpn.NativeVpnService.currentServerInfo.isNotBlank()) {
      remoteInfo = com.hyiptv.player.data.vpn.NativeVpnService.currentServerInfo
    }
  }

  LaunchedEffect(Unit) { refresh() }

  var pendingFileForVpn by remember { mutableStateOf<File?>(null) }
  
  val vpnPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == android.app.Activity.RESULT_OK) {
      pendingFileForVpn?.let { file ->
        val ok = try { realHelper.startRealVpn(file.absolutePath) } catch (_: Exception) { false }
        isRunning = ok
        message = if (ok) "✓ تم بدء اتصال VPN: ${repo.parseRemoteInfo(file)}" else "✗ فشل التشغيل - حاول مرة أخرى"
        isError = !ok
        refresh()
      }
    } else {
      message = "يجب الموافقة على إذن VPN - الإذن مطلوب للاتصال"
      isError = true
    }
    pendingFileForVpn = null
  }

  // Android 9 TV Box: OpenDocument مع حماية من الكراش
  val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
    try {
      if (uri == null) {
        message = "لم يتم اختيار ملف"
        isError = true
        return@rememberLauncherForActivityResult
      }
      try { 
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) 
      } catch (_: Exception) {}
      if (isRunning) {
        realHelper.stopRealVpn()
        isRunning = false
      }
      val res = repo.saveVpnFromUri(uri)
      res.onSuccess { 
        refresh()
        message = "✓ تم الحفظ والاستيراد من الفلاش/التخزين: ${it.name} - ${repo.parseRemoteInfo(it)}"
        isError = false
        internalInfo = repo.getInternalFileInfo()
      }
      res.onFailure { 
        message = "✗ فشل الاستيراد: ${it.message}"
        isError = true 
      }
    } catch (e: Exception) {
      message = "✗ خطأ: ${e.message}"
      isError = true
    }
  }
  
  // احتياطي لأندرويد 9 TV Box: GetContent أكثر توافقاً
  val pickerFallback = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
    try {
      if (uri == null) {
        message = "لم يتم اختيار ملف"
        isError = true
        return@rememberLauncherForActivityResult
      }
      val res = repo.saveVpnFromUri(uri)
      res.onSuccess { 
        refresh()
        message = "✓ تم الحفظ والاستيراد من الفلاش/التخزين: ${it.name} - ${repo.parseRemoteInfo(it)}"
        isError = false
        internalInfo = repo.getInternalFileInfo()
      }
      res.onFailure { 
        message = "✗ فشل الاستيراد: ${it.message}"
        isError = true 
      }
    } catch (e: Exception) {
      message = "✗ خطأ: ${e.message}"
      isError = true
    }
  }
  
  val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
    refresh()
    message = "تم طلب الصلاحيات - حاول مرة أخرى"
    isError = false
  }

  Column(
    Modifier
      .fillMaxSize()
      .background(BlackBackground)
      .verticalScroll(rememberScrollState())
  ) {
    TopAppBar(
      title = { 
        Column {
          Text("VPN مدمج 100% - fr1.vpnjantit.com", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Text("بدون تطبيق ثاني - استيراد من الفلاش والداخلي", color = TextSecondary, fontSize = 11.sp)
        }
      },
      navigationIcon = { 
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = BlackBackground)
    )
    
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      
      // حالة الاتصال
      Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (isRunning) CardBackground.copy(alpha = 0.8f) else CharcoalSurface),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
              if (isRunning) Icons.Default.CheckCircle else Icons.Default.Info,
              null,
              tint = if (isRunning) SuccessGreen else GoldPrimary,
              modifier = Modifier.size(24.dp)
            )
            Text(
              if (isRunning) "متصل - VPN يعمل" else "غير متصل - VPN متوقف",
              color = if (isRunning) SuccessGreen else GoldPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
          }
          Text("الخادم: $remoteInfo", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          Text("الملف الداخلي: $internalInfo", color = TextSecondary, fontSize = 11.sp)
          if (currentFile != null) {
            Text("المسار: ${currentFile!!.absolutePath}", color = TextSecondary, fontSize = 10.sp)
          }
        }
      }

      // أزرار التشغيل
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
          onClick = {
            val file = currentFile ?: repo.getSavedVpnFile()
            if (file == null) {
              message = "لا يوجد ملف VPN - استورد ملف .ovpn أولاً"
              isError = true
              return@Button
            }
            if (isRunning) {
              realHelper.stopRealVpn()
              isRunning = false
              message = "تم إيقاف VPN"
              isError = false
            } else {
              val prepareIntent = try {
                android.net.VpnService.prepare(context)
              } catch (_: Exception) { null }
              if (prepareIntent != null) {
                pendingFileForVpn = file
                try {
                  vpnPermissionLauncher.launch(prepareIntent)
                } catch (e: Exception) {
                  message = "خطأ في طلب إذن VPN: ${e.message}"
                  isError = true
                }
              } else {
                val ok = try { realHelper.startRealVpn(file.absolutePath) } catch (_: Exception) { false }
                isRunning = ok
                message = if (ok) "✓ تم التشغيل - ${repo.parseRemoteInfo(file)}" else "✗ فشل التشغيل"
                isError = !ok
              }
            }
            refresh()
          },
          modifier = Modifier.weight(1f).height(52.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isRunning) Color(0xFFB71C1C) else SuccessGreen,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow, null)
          Spacer(Modifier.width(6.dp))
          Text(if (isRunning) "إيقاف VPN" else "تشغيل VPN", fontWeight = FontWeight.Bold)
        }
        
        Button(
          onClick = { refresh() },
          modifier = Modifier.weight(0.5f).height(52.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CharcoalSurface, contentColor = GoldPrimary),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Refresh, null)
          Spacer(Modifier.width(4.dp))
          Text("تحديث")
        }
      }

      // 3 أزرار الاستيراد الرئيسية - الفلاش والداخلي والمضمن
      Text("استيراد ملف VPN جديد:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
      
      // زر 1: من الفلاشة
      Button(
        onClick = { 
          // طلب صلاحيات أولاً على أندرويد 11+
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
              if (!Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                  data = android.net.Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
                message = "فعل صلاحية الوصول لكل الملفات ثم عد"
                isError = false
                return@Button
              }
            } catch (_: Exception) {}
          }
          try {
          picker.launch(arrayOf("*/*"))
        } catch (e: Exception) {
          try {
            pickerFallback.launch("*/*")
          } catch (e2: Exception) {
            message = "✗ لا يوجد مدير ملفات - ضع ملف .ovpn في مجلد Download ثم اضغط 'فحص التخزين'"
            isError = true
            // حاول فحص التخزين تلقائياً
            foundFiles = try { repo.scanForVpnFiles() } catch (_: Exception) { emptyList() }
          }
        } 
        },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BlackBackground),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Usb, null)
        Spacer(Modifier.width(8.dp))
        Text("1- من الفلاشة USB / التخزين (اختر ملف .ovpn)", fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
      }
      
      // زر 2: من التخزين الداخلي (فحص تلقائي)
      Button(
        onClick = { 
          foundFiles = try { repo.scanForVpnFiles() } catch (_: Exception) { emptyList() }
          if (foundFiles.isEmpty()) {
            message = "لم يتم العثور على ملفات .ovpn في Download أو الفلاشة - ضع الملف في مجلد Download"
            isError = true
          } else {
            message = "تم العثور على ${foundFiles.size} ملف - اختر من القائمة أدناه"
            isError = false
          }
        },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5), contentColor = Color.White),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Folder, null)
        Spacer(Modifier.width(8.dp))
        Text("2- فحص التخزين الداخلي والفلاشة (Download)", fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
      }
      
      // Active imported profile and removal
      Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("ملف VPN الحالي", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text(currentFile?.name ?: "لم يتم استيراد ملف بعد", color = TextPrimary, fontSize = 12.sp)
          Text(internalInfo, color = TextSecondary, fontSize = 11.sp)
          OutlinedButton(
            onClick = {
              if (isRunning) realHelper.stopRealVpn()
              repo.deleteCurrent()
              refresh()
              message = "تم حذف ملف VPN الحالي. يمكنك استيراد ملف جديد."
              isError = false
            },
            enabled = currentFile != null,
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Delete, null)
            Spacer(Modifier.width(6.dp))
            Text("حذف ملف VPN الحالي")
          }
        }
      }

      // قائمة الملفات الموجودة
      if (foundFiles.isNotEmpty()) {
        Card(
          Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = CardBackground),
          shape = RoundedCornerShape(16.dp)
        ) {
          Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ملفات VPN موجودة في الجهاز (${foundFiles.size}) - اضغط للاستيراد:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            foundFiles.take(10).forEach { file ->
              Card(
                Modifier
                  .fillMaxWidth()
                  .clickable {
                    try {
                      if (isRunning) {
                        realHelper.stopRealVpn()
                        isRunning = false
                      }
                      val res = repo.saveVpnFromFile(file)
                      if (res.isSuccess) {
                        refresh()
                        message = "✓ تم استيراد من ${file.name}: ${repo.parseRemoteInfo(res.getOrNull()!!)}"
                        isError = false
                      } else {
                        message = "✗ فشل الاستيراد: ${res.exceptionOrNull()?.message}"
                        isError = true
                      }
                    } catch (e: Exception) {
                      message = "✗ خطأ: ${e.message}"
                      isError = true
                    }
                  }
                  .border(1.dp, DividerColor, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp)
              ) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Icon(Icons.Default.Description, null, tint = GoldAccent, modifier = Modifier.size(20.dp))
                  Column(Modifier.weight(1f)) {
                    Text(file.name, color = TextPrimary, maxLines = 1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(file.parent ?: "", color = TextSecondary, maxLines = 1, fontSize = 9.sp)
                  }
                  Icon(Icons.Default.Download, null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                }
              }
            }
          }
        }
      } else {
        Card(
          Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = CardBackground.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.SearchOff, null, tint = TextSecondary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(6.dp))
            Text("لم يتم العثور على ملفات .ovpn", color = TextSecondary, fontSize = 12.sp)
            Text("ضع ملف .ovpn الجديد في مجلد Download أو في فلاشة USB ثم اضغط 'فحص التخزين'", color = TextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center)
          }
        }
      }

      // رسالة الحالة
      message?.let { msg ->
        Card(
          Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = if (isError) Color(0xFF4A1A1A) else Color(0xFF1A4A1A)),
          shape = RoundedCornerShape(12.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isError) Color.Red else SuccessGreen)
        ) {
          Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
              if (isError) Icons.Default.Error else Icons.Default.CheckCircle,
              null,
              tint = if (isError) Color.Red else SuccessGreen,
              modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(msg, color = Color.White, fontSize = 12.sp)
          }
        }
      }
      
      Spacer(Modifier.height(16.dp))
      Text(
        "ملاحظة: استورد ملف .ovpn الجديد من الموقع أو USB. سيحل الملف الجديد محل الملف السابق، ويمكنك حذفه ثم استيراد ملف آخر.",
        color = TextSecondary,
        fontSize = 10.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
      )
    }
  }
}
