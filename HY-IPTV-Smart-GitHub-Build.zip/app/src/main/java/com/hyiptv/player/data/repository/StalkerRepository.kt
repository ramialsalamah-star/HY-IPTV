package com.hyiptv.player.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hyiptv.player.data.model.StalkerProfile
import com.hyiptv.player.data.remote.StalkerApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

private val Context.stalkerDataStore: DataStore<Preferences> by preferencesDataStore(name = "stalker_profiles")

class StalkerRepository(private val context: Context) {

  private val gson = Gson()
  private val PROFILES_KEY = stringPreferencesKey("stalker_profiles")
  private val api = StalkerApi()
  private val channelRepo = ChannelRepository(context)

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _error = MutableStateFlow<String?>(null)
  val error: StateFlow<String?> = _error.asStateFlow()

  val profilesFlow: Flow<List<StalkerProfile>> = context.stalkerDataStore.data.map { prefs ->
    val json = prefs[PROFILES_KEY] ?: "[]"
    try {
      val type = object : TypeToken<List<StalkerProfile>>() {}.type
      gson.fromJson<List<StalkerProfile>>(json, type) ?: emptyList()
    } catch (e: Exception) {
      emptyList()
    }
  }

  suspend fun getProfiles(): List<StalkerProfile> = profilesFlow.first()

  suspend fun saveProfile(profile: StalkerProfile) {
    val current = getProfiles().toMutableList()
    val index = current.indexOfFirst { it.id == profile.id }
    if (index >= 0) current[index] = profile else current.add(profile)
    context.stalkerDataStore.edit { prefs ->
      prefs[PROFILES_KEY] = gson.toJson(current)
    }
  }

  suspend fun deleteProfile(id: String) {
    val current = getProfiles().filterNot { it.id == id }
    context.stalkerDataStore.edit { prefs ->
      prefs[PROFILES_KEY] = gson.toJson(current)
    }
    channelRepo.removeSource("stalker_$id")
    if (current.isEmpty()) channelRepo.removeSource("stalker")
  }

  fun generateMac(deviceId: String): String = api.generateMacFromDeviceId(deviceId)

  suspend fun connectAndLoad(profile: StalkerProfile): Result<Int> {
    _isLoading.value = true
    _error.value = null
    return try {
      val handshake = api.handshake(profile.portalUrl, profile.macAddress)
      if (handshake.isFailure) {
        val err = handshake.exceptionOrNull()?.message ?: "Handshake failed"
        _error.value = err
        return Result.failure(Exception(err))
      }
      val token = handshake.getOrThrow()
      val channelsResult = api.getLiveChannels(profile.portalUrl, profile.macAddress, token)
      channelsResult.fold(
        onSuccess = { list ->
          val namespaced = list.map { channel ->
            channel.copy(id = "stalker_${profile.id}_${channel.id}", contentType = "live")
          }
          val count = channelRepo.replaceChannels(namespaced, sourceType = "stalker_${profile.id}")
          Result.success(count)
        },
        onFailure = { e ->
          _error.value = e.message
          Result.failure(e)
        }
      )
    } catch (e: Exception) {
      _error.value = e.message
      Result.failure(e)
    } finally {
      _isLoading.value = false
    }
  }

  suspend fun resolvePlaybackUrl(url: String): String = withContext(Dispatchers.IO) {
    if (!api.needsResolve(url)) return@withContext url
    val profiles = getProfiles()
    if (profiles.isEmpty()) return@withContext url
    val hostHint = url.substringAfter("://").substringBefore("/")
    val profile = profiles.firstOrNull { profile ->
      profile.portalUrl.substringAfter("://").substringBefore("/").equals(hostHint, true)
    } ?: profiles.last()
    val token = api.handshake(profile.portalUrl, profile.macAddress).getOrNull() ?: return@withContext url
    api.createLink(profile.portalUrl, profile.macAddress, token, api.commandFromStoredUrl(url)) ?: url
  }

  fun clearError() {
    _error.value = null
  }

  fun createProfile(name: String, mac: String, portalUrl: String): StalkerProfile {
    return StalkerProfile(
      id = UUID.randomUUID().toString(),
      name = name.ifBlank { "Stalker User" },
      macAddress = mac.trim().uppercase().replace('-', ':'),
      portalUrl = portalUrl.trim()
    )
  }
}
