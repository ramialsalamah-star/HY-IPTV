package com.hyiptv.player.player

import android.content.Context
import com.hyiptv.player.data.repository.StalkerRepository

object StreamUrlResolver {
  suspend fun resolve(context: Context, url: String): String {
    if (!looksLikePortalCommand(url)) return url
    return runCatching { StalkerRepository(context).resolvePlaybackUrl(url) }
      .getOrNull()
      ?.takeIf { it.isNotBlank() }
      ?: url
  }

  fun looksLikePortalCommand(url: String): Boolean {
    val value = url.trim().lowercase()
    return value.contains("portal.php") ||
      value.contains("action=create_link") ||
      value.startsWith("ffmpeg ") ||
      value.startsWith("ffrt ") ||
      value.startsWith("auto ")
  }
}
