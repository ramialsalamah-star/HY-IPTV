package com.hyiptv.player.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChannelDao {

  @Query("SELECT COUNT(*) FROM channels")
  suspend fun getChannelCount(): Int

  @Query("SELECT COUNT(*) FROM channels WHERE contentType = :type")
  suspend fun getCountByType(type: String): Int

  @Query("SELECT * FROM channels WHERE contentType = :type ORDER BY name ASC LIMIT :limit OFFSET :offset")
  suspend fun getByTypePaged(type: String, limit: Int, offset: Int): List<ChannelEntity>

  @Query("SELECT * FROM channels ORDER BY name ASC LIMIT :limit OFFSET :offset")
  suspend fun getChannelsPaged(limit: Int, offset: Int): List<ChannelEntity>

  @Query("SELECT * FROM channels WHERE contentType = 'live' AND groupName = :group ORDER BY CASE WHEN name GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, name COLLATE NOCASE ASC LIMIT :limit OFFSET :offset")
  suspend fun getLiveByGroupPaged(group: String, limit: Int, offset: Int): List<ChannelEntity>

  @Query("SELECT * FROM channels WHERE contentType = 'live' ORDER BY CASE WHEN name GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, name COLLATE NOCASE ASC LIMIT :limit OFFSET :offset")
  suspend fun getLivePaged(limit: Int, offset: Int): List<ChannelEntity>

  @Query("""
    SELECT * FROM channels 
    WHERE contentType = :type AND (name LIKE '%' || :query || '%' OR groupName LIKE '%' || :query || '%')
    ORDER BY name ASC LIMIT :limit OFFSET :offset
  """)
  suspend fun searchByType(type: String, query: String, limit: Int, offset: Int): List<ChannelEntity>

  @Query("""
    SELECT * FROM channels 
    WHERE contentType = 'live' AND (name LIKE '%' || :query || '%' OR groupName LIKE '%' || :query || '%')
    ORDER BY CASE WHEN name GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, name COLLATE NOCASE ASC LIMIT :limit OFFSET :offset
  """)
  suspend fun searchLive(query: String, limit: Int, offset: Int): List<ChannelEntity>

  @Query("""
    SELECT * FROM channels 
    WHERE name LIKE '%' || :query || '%' OR groupName LIKE '%' || :query || '%'
    ORDER BY 
      CASE contentType WHEN 'live' THEN 0 WHEN 'movie' THEN 1 ELSE 2 END,
      name ASC
    LIMIT :limit OFFSET :offset
  """)
  suspend fun searchAll(query: String, limit: Int, offset: Int): List<ChannelEntity>

  @Query("""
    SELECT COUNT(*) FROM channels 
    WHERE name LIKE '%' || :query || '%' OR groupName LIKE '%' || :query || '%'
  """)
  suspend fun countSearch(query: String): Int

  @Query("SELECT DISTINCT groupName FROM channels WHERE contentType = 'live' ORDER BY CASE WHEN groupName GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, groupName COLLATE NOCASE ASC")
  suspend fun getLiveGroups(): List<String>

  @Query("SELECT groupName AS name, COUNT(*) AS count FROM channels WHERE contentType = :type GROUP BY groupName ORDER BY CASE WHEN groupName GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, groupName COLLATE NOCASE ASC")
  suspend fun getGroupCounts(type: String): List<GroupCount>

  @Query("SELECT COUNT(*) FROM channels WHERE contentType = :type")
  suspend fun countType(type: String): Int

  @Query("SELECT DISTINCT groupName FROM channels WHERE contentType = :type ORDER BY CASE WHEN groupName GLOB '*[ء-ي]*' THEN 0 ELSE 1 END, groupName COLLATE NOCASE ASC")
  suspend fun getGroupsByType(type: String): List<String>

  @Query("SELECT * FROM channels WHERE isFavorite = 1 ORDER BY name ASC")
  fun getFavoritesFlow(): Flow<List<ChannelEntity>>

  @Query("SELECT * FROM channels WHERE isFavorite = 1 ORDER BY name ASC")
  suspend fun getFavorites(): List<ChannelEntity>

  @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
  suspend fun getChannelById(id: String): ChannelEntity?

  @Query("SELECT * FROM channels WHERE streamUrl = :url LIMIT 1")
  suspend fun getByStreamUrl(url: String): ChannelEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChannels(channels: List<ChannelEntity>)

  @Query("UPDATE channels SET isFavorite = :favorite WHERE id = :id")
  suspend fun setFavorite(id: String, favorite: Boolean)

  @Query("UPDATE channels SET lastWatched = :timestamp WHERE id = :id")
  suspend fun updateLastWatched(id: String, timestamp: Long)

  @Query("DELETE FROM channels")
  suspend fun clearAllChannels()

  @Query("DELETE FROM favorites")
  suspend fun clearFavorites()

  @Query("DELETE FROM recent")
  suspend fun clearRecent()

  @Query("DELETE FROM channels WHERE sourceType = :sourceType")
  suspend fun clearBySource(sourceType: String)

  @Query("DELETE FROM channels WHERE sourceType LIKE 'playlist_%' OR sourceType IN ('m3u', 'xtream')")
  suspend fun clearPlaylistSources()

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFavorite(fav: FavoriteEntity)

  @Query("DELETE FROM favorites WHERE channelId = :channelId")
  suspend fun removeFavorite(channelId: String)

  @Query("SELECT channelId FROM favorites")
  suspend fun getFavoriteIds(): List<String>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRecent(recent: RecentEntity)

  @Query("SELECT * FROM recent ORDER BY watchedAt DESC LIMIT :limit")
  suspend fun getRecent(limit: Int = 50): List<RecentEntity>
}
