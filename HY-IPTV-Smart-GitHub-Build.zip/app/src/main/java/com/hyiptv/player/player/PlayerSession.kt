package com.hyiptv.player.player

import com.hyiptv.player.data.model.Channel

data class PlayRequest(
  val mediaId: String,
  val title: String,
  val streamUrl: String
)

/**
 * Holds the current channel list so the player can zap up/down with remote.
 * Also carries the item to open so the stream URL is not put in the navigation route.
 */
object PlayerSession {
  @Volatile
  var channels: List<Channel> = emptyList()
    private set

  @Volatile
  var index: Int = 0
    private set

  @Volatile
  var request: PlayRequest? = null
    private set

  fun open(channel: Channel) {
    ensureListed(channel)
    request = PlayRequest(channel.id, channel.name, channel.streamUrl)
  }

  fun openUrl(streamUrl: String, title: String) {
    val channel = Channel(
      id = streamUrl,
      name = title.ifBlank { "قناة" },
      streamUrl = streamUrl
    )
    open(channel)
  }

  fun setPlaylist(list: List<Channel>, current: Channel) {
    channels = list
    index = list.indexOfFirst { it.id == current.id || it.streamUrl == current.streamUrl }
      .let { if (it >= 0) it else 0 }
    request = PlayRequest(current.id, current.name, current.streamUrl)
  }

  fun setPlaylist(list: List<Channel>, startIndex: Int) {
    channels = list
    index = startIndex.coerceIn(0, (list.size - 1).coerceAtLeast(0))
    current()?.let { request = PlayRequest(it.id, it.name, it.streamUrl) }
  }

  fun ensureListed(channel: Channel) {
    val existing = channels.indexOfFirst { it.id == channel.id || it.streamUrl == channel.streamUrl }
    if (existing >= 0) {
      index = existing
    } else {
      channels = listOf(channel)
      index = 0
    }
  }

  fun current(): Channel? = channels.getOrNull(index)

  fun next(): Channel? {
    if (channels.isEmpty()) return null
    index = (index + 1) % channels.size
    return channels[index]
  }

  fun previous(): Channel? {
    if (channels.isEmpty()) return null
    index = if (index <= 0) channels.lastIndex else index - 1
    return channels[index]
  }

  fun clear() {
    channels = emptyList()
    index = 0
    request = null
  }
}
