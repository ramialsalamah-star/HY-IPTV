package com.hyiptv.player.data.vpn

import android.content.Context
import android.content.Intent
import java.io.File

class EmbeddedVpnHelper(private val context: Context) {

  companion object {
    var isRunning: Boolean = false
      private set
  }

  fun startVpnFromFile(file: File): Boolean {
    return try {
      // حاول الحقيقي أولاً
      try {
        val realHelper = RealVpnHelper(context)
        val realResult = realHelper.startRealVpn(file.absolutePath)
        if (realResult) {
          isRunning = true
          return true
        }
      } catch (e: Exception) {
        e.printStackTrace()
      }
      
      // احتياطي: NativeVpnService
      val intent = Intent(context, NativeVpnService::class.java).apply {
        action = NativeVpnService.ACTION_START
        putExtra(NativeVpnService.EXTRA_CONFIG_PATH, file.absolutePath)
      }
      try {
        context.startService(intent)
      } catch (e: Exception) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
          try {
            context.startForegroundService(intent)
          } catch (_: Exception) {
            return false
          }
        } else {
          return false
        }
      }
      Thread.sleep(500)
      isRunning = true
      true
    } catch (e: Exception) {
      e.printStackTrace()
      false
    }
  }

  fun startVpnFromAssets(): Boolean {
    return try {
      val repo = VpnRepository(context)
      val file = repo.ensureInternalVpnExists() ?: repo.saveVpnFromAssets() ?: return false
      startVpnFromFile(file)
    } catch (_: Exception) {
      false
    }
  }

  fun stopVpn() {
    try {
      try {
        val realHelper = RealVpnHelper(context)
        realHelper.stopRealVpn()
      } catch (_: Exception) {}
      
      val intent = Intent(context, NativeVpnService::class.java).apply {
        action = NativeVpnService.ACTION_STOP
      }
      try {
        context.startService(intent)
      } catch (_: Exception) {}
      isRunning = false
    } catch (_: Exception) {
      isRunning = false
    }
  }
}
