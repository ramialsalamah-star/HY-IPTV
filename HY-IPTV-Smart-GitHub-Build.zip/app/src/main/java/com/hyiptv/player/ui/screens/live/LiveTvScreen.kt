@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.media3.common.util.UnstableApi::class)

package com.hyiptv.player.ui.screens.live

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import com.hyiptv.player.player.PlayerFactory
import coil.compose.AsyncImage
import com.hyiptv.player.R
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.player.PlayerSession
import com.hyiptv.player.util.GroupLockManager
import com.hyiptv.player.util.LiveTvStateManager
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.launch

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun LiveTvScreen(
  onBack: () -> Unit,
  onPlayChannel: (Channel) -> Unit = {}
) {
  val context = LocalContext.current
    var longPressFavMessage by remember { mutableStateOf<String?>(null) }
    val hapticFeedback = LocalHapticFeedback.current
  val repository = remember { ChannelRepository(context) }
  val scope = rememberCoroutineScope()
  val listState = rememberLazyListState()
  val keyboardController = LocalSoftwareKeyboardController.current
  val firstChannelFocus = remember { FocusRequester() }
  val searchFocusRequester = remember { FocusRequester() }
  val liveTvStateManager = remember { LiveTvStateManager(context) }

  var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var groupInfos by remember { mutableStateOf<List<ChannelRepository.GroupInfo>>(emptyList()) }
  var totalCount by remember { mutableStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var groupSort by rememberSaveable { mutableStateOf("az") }
  var selectedGroup by rememberSaveable { mutableStateOf(liveTvStateManager.getLastGroup() ?: "ALL") }
  var selectedChannelId by rememberSaveable { mutableStateOf(liveTvStateManager.getLastChannelId()) }
  var pinDialogGroup by remember { mutableStateOf<String?>(null) }
  var pendingUnlockChannelId by remember { mutableStateOf<String?>(null) }
  var currentPage by remember { mutableStateOf(0) }
  var isLoading by remember { mutableStateOf(true) }
  var isLoadingMore by remember { mutableStateOf(false) }
  var endReached by remember { mutableStateOf(false) }
  var isSearchActive by remember { mutableStateOf(false) }
  var showFavoritesOnly by rememberSaveable { mutableStateOf(false) }
  var favorites by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var lastChannel by remember { mutableStateOf<Channel?>(null) }
  var previewChannel by remember { mutableStateOf<Channel?>(null) }
  val previewPlayer = remember { PlayerFactory.createPlayer(context).apply { volume = 0f; playWhenReady = true } }
  val lockManager = remember { GroupLockManager(context) }
  DisposableEffect(lockManager) { onDispose { lockManager.clearSession() } }
  var longPressGroup by remember { mutableStateOf<String?>(null) }
  var longPressChannel by remember { mutableStateOf<Channel?>(null) }
  var pinInput by remember { mutableStateOf("") }
  var pinError by remember { mutableStateOf(false) }
  var showSetPin by remember { mutableStateOf(false) }
  var pendingLockGroup by remember { mutableStateOf<String?>(null) }
  var pendingUnlockGroup by remember { mutableStateOf<String?>(null) }
  var newPin by remember { mutableStateOf("") }
  var lockManageMode by remember { mutableStateOf(false) }
  var activateLockModeAfterPin by remember { mutableStateOf(false) }
  var unlockManageModeRequest by remember { mutableStateOf(false) }
  var pendingToggleGroupAfterPin by remember { mutableStateOf<String?>(null) }
  var groupsCollapsed by remember { mutableStateOf(false) }

  // Consume Android system Back and TV-remote Back consistently on every
  // Live TV list state. Search is dismissed first; otherwise return Home.
  BackHandler {
    if (isSearchActive) {
      isSearchActive = false
      searchQuery = ""
      keyboardController?.hide()
    } else {
      onBack()
    }
  }

  fun persistGroupOrder(list: List<ChannelRepository.GroupInfo>) {
    context.getSharedPreferences("live_group_order", android.content.Context.MODE_PRIVATE)
      .edit().putString("order", list.map { it.name }.joinToString("\u001F")).apply()
  }


  fun moveGroupToTop(groupName: String) {
    val current = groupInfos.toMutableList()
    val from = current.indexOfFirst { it.name == groupName }
    if (from <= 0) return
    if (groupName == "ALL" || groupName == "Favorites") return
    val item = current.removeAt(from)
    // Insert after pinned items
    val pinnedCount = current.count { it.name == "ALL" || it.name == "Favorites" }
    current.add(pinnedCount, item)
    groupInfos = current
    persistGroupOrder(current)
  }

  fun moveGroupToBottom(groupName: String) {
    val current = groupInfos.toMutableList()
    val from = current.indexOfFirst { it.name == groupName }
    if (from < 0 || from == current.lastIndex) return
    if (groupName == "ALL" || groupName == "Favorites") return
    val item = current.removeAt(from)
    current.add(item)
    groupInfos = current
    persistGroupOrder(current)
  }

  fun moveChannel(channelId: String, direction: Int) {
    val current = channels.toMutableList()
    val from = current.indexOfFirst { it.id == channelId }
    val to = from + direction
    if (from < 0 || to !in current.indices) return
    val item = current.removeAt(from)
    current.add(to, item)
    channels = current
  }

  fun moveChannelToTop(channelId: String) {
    val current = channels.toMutableList()
    val from = current.indexOfFirst { it.id == channelId }
    if (from <= 0) return
    val item = current.removeAt(from)
    current.add(0, item)
    channels = current
  }

  fun moveChannelToBottom(channelId: String) {
    val current = channels.toMutableList()
    val from = current.indexOfFirst { it.id == channelId }
    if (from < 0 || from == current.lastIndex) return
    val item = current.removeAt(from)
    current.add(item)
    channels = current
  }


  fun moveGroup(groupName: String, direction: Int) {
    val current = groupInfos.toMutableList()
    val from = current.indexOfFirst { it.name == groupName }
    val to = from + direction
    if (from < 0 || to !in current.indices) return
    if (current[from].name == "ALL" || current[from].name == "Favorites" || current[to].name == "ALL" || current[to].name == "Favorites") return
    val item = current.removeAt(from)
    current.add(to, item)
    groupInfos = current
    persistGroupOrder(current)
    // Keep the management dialog open so the user can move the same group repeatedly.
  }

  // Locked live-TV groups are hidden everywhere in this screen, including
  // ALL, search results, favorites and the continue-watching shortcut.
  fun hideLockedGroupChannels(items: List<Channel>): List<Channel> =
    items.filter { channel ->
      // FIX: Only hide live TV groups, keep movies/series always visible
      // Individually locked channels remain visible; only locked groups are hidden.
      if (channel.contentType == "live") {
        !lockManager.isGroupLocked(channel.group)
      } else {
        true
      }
    }

  fun loadFirstPage() {
    // A locked group must never load channel data until the PIN is verified.
    if (selectedGroup != "ALL" && selectedGroup != "Favorites" && lockManager.isGroupLocked(selectedGroup)) {
      channels = emptyList()
      previewChannel = null
      isLoading = false
      endReached = true
      currentPage = 0
      return
    }
    scope.launch {
      isLoading = true
      endReached = false
      currentPage = 0
      groupInfos = repository.getGroupInfos("live").let { list ->
        // Keep the built-in All and Favorites entries pinned above user groups.
        val pinned = list.filter { it.name == "ALL" || it.name == "Favorites" }
          .sortedBy { if (it.name == "ALL") 0 else 1 }
        val userGroups = list.filterNot { it.name == "ALL" || it.name == "Favorites" }
        val sorted = when (groupSort) {
          "az" -> userGroups.sortedBy { it.name.lowercase() }
          "za" -> userGroups.sortedByDescending { it.name.lowercase() }
          else -> userGroups
        }
        val saved = context.getSharedPreferences("live_group_order", android.content.Context.MODE_PRIVATE)
          .getString("order", null)?.split("\u001F")?.filter { it.isNotBlank() }.orEmpty()
        val orderedGroups = if (saved.isEmpty()) sorted else {
          val positions = saved.withIndex().associate { it.value to it.index }
          sorted.sortedBy { positions[it.name] ?: (saved.size + sorted.indexOf(it)) }
        }
        pinned + orderedGroups
      }
      totalCount = repository.getChannelCount()
      val rawChannels = when {
        showFavoritesOnly || selectedGroup == "Favorites" -> {
          repository.getFavorites().filter { it.contentType == "live" || it.contentType.isBlank() }
        }
        searchQuery.isNotBlank() -> repository.loadPage("All", searchQuery, 0, "live")
        selectedGroup == "ALL" -> repository.loadPage("All", "", 0, "live")
        else -> repository.loadPage(selectedGroup, "", 0, "live")
      }
      val visibleChannels = hideLockedGroupChannels(rawChannels)
      channels = visibleChannels
      if (channels.none { it.id == previewChannel?.id }) previewChannel = channels.firstOrNull()
      // Use the unfiltered page size for paging so hidden locked entries do
      // not prevent the list from reaching later unlocked channels.
      endReached = rawChannels.size < ChannelRepository.PAGE_SIZE || showFavoritesOnly
      isLoading = false
    }
  }

  fun loadNextPage() {
    if (isLoadingMore || endReached || showFavoritesOnly || selectedGroup == "Favorites" || lockManager.isGroupLocked(selectedGroup)) return
    scope.launch {
      isLoadingMore = true
      val next = currentPage + 1
      val page = if (selectedGroup == "ALL") {
        repository.loadPage("All", searchQuery, next, "live")
      } else {
        repository.loadPage(selectedGroup, searchQuery, next, "live")
      }
      if (page.isEmpty() || page.size < ChannelRepository.PAGE_SIZE) endReached = true
      if (page.isNotEmpty()) {
        channels = channels + hideLockedGroupChannels(page)
        currentPage = next
      }
      isLoadingMore = false
    }
  }

  LaunchedEffect(Unit) { lastChannel = repository.getLastWatchedChannel() }
  LaunchedEffect(channels) { if (previewChannel == null && channels.isNotEmpty()) previewChannel = channels.first() }
  LaunchedEffect(previewChannel?.streamUrl, previewChannel?.id) {
    val url = previewChannel?.streamUrl
    if (previewChannel != null && lockManager.isChannelLocked(previewChannel!!.id)) {
      previewPlayer.stop()
    } else if (!url.isNullOrBlank()) {
      previewPlayer.setMediaSource(PlayerFactory.createMediaSource(url))
      previewPlayer.prepare()
      previewPlayer.playWhenReady = true
    } else { previewPlayer.stop() }
  }
  DisposableEffect(previewPlayer) { onDispose { previewPlayer.release() } }
  LaunchedEffect(selectedGroup, searchQuery, showFavoritesOnly, groupSort) { 
    favorites = repository.getFavorites().filter { it.contentType == "live" || it.contentType.isBlank() }
    loadFirstPage() 
  }
  // Request initial focus only when the selected group changes. Previously
  // this effect also ran after every channel-list update (including adding a
  // channel to Favorites), which moved the TV list focus back to row one.
  LaunchedEffect(selectedGroup) {
    kotlinx.coroutines.delay(250)
    if (channels.isNotEmpty()) {
      try { firstChannelFocus.requestFocus() } catch (_: Exception) {}
    }
  }
  LaunchedEffect(isSearchActive) { if (isSearchActive) searchFocusRequester.requestFocus() }
  LaunchedEffect(listState) {
    snapshotFlow {
      val info = listState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
      last >= info.totalItemsCount - 5
    }.collect { if (it) loadNextPage() }
  }

  Box(Modifier.fillMaxSize().background(BlackBackground)) {
    Column(Modifier.fillMaxSize()) {
      TopAppBar(
        title = {
          if (isSearchActive) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              modifier = Modifier.fillMaxWidth().focusRequester(searchFocusRequester),
              placeholder = { Text(stringResource(R.string.search), color = TextMuted) },
              singleLine = true,
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
              keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() }),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary, unfocusedBorderColor = DividerColor,
                focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
                cursorColor = GoldPrimary, focusedContainerColor = DarkSurface, unfocusedContainerColor = DarkSurface
              )
            )
          } else {
            Text("بث مباشر" + if (totalCount > 0) " ($totalCount)" else "", color = GoldPrimary, fontWeight = FontWeight.Bold)
          }
        },
        navigationIcon = {
          IconButton(onClick = {
            if (isSearchActive) { isSearchActive = false; searchQuery = ""; keyboardController?.hide() } else onBack()
          }) {
            Icon(if (isSearchActive) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
          }
        },
        actions = {
          if (!isSearchActive) {
            // FIX 7: Show favorite button on top near search
            IconButton(onClick = { showFavoritesOnly = !showFavoritesOnly
                            if (showFavoritesOnly) {
                                val favCount = repository.getFavorites().size
                                if (favCount == 0) {
                                    longPressFavMessage = "❤️ المفضلة فارغة - اضغط مطولاً على القنوات لإضافتها"
                                }
                            } }) {
              Icon(if (showFavoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorites", tint = if (showFavoritesOnly) Color(0xFF4CAF50) else GoldPrimary)
            }
            IconButton(onClick = {
              groupSort = if (groupSort == "az") "default" else "az"
            }) {
              Text("A-Z", color = GoldPrimary, fontSize = 12.sp)
            }
            IconButton(onClick = { groupsCollapsed = !groupsCollapsed }) {
              Text(if (groupsCollapsed) "»" else "«", color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = {
              if (lockManageMode) {
                lockManageMode = false
              } else if (lockManager.hasPin()) {
                unlockManageModeRequest = true
                pinDialogGroup = "إدارة القوائم"
                pinInput = ""
                pinError = false
              } else {
                activateLockModeAfterPin = true
                pendingLockGroup = null
                newPin = ""
                showSetPin = true
              }
            }) {
              Icon(
                if (lockManageMode) Icons.Default.LockOpen else Icons.Default.Lock,
                contentDescription = if (lockManageMode) "إنهاء إدارة القفل" else "إدارة قفل القوائم",
                tint = if (lockManageMode) Color(0xFF39E600) else GoldPrimary
              )
            }
            IconButton(onClick = { isSearchActive = true }) {
              Icon(Icons.Default.Search, null, tint = GoldPrimary)
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0D1520))
      )

      Row(Modifier.fillMaxSize()) {
        // LEFT: wider, readable group list
        if (!groupsCollapsed) {
          LazyColumn(
            modifier = Modifier.width(220.dp).fillMaxHeight().background(Color(0xFF0A1A2E)).border(1.dp, DividerColor),
            contentPadding = PaddingValues(vertical = 6.dp)
          ) {
            itemsIndexed(groupInfos) { _, g ->
              var groupFocused by remember(g.name) { mutableStateOf(false) }
              val selected = when {
                g.name == "Favorites" && (showFavoritesOnly || selectedGroup == "Favorites") -> true
                g.name == selectedGroup -> true
                else -> false
              }
              Row(
                Modifier.fillMaxWidth()
                  .onFocusChanged { groupFocused = it.isFocused }
                  .background(if (selected || groupFocused) Color(0x5532CD32) else Color.Transparent, RoundedCornerShape(8.dp))
                  .border(if (selected || groupFocused) 2.dp else 0.dp, if (selected || groupFocused) Color(0xFF39E600) else Color.Transparent, RoundedCornerShape(8.dp))
                  .combinedClickable(
                    onLongClick = { if (g.name != "ALL" && g.name != "Favorites") longPressGroup = g.name },
                    onClick = {
                      if (lockManageMode && g.name != "ALL" && g.name != "Favorites") {
                        if (!lockManager.hasPin()) { pendingLockGroup = g.name; newPin = ""; showSetPin = true }
                        else {
                          lockManager.toggleGroup(g.name)
                          groupInfos = groupInfos.toList()
                          // Re-filter the current view immediately so channels from a newly
                          // locked group disappear even when viewing ALL or Favorites.
                          loadFirstPage()
                        }
                        return@combinedClickable
                      }
                      if (g.name == "Favorites") { showFavoritesOnly = true; selectedGroup = "Favorites" }
                      else if (lockManager.isGroupLocked(g.name)) {
                        showFavoritesOnly = false
                        selectedGroup = g.name
                        channels = emptyList()
                        previewChannel = null
                        if (!lockManager.hasPin()) {
                          pendingUnlockGroup = g.name
                          newPin = ""
                          showSetPin = true
                        } else {
                          pinDialogGroup = g.name
                          pinInput = ""
                          pinError = false
                        }
                      }
                      else { showFavoritesOnly = false; selectedGroup = g.name }
                    })
                  .focusable()
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(g.name, color = if (selected || groupFocused) Color.White else TextPrimary, fontSize = 15.sp, fontWeight = if (selected || groupFocused) FontWeight.Bold else FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  if (lockManager.isGroupLocked(g.name)) { Text("🔒", fontSize = 10.sp); Spacer(Modifier.width(4.dp)) }
                  Text(g.count.toString(), color = if (selected) Color(0xFF81C784) else TextMuted, fontSize = 13.sp)
                }
              }
              HorizontalDivider(color = DividerColor.copy(0.5f), thickness = 0.5.dp)
            }
          }
        }

        // Middle + Right
        Row(Modifier.weight(1f).fillMaxHeight().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // MIDDLE: compact channel list
          Column(Modifier.weight(1.0f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("القنوات (${channels.size})", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text("ملء: OK", color = TextMuted, fontSize = 10.sp)
            }
            when {
              isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = GoldPrimary) }
              channels.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.LiveTv, null, tint = GoldPrimary.copy(0.4f), modifier = Modifier.size(48.dp)); Text(stringResource(R.string.no_data), color = TextMuted) }
              }
              else -> LazyColumn(state = listState, contentPadding = PaddingValues(vertical = 3.dp)) {
                lastChannel?.takeUnless { lockManager.isGroupLocked(it.group) }?.let { last ->
                  item(key = "continue_watching") {
                    Card(onClick = { PlayerSession.setPlaylist(listOf(last) + channels.filter { it.id != last.id }, last); onPlayChannel(last) }, modifier = Modifier.fillMaxWidth().padding(3.dp), colors = CardDefaults.cardColors(containerColor = GoldPrimary.copy(alpha = 0.12f))) {
                      Text("▶ متابعة: ${last.name}", color = GoldAccent, modifier = Modifier.padding(8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                  }
                }
                itemsIndexed(channels, key = { _, c -> c.id }) { index, channel ->
                  ChannelRow(
                    number = index + 1,
                    channel = channel,
                    selected = previewChannel?.id == channel.id,
                    isLocked = lockManager.isChannelLocked(channel.id),
                    isArabic = false,
                    modifier = if (index == 0) Modifier.focusRequester(firstChannelFocus) else Modifier,
                    onClick = {
                      if (lockManager.isChannelLocked(channel.id)) {
                        pendingUnlockChannelId = channel.id
                        pinDialogGroup = "قناة: ${channel.name}"
                        pinInput = ""
                        pinError = false
                      } else {
                        selectedChannelId = channel.id
                        liveTvStateManager.saveChannel(channel.id, channel.name, channel.streamUrl, channel.group)
                        PlayerSession.setPlaylist(channels, channel)
                        onPlayChannel(channel)
                      }
                    },
                    onFocus = { previewChannel = channel },
                    onToggleFavorite = {
                      scope.launch {
                        val v = repository.toggleFavorite(channel.id)
                        channels = channels.map { if (it.id == channel.id) it.copy(isFavorite = v) else it }
                      }
                    },
                    onLongClick = { longPressChannel = channel }
                  )
                  HorizontalDivider(color = DividerColor.copy(0.35f), thickness = 0.5.dp)
                }
                if (isLoadingMore) item { Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(20.dp), color = GoldPrimary, strokeWidth = 2.dp) } }
              }
            }
          }

          // RIGHT: largest live preview area
          Column(Modifier.weight(1.65f).fillMaxHeight()) {
            Text("معاينة البث • OK لتكبير", color = GoldPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp), fontSize = 12.sp)
            Card(modifier = Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.Black)) {
              Box(Modifier.fillMaxSize()) {
                AndroidView(
                  factory = { ctx -> PlayerView(ctx).apply {
                    player = previewPlayer; useController = false
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                  } },
                  update = { it.player = previewPlayer },
                  modifier = Modifier.fillMaxSize().clickable { previewChannel?.let { ch -> PlayerSession.setPlaylist(channels, ch); onPlayChannel(ch) } }
                )
                if (previewChannel == null) Text("اختر قناة", color = Color.White, modifier = Modifier.align(Alignment.Center))
                TextButton(
                  enabled = previewChannel != null,
                  onClick = { previewChannel?.let { ch -> PlayerSession.setPlaylist(channels, ch); onPlayChannel(ch) } },
                  modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).background(Color(0xAA000000), RoundedCornerShape(8.dp))
                ) { Text("ملء الشاشة OK", color = GoldPrimary, fontWeight = FontWeight.Bold) }
              }
            }
            Spacer(Modifier.height(6.dp))
            Text(previewChannel?.name ?: "لا توجد قناة", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
          }
        }
      }
    }

    longPressGroup?.let { groupName ->
      AlertDialog(
        onDismissRequest = { longPressGroup = null },
        title = { Text(groupName, color = GoldPrimary, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            val groupIndex = groupInfos.indexOfFirst { it.name == groupName }
            TextButton(onClick = { moveGroupToTop(groupName) }, enabled = groupIndex > 1) {
              Text("⏫ نقل إلى الأعلى تماماً", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = { moveGroup(groupName, -1) }, enabled = groupIndex > 0 && groupInfos.getOrNull(groupIndex - 1)?.name !in listOf("ALL", "Favorites")) {
              Text("↑ نقل إلى الأعلى", color = TextPrimary)
            }
            TextButton(onClick = { moveGroup(groupName, 1) }, enabled = groupIndex >= 0 && groupIndex < groupInfos.lastIndex && groupInfos.getOrNull(groupIndex + 1)?.name !in listOf("ALL", "Favorites")) {
              Text("↓ نقل إلى الأسفل", color = TextPrimary)
            }
            TextButton(onClick = { moveGroupToBottom(groupName) }, enabled = groupIndex >= 0 && groupIndex < groupInfos.lastIndex) {
              Text("⏬ نقل إلى الأسفل تماماً", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
            HorizontalDivider(color = DividerColor.copy(0.5f), modifier = Modifier.padding(vertical = 4.dp))
            TextButton(onClick = {
              if (!lockManager.hasPin()) {
                pendingLockGroup = groupName
                newPin = ""
                showSetPin = true
              } else {
                pendingToggleGroupAfterPin = groupName
                pinDialogGroup = groupName
                pinInput = ""
                pinError = false
              }
              longPressGroup = null
            }) { 
              Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(if (lockManager.isGroupLocked(groupName)) "🔓 فتح القفل" else "🔒 قفل القائمة", color = if (lockManager.isGroupLocked(groupName)) Color(0xFF81C784) else Color(0xFFFF8A65))
              }
            }
            TextButton(onClick = { longPressGroup = null }) { Text("إغلاق", color = TextMuted) }
            Text("💡 الضغط المطول على OK في الريموت يفتح هذه القائمة", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
          }
        },
        confirmButton = {},
        containerColor = Color(0xFF1A1A1A)
      )
    }

    longPressChannel?.let { channel ->
      AlertDialog(
        onDismissRequest = { longPressChannel = null },
        title = { Text(channel.name, color = GoldPrimary, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
          Column {
            TextButton(onClick = {
              PlayerSession.setPlaylist(channels, channel)
              liveTvStateManager.saveChannel(channel.id, channel.name, channel.streamUrl, channel.group)
              onPlayChannel(channel)
              longPressChannel = null
            }) { Text("▶ تشغيل القناة", color = Color(0xFF39E600), fontWeight = FontWeight.Bold) }
            TextButton(onClick = {
              scope.launch {
                val v = repository.toggleFavorite(channel.id)
                channels = channels.map { if (it.id == channel.id) it.copy(isFavorite = v) else it }
              }
              longPressChannel = null
            }) { Text(if (channel.isFavorite) "★ In Favorite ❤️" else "☆ Add to Favorite 🤍", color = GoldPrimary) }
            HorizontalDivider(color = DividerColor.copy(0.3f), modifier = Modifier.padding(vertical = 2.dp))
            TextButton(onClick = { moveChannelToTop(channel.id) }) { Text("⏫ نقل إلى الأعلى تماماً", color = TextPrimary) }
            TextButton(onClick = { moveChannel(channel.id, -1) }) { Text("↑ نقل إلى الأعلى", color = TextPrimary) }
            TextButton(onClick = { moveChannel(channel.id, 1) }) { Text("↓ نقل إلى الأسفل", color = TextPrimary) }
            TextButton(onClick = { moveChannelToBottom(channel.id) }) { Text("⏬ نقل إلى الأسفل تماماً", color = TextPrimary) }
            HorizontalDivider(color = DividerColor.copy(0.3f), modifier = Modifier.padding(vertical = 2.dp))
            TextButton(onClick = {
              if (!lockManager.hasPin()) {
                // For channel lock we need PIN first
                pendingLockGroup = null
                newPin = ""
                showSetPin = true
              } else {
                lockManager.lockChannel(channel.id)
                channels = channels.filterNot { it.id == channel.id }
              }
              longPressChannel = null
            }) { Text("🔒 قفل القناة", color = Color(0xFFFF8A65)) }
            TextButton(onClick = { longPressChannel = null }) { Text("إغلاق", color = TextMuted) }
          }
        },
        confirmButton = {},
        containerColor = Color(0xFF1A1A1A)
      )
    }


    if (pinDialogGroup != null) {
      AlertDialog(
        onDismissRequest = {
          pinDialogGroup = null
          pendingUnlockChannelId = null
          unlockManageModeRequest = false
          pendingToggleGroupAfterPin = null
        },
        title = { Text("قائمة مقفلة 🔒", color = GoldPrimary) },
        text = {
          Column {
            Text(if (unlockManageModeRequest) "أدخل الرمز لتفعيل إدارة القوائم" else "أدخل الرمز لفتح: ${pinDialogGroup}", color = TextSecondary)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = pinInput, onValueChange = { value -> pinInput = value.filter(Char::isDigit).take(8); pinError = false }, label = { Text("الرمز", color = TextSecondary) }, singleLine = true, isError = pinError,
              keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword, imeAction = ImeAction.Done),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, unfocusedBorderColor = DividerColor, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, cursorColor = GoldPrimary, focusedContainerColor = DarkSurface, unfocusedContainerColor = DarkSurface))
            if (pinError) Text("رمز خاطئ", color = ErrorRed, style = MaterialTheme.typography.bodySmall)
          }
        },
        confirmButton = {
          TextButton(onClick = {
            if (lockManager.checkPin(pinInput)) {
              when {
                pendingUnlockChannelId != null -> {
                  lockManager.unlockChannel(pendingUnlockChannelId!!)
                  pendingUnlockChannelId = null
                  pinDialogGroup = null
                }
                unlockManageModeRequest -> {
                  lockManageMode = true
                  showFavoritesOnly = false
                  unlockManageModeRequest = false
                }
                pendingToggleGroupAfterPin != null -> {
                  val groupName = pendingToggleGroupAfterPin!!
                  lockManager.toggleGroup(groupName)
                  pendingToggleGroupAfterPin = null
                  groupInfos = groupInfos.toList()
                  loadFirstPage()
                }
                else -> {
                  val groupName = pinDialogGroup ?: ""
                  lockManager.unlockForSession(groupName)
                  selectedGroup = groupName.ifBlank { selectedGroup }
                  showFavoritesOnly = false
                  loadFirstPage()
                }
              }
              pinDialogGroup = null
            } else pinError = true
          }) { Text("فتح", color = GoldPrimary) }
        },
        dismissButton = { TextButton(onClick = { pinDialogGroup = null; pendingUnlockChannelId = null; unlockManageModeRequest = false; pendingToggleGroupAfterPin = null }) { Text("إلغاء", color = TextMuted) } },
        containerColor = Color(0xFF1A1A1A)
      )
    }

    if (showSetPin) {
      AlertDialog(
        onDismissRequest = {
        showSetPin = false
        pendingLockGroup = null
        pendingUnlockGroup = null
        activateLockModeAfterPin = false
        newPin = ""
      },
        title = { Text("تعيين رمز", color = GoldPrimary) },
        text = {
          Column {
            Text("اختر رمز 4 أرقام+", color = TextSecondary)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = newPin, onValueChange = { value -> newPin = value.filter(Char::isDigit).take(8) }, label = { Text("الرمز", color = TextSecondary) }, singleLine = true,
              keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword, imeAction = ImeAction.Done),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, unfocusedBorderColor = DividerColor, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, cursorColor = GoldPrimary, focusedContainerColor = DarkSurface, unfocusedContainerColor = DarkSurface))
          }
        },
        confirmButton = {
          TextButton(onClick = {
            if (newPin.length >= 4 && newPin.all(Char::isDigit)) {
              lockManager.setPin(newPin)
              pendingLockGroup?.let {
                lockManager.lockGroup(it)
                loadFirstPage()
              }
              pendingLockGroup = null
              pendingUnlockGroup?.let {
                lockManager.unlockForSession(it)
                selectedGroup = it
                showFavoritesOnly = false
                loadFirstPage()
              }
              pendingUnlockGroup = null
              if (activateLockModeAfterPin) lockManageMode = true
              activateLockModeAfterPin = false
              showSetPin = false
              newPin = ""
            }
          }) { Text("حفظ", color = GoldPrimary) }
        },
        dismissButton = { TextButton(onClick = { showSetPin = false; pendingLockGroup = null; pendingUnlockGroup = null; activateLockModeAfterPin = false; newPin = "" }) { Text("إلغاء", color = TextMuted) } },
        containerColor = Color(0xFF1A1A1A)
      )
    }

    if (lockManageMode) {
      Text("وضع إدارة القفل مفعّل: اضغط على أي مجموعة لقفلها أو فتح قفلها، ثم اضغط أيقونة القفل لإنهاء الوضع.", color = GoldAccent, style = MaterialTheme.typography.labelSmall, modifier = Modifier.fillMaxWidth().background(GoldPrimary.copy(0.1f)).padding(8.dp))
    }
  }
}

@Composable
private fun ChannelRow(
  number: Int,
  channel: Channel,
  selected: Boolean = false,
  isLocked: Boolean = false,
  isArabic: Boolean = false,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
  onFocus: () -> Unit = {},
  onToggleFavorite: () -> Unit,
  onLongClick: () -> Unit = {}
) {
  var focused by remember { mutableStateOf(false) }
  Row(
    modifier.fillMaxWidth()
      .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus() }
      .focusable()
      .combinedClickable(onClick = onClick, onLongClick = onLongClick)
      .shadow(if (focused || selected) 14.dp else 0.dp, RoundedCornerShape(10.dp))
      .background(
        when {
          focused -> Color(0xFF39E600).copy(alpha = 0.25f)
          selected -> Color(0x5532CD32)
          isArabic -> GoldPrimary.copy(alpha = 0.08f)
          else -> CardBackground
        },
        RoundedCornerShape(10.dp)
      )
      .border(
        width = when { focused -> 3.dp; selected -> 3.dp; else -> 1.dp },
        color = when { focused -> Color(0xFF39E600); selected -> Color(0xFF39E600); isArabic -> GoldPrimary.copy(alpha = 0.5f); else -> DividerColor },
        shape = RoundedCornerShape(10.dp)
      )
      .padding(horizontal = 6.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(number.toString(), color = if (focused) Color(0xFF39E600) else GoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(20.dp), textAlign = TextAlign.Center)
    if (!channel.logoUrl.isNullOrBlank()) {
      AsyncImage(model = channel.logoUrl, contentDescription = null, modifier = Modifier.size(24.dp).background(DarkSurface, RoundedCornerShape(6.dp)), contentScale = ContentScale.Fit)
    } else {
      Box(Modifier.size(24.dp).background(GoldPrimary.copy(0.12f), RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.LiveTv, null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
      }
    }
    Spacer(Modifier.width(8.dp))
    Column(Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(channel.name, color = if (focused) Color.White else TextPrimary, fontWeight = if (focused || selected) FontWeight.Bold else FontWeight.Medium, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        // نجمة إضافية - لا تشيل شي، زيادة فقط - تشتغل بالريموت
        IconButton(
            onClick = {
                hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                val newVal = repository.toggleFavorite(channel.id)
                channels = channels.map { if (it.id == channel.id) it.copy(isFavorite = newVal) else it }
                favorites = repository.getFavorites().filter { it.contentType == "live" || it.contentType.isBlank() }
                longPressFavMessage = if (newVal) "⭐ Added: ${channel.name}" else "✗ Removed: ${channel.name}"
            },
            modifier = Modifier.size(28.dp).focusable().semantics { contentDescription = if (channel.isFavorite) "In Favorite" else "Add to Favorite" }
        ) {
            Text(if (channel.isFavorite) "⭐" else "☆", fontSize = 14.sp, color = if (channel.isFavorite) androidx.compose.ui.graphics.Color(0xFF4CAF50) else androidx.compose.ui.graphics.Color.White)
        }
      }
    }
    if (isLocked) {
      Text("🔒", fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
    }
    // برا بدون مفضلة - تمت الإزالة حسب الطلب
    Spacer(modifier = Modifier.size(30.dp))
  }
}