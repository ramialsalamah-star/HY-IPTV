package com.hyiptv.player.data.repository

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hyiptv.player.data.model.Playlist
import com.hyiptv.player.data.model.PlaylistType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.playlistDataStore: DataStore<Preferences> by preferencesDataStore(name = "playlists")

private fun String.normalizedForComparison(): String {
  var s = trim()
  if (s.endsWith("/")) s = s.dropLast(1)
  s = s.removeSuffix("/player_api.php")
  s = s.removeSuffix("/xmltv.php")
  s = s.removeSuffix("/get.php")
  if (s.startsWith("https://", ignoreCase = true)) s = "http://" + s.substring(8)
  return s.lowercase()
}


class PlaylistRepository(private val context: Context) {

  private val gson = Gson()
  private val PLAYLISTS_KEY = stringPreferencesKey("saved_playlists")
  private val m3uParser = M3uParser()
  private val channelRepo = ChannelRepository(context)

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _error = MutableStateFlow<String?>(null)
  val error: StateFlow<String?> = _error.asStateFlow()

  private val _lastLoadedCount = MutableStateFlow(0)
  val lastLoadedCount: StateFlow<Int> = _lastLoadedCount.asStateFlow()

  val playlistsFlow: Flow<List<Playlist>> = context.playlistDataStore.data.map { prefs ->
    decodePlaylists(prefs[PLAYLISTS_KEY])
  }

  suspend fun getPlaylists(): List<Playlist> = playlistsFlow.first()

  suspend fun savePlaylist(playlist: Playlist) {
    context.playlistDataStore.edit { prefs ->
      val current = decodePlaylists(prefs[PLAYLISTS_KEY]).toMutableList()
      val normalized = if (playlist.isActive) {
        current.map { it.copy(isActive = false) }.toMutableList()
      } else current
      val index = normalized.indexOfFirst { it.id == playlist.id }
      if (index >= 0) normalized[index] = playlist else normalized.add(playlist)
      prefs[PLAYLISTS_KEY] = gson.toJson(normalized)
    }
  }

  suspend fun deletePlaylist(id: String) {
    val playlistsBeforeDelete = getPlaylists()
    val deleted = playlistsBeforeDelete.firstOrNull { it.id == id }
    val remaining = playlistsBeforeDelete.filterNot { it.id == id }

    val nextActiveId = remaining.firstOrNull { it.isActive }?.id
      ?: if (deleted?.isActive == true) remaining.lastOrNull()?.id else null
    context.playlistDataStore.edit { prefs ->
      prefs[PLAYLISTS_KEY] = gson.toJson(
        remaining.map { it.copy(isActive = it.id == nextActiveId) }
      )
    }
    channelRepo.removeSource("playlist_$id")

    if (deleted?.isActive == true && nextActiveId != null) {
      try {
        val next = remaining.firstOrNull { it.id == nextActiveId }
        if (next != null) {
          if (next.type == PlaylistType.M3U) {
            val parsed = when {
              next.url.startsWith("content://", ignoreCase = true) ->
                m3uParser.parseFromUri(context, android.net.Uri.parse(next.url))
              next.url.startsWith("http://", ignoreCase = true) ||
                next.url.startsWith("https://", ignoreCase = true) ->
                m3uParser.parseFromUrl(next.url)
              else -> Result.failure(Exception("مصدر غير صالح"))
            }
            parsed.onSuccess { channels ->
              val namespaced = channels.map { ch -> ch.copy(id = "playlist_${next.id}_${ch.id}") }
              channelRepo.replaceChannels(namespaced, sourceType = "playlist_${next.id}")
            }
          } else if (next.type == PlaylistType.XTREAM) {
            XtreamRepository(context).loadExistingPlaylist(next)
          }
        }
      } catch (_: Exception) {}
    }

    if (deleted?.type == PlaylistType.XTREAM) {
      // The login form stores credentials separately from the playlist list.
      // Clear them only when no other saved Xtream playlist uses the same login.
      val sameLoginStillSaved = remaining.any {
        it.type == PlaylistType.XTREAM &&
          it.serverUrl.normalizedForComparison() == deleted.serverUrl.normalizedForComparison() &&
          it.username.trim() == deleted.username.trim() &&
          it.password.trim() == deleted.password.trim()
      }
      if (!sameLoginStillSaved) {
        XtreamRepository(context).clearSavedConfigIfMatches(
          com.hyiptv.player.data.remote.XtreamApi.XtreamConfig(
            deleted.serverUrl, deleted.username, deleted.password
          )
        )
      }
    }
  }

  suspend fun setActivePlaylist(id: String) {
    context.playlistDataStore.edit { prefs ->
      val updated = decodePlaylists(prefs[PLAYLISTS_KEY]).map { it.copy(isActive = it.id == id) }
      prefs[PLAYLISTS_KEY] = gson.toJson(updated)
    }
  }

  private suspend fun purgeOtherSources(currentId: String) {
    try {
      channelRepo.removeSource("m3u")
      channelRepo.removeSource("xtream")
      channelRepo.removeSource("stalker")
      channelRepo.clearPlaylistSources()
      val all = getPlaylists()
      for (other in all) {
        if (other.id != currentId) {
          runCatching { channelRepo.removeSource("playlist_${other.id}") }
          runCatching { channelRepo.removeSource("stalker_${other.id}") }
        }
      }
    } catch (_: Exception) {}
  }

    suspend fun activatePlaylist(id: String): Result<Int> {
    val playlist = getPlaylists().firstOrNull { it.id == id }
      ?: return Result.failure(Exception("القائمة غير موجودة"))
    return try {
      if (playlist.type == PlaylistType.XTREAM) {
        return XtreamRepository(context).loadExistingPlaylist(playlist)
      }
      val parsed = when {
        playlist.url.startsWith("content://", ignoreCase = true) ->
          m3uParser.parseFromUri(context, Uri.parse(playlist.url))
        playlist.url.startsWith("http://", ignoreCase = true) ||
          playlist.url.startsWith("https://", ignoreCase = true) ->
          m3uParser.parseFromUrl(playlist.url)
        else -> Result.failure(Exception("مصدر القائمة غير صالح أو لم يعد متاحاً - قد تكون صلاحية الملف انتهت، أعد استيراده"))
      }
      parsed.fold(
        onSuccess = { channels ->
          val namespaced = channels.map { channel ->
            channel.copy(id = "playlist_${id}_${channel.id}")
          }
          purgeOtherSources(id)
          val count = channelRepo.replaceChannels(namespaced, sourceType = "playlist_$id")
          setActivePlaylist(id)
          Result.success(count)
        },
        onFailure = { Result.failure(it) }
      )
    } catch (error: Exception) {
      Result.failure(error)
    }
  }

  suspend fun renamePlaylist(id: String, newName: String) {
    if (newName.isBlank()) return
    context.playlistDataStore.edit { prefs ->
      val updated = decodePlaylists(prefs[PLAYLISTS_KEY]).map {
        if (it.id == id) it.copy(name = newName.trim()) else it
      }
      prefs[PLAYLISTS_KEY] = gson.toJson(updated)
    }
  }

  private fun decodePlaylists(json: String?): List<Playlist> = try {
    val type = object : TypeToken<List<Playlist>>() {}.type
    gson.fromJson<List<Playlist>>(json ?: "[]", type) ?: emptyList()
  } catch (_: Exception) {
    emptyList()
  }

  suspend fun loadM3uPlaylist(url: String, name: String = "M3U Playlist"): Result<Int> {
    _isLoading.value = true
    _error.value = null
    return try {
      val result = m3uParser.parseFromUrl(url)
      result.fold(
        onSuccess = { list ->
          val playlistId = UUID.randomUUID().toString()
          // Purge other sources before saving new M3U
          purgeOtherSources(playlistId)
          val namespaced = list.map { channel ->
            channel.copy(id = "playlist_${playlistId}_${channel.id}")
          }
          val count = channelRepo.replaceChannels(namespaced, sourceType = "playlist_$playlistId")
          _lastLoadedCount.value = count
          savePlaylist(
            Playlist(
              id = playlistId,
              name = name,
              type = PlaylistType.M3U,
              url = url,
              isActive = true
            )
          )
          Result.success(count)
        },
        onFailure = { e ->
          _error.value = e.message ?: "Failed to load playlist"
          Result.failure(e)
        }
      )
    } finally {
      _isLoading.value = false
    }
  }

  /**
   * Import local .m3u / .m3u8 file from device storage.
   */
  suspend fun loadM3uFromUri(uri: Uri, name: String = "Local M3U"): Result<Int> {
    _isLoading.value = true
    _error.value = null
    return try {
      val result = m3uParser.parseFromUri(context, uri)
      result.fold(
        onSuccess = { list ->
          val playlistId = UUID.randomUUID().toString()
          // Purge other sources before saving new M3U
          purgeOtherSources(playlistId)
          val namespaced = list.map { channel ->
            channel.copy(id = "playlist_${playlistId}_${channel.id}")
          }
          val count = channelRepo.replaceChannels(namespaced, sourceType = "playlist_$playlistId")
          _lastLoadedCount.value = count
          savePlaylist(
            Playlist(
              id = playlistId,
              name = name,
              type = PlaylistType.M3U,
              url = uri.toString(),
              isActive = true
            )
          )
          Result.success(count)
        },
        onFailure = { e ->
          _error.value = e.message ?: "Failed to import file"
          Result.failure(e)
        }
      )
    } finally {
      _isLoading.value = false
    }
  }

  fun clearError() {
    _error.value = null
  }

  suspend fun getChannelCount(): Int = channelRepo.getChannelCount()
}
