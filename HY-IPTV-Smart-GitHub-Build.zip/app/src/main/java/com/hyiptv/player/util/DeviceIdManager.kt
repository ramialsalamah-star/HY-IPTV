package com.hyiptv.player.util

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "device_prefs")

class DeviceIdManager(private val context: Context) {

  private val DEVICE_ID_KEY = stringPreferencesKey("persistent_device_id")
  private val ACTIVATION_CODE_KEY = stringPreferencesKey("activation_code")
  private val SUBSCRIPTION_STATUS_KEY = stringPreferencesKey("subscription_status")
  private val EXPIRATION_DATE_KEY = stringPreferencesKey("expiration_date")
  private val IS_ACTIVATED_KEY = stringPreferencesKey("is_activated")

  val deviceIdFlow: Flow<String> = context.dataStore.data.map { prefs ->
    prefs[DEVICE_ID_KEY] ?: generateAndSaveDeviceId()
  }

  suspend fun getDeviceId(): String {
    val prefs = context.dataStore.data.first()
    return prefs[DEVICE_ID_KEY] ?: generateAndSaveDeviceId()
  }

  private suspend fun generateAndSaveDeviceId(): String {
    val newId = "HY-" + UUID.randomUUID().toString().uppercase().replace("-", "").take(16)
    context.dataStore.edit { prefs ->
      prefs[DEVICE_ID_KEY] = newId
    }
    return newId
  }

  suspend fun saveActivation(code: String, status: String, expiration: String) {
    context.dataStore.edit { prefs ->
      prefs[ACTIVATION_CODE_KEY] = code
      prefs[SUBSCRIPTION_STATUS_KEY] = status
      prefs[EXPIRATION_DATE_KEY] = expiration
      prefs[IS_ACTIVATED_KEY] = "true"
    }
  }

  suspend fun isActivated(): Boolean {
    val prefs = context.dataStore.data.first()
    return prefs[IS_ACTIVATED_KEY] == "true"
  }

  suspend fun getSubscriptionStatus(): String {
    val prefs = context.dataStore.data.first()
    return prefs[SUBSCRIPTION_STATUS_KEY] ?: "inactive"
  }

  suspend fun getExpirationDate(): String {
    val prefs = context.dataStore.data.first()
    return prefs[EXPIRATION_DATE_KEY] ?: "-"
  }

  suspend fun clearActivation() {
    context.dataStore.edit { prefs ->
      prefs.remove(ACTIVATION_CODE_KEY)
      prefs.remove(SUBSCRIPTION_STATUS_KEY)
      prefs.remove(EXPIRATION_DATE_KEY)
      prefs[IS_ACTIVATED_KEY] = "false"
    }
  }
}
