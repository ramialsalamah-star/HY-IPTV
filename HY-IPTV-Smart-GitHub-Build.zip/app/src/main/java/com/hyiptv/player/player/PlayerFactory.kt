package com.hyiptv.player.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.extractor.ts.TsExtractor

@OptIn(UnstableApi::class)
object PlayerFactory {

  private const val UA_MAG =
    "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

  fun createHttpFactory(userAgent: String = UA_MAG): HttpDataSource.Factory =
    DefaultHttpDataSource.Factory()
      .setUserAgent(userAgent)
      .setAllowCrossProtocolRedirects(true)
      .setConnectTimeoutMs(20_000)
      .setReadTimeoutMs(25_000)
      .setKeepPostFor302Redirects(true)

  fun createPlayer(context: Context): ExoPlayer {
    val httpFactory = createHttpFactory()

    val extractorsFactory = DefaultExtractorsFactory()
      .setTsExtractorFlags(
        DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
          DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
          DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS
      )
      .setTsExtractorTimestampSearchBytes(TsExtractor.DEFAULT_TIMESTAMP_SEARCH_BYTES * 3)
      .setConstantBitrateSeekingEnabled(true)

    // Media3: DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)
    val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory, extractorsFactory)

    // Adaptive selection tuned for varying internet speeds
    val adaptiveFactory = AdaptiveTrackSelection.Factory(
      1000,  // min duration for quality increase (ms)
      5000,  // max duration for quality decrease
      25000, // min duration to retain after discard
      0.75f  // reserve headroom so automatic quality adapts before the link saturates
    )
    val trackSelector = DefaultTrackSelector(context, adaptiveFactory).apply {
      setParameters(
        buildUponParameters()
          .setForceHighestSupportedBitrate(false) // choose the highest sustainable rendition, including 4K when supported
          .setAllowVideoMixedMimeTypeAdaptiveness(true)
          .setAllowAudioMixedMimeTypeAdaptiveness(true)
          .setAllowVideoNonSeamlessAdaptiveness(true)
      )
    }

    val loadControl = DefaultLoadControl.Builder()
      .setBufferDurationsMs(8_000, 40_000, 1_000, 2_000)
      .setPrioritizeTimeOverSizeThresholds(true)
      .setBackBuffer(10_000, true)
      .build()

    val renderersFactory = DefaultRenderersFactory(context)
      .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
      .setEnableDecoderFallback(true)

    val audioAttributes = AudioAttributes.Builder()
      .setUsage(C.USAGE_MEDIA)
      .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
      .build()

    return ExoPlayer.Builder(context, renderersFactory)
      .setTrackSelector(trackSelector)
      .setLoadControl(loadControl)
      .setMediaSourceFactory(mediaSourceFactory)
      .setSeekBackIncrementMs(10_000)
      .setSeekForwardIncrementMs(10_000)
      .setAudioAttributes(audioAttributes, true)
      .setHandleAudioBecomingNoisy(true)
      .build()
  }

  fun createMediaSource(url: String, ua: String = UA_MAG): MediaSource {
    val normalized = url.trim()
    require(normalized.isNotBlank()) { "رابط البث فارغ" }
    val lower = normalized.lowercase()
    val inferredMime = when {
      lower.substringBefore('?').endsWith(".m3u8") || lower.contains("format=m3u8") || lower.contains("type=m3u8") || lower.contains("output=m3u8") -> "application/x-mpegURL"
      lower.substringBefore('?').endsWith(".mpd") || lower.contains("format=mpd") || lower.contains("type=mpd") || lower.contains("output=mpd") -> "application/dash+xml"
      else -> null
    }
    val itemBuilder = MediaItem.Builder().setUri(normalized)
    if (inferredMime != null) itemBuilder.setMimeType(inferredMime)
    val item = itemBuilder.build()

    // RTSP is a different transport and must not be sent through HTTP.
    if (lower.startsWith("rtsp://")) {
      return RtspMediaSource.Factory().createMediaSource(item)
    }
    require(!(lower.startsWith("rtmp://") || lower.startsWith("udp://") || lower.startsWith("mms://"))) {
      "نوع البث غير مدعوم في مشغل Media3: ${normalized.substringBefore("://")}. يلزم محرك بث إضافي لهذا النوع."
    }

    val http = createHttpFactory(ua)
    return when {
      // HLS live channels and VOD playlists.
      lower.contains(".m3u8") || lower.contains("format=m3u8") ||
        lower.contains("/hls/") || lower.contains("type=m3u8") ||
        lower.contains("output=m3u8") || lower.contains("output=hls") ->
        HlsMediaSource.Factory(http)
          .setAllowChunklessPreparation(true)
          .createMediaSource(item)

      // DASH was previously treated as a progressive file, which fails
      // for .mpd manifests even though the DASH module is included.
      lower.contains(".mpd") || lower.contains("format=mpd") ||
        lower.contains("type=mpd") || lower.contains("output=mpd") ->
        DashMediaSource.Factory(http).createMediaSource(item)

      // MPEG-TS (.ts), MP4, MKV, MP3, AAC and other extractor-supported
      // progressive streams are handled by Media3's extractors.
      else -> ProgressiveMediaSource.Factory(http).createMediaSource(item)
    }
  }

  fun createHlsSource(url: String, ua: String = UA_MAG): MediaSource {
    val http = createHttpFactory(ua)
    val item = MediaItem.Builder().setUri(url).build()
    return HlsMediaSource.Factory(http)
      .setAllowChunklessPreparation(true)
      .createMediaSource(item)
  }

}
