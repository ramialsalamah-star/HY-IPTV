package com.hyiptv.player

import android.app.Application
import com.hyiptv.player.data.vpn.VpnRepository

class HYIptvApp : Application() {
  override fun onCreate() {
    super.onCreate()
    // تأكد من وجود ملف VPN الداخلي عند بدء التطبيق - إصلاح الداخلي
    try {
      val repo = VpnRepository(this)
      repo.ensureInternalVpnExists()
    } catch (_: Exception) {}
  }
}
