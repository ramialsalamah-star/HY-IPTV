
package com.hyiptv.player.ui.screens.xtream

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.hyiptv.player.data.repository.XtreamRepository
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XtreamScreen(
  onBack: () -> Unit,
  onConnected: () -> Unit = {}
) {
  val context = LocalContext.current
  val repo = remember { XtreamRepository(context) }
  val scope = rememberCoroutineScope()

  var server by remember { mutableStateOf("") }
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var isLoading by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    val cfg = repo.getSavedConfig()
    if (cfg != null) {
      server = cfg.serverUrl
      username = cfg.username
      password = cfg.password
    }
  }

  Column(modifier = Modifier.fillMaxSize().background(BlackBackground)) {
    TopAppBar(
      title = { Text("Xtream Codes", color = GoldPrimary, fontWeight = FontWeight.Bold) },
      navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary) } },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Card(modifier = Modifier.fillMaxWidth().border(1.dp, GoldPrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp)), colors = CardDefaults.cardColors(containerColor = CardBackground), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Cloud, null, tint = GoldPrimary)
            Spacer(Modifier.width(10.dp))
            Text("Xtream Codes Login", color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
          }
          OutlinedTextField(value = server, onValueChange = { server = it }, label = { Text("Server URL", color = TextSecondary) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username", color = TextSecondary) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password", color = TextSecondary) }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors(), shape = RoundedCornerShape(12.dp))
          message?.let { msg: String -> Text(msg, color = if (isError) ErrorRed else SuccessGreen) }
          Button(
            onClick = {
              if (server.isBlank() || username.isBlank() || password.isBlank()) {
                message = "Fill all fields"
                isError = true
                return@Button
              }
              isLoading = true
              message = null
              scope.launch {
                val result: Result<Int> = repo.connectAndLoad(server.trim(), username.trim(), password)
                isLoading = false
                result.onSuccess { count: Int ->
                  message = "تم تحميل " + count.toString() + " عنصر"
                  isError = count == 0
                  if (count > 0) onConnected() else isError = true
                }.onFailure { e: Throwable ->
                  message = e.message ?: "Failed"
                  isError = true
                }
              }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = !isLoading,
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BlackBackground),
            shape = RoundedCornerShape(12.dp)
          ) {
            if (isLoading) CircularProgressIndicator(Modifier.size(22.dp), color = BlackBackground, strokeWidth = 2.dp) else Text("Connect", fontWeight = FontWeight.Bold)
          }
        }
      }
      Text("Supports standard Xtream Codes player_api.php (Live TV primary).", color = TextMuted, style = MaterialTheme.typography.bodySmall)
    }
  }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
  focusedBorderColor = GoldPrimary, unfocusedBorderColor = DividerColor, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, cursorColor = GoldPrimary, focusedContainerColor = DarkSurface, unfocusedContainerColor = DarkSurface, focusedLabelColor = GoldAccent, unfocusedLabelColor = TextSecondary
)
