package com.hyiptv.player.util

import android.content.Context
import android.content.SharedPreferences

/**
 * مدير سجل البحث الاحترافي - يحفظ عمليات البحث الأخيرة والاقتراحات
 * Professional Search History Manager - saves recent searches and suggestions
 */
class SearchHistoryManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("hy_search_history", Context.MODE_PRIVATE)

  companion object {
    private const val KEY_HISTORY = "search_history"
    private const val MAX_HISTORY = 10
  }

  fun getHistory(): List<String> {
    val set = prefs.getStringSet(KEY_HISTORY, emptySet()) ?: emptySet()
    return set.toList().reversed() // الأحدث أولاً
  }

  fun addSearch(query: String) {
    val trimmed = query.trim()
    if (trimmed.length < 2) return
    
    val current = getHistory().toMutableList()
    current.remove(trimmed) // إزالة إذا موجود مسبقاً
    current.add(0, trimmed) // إضافة في البداية
    
    // الاحتفاظ بآخر 10 فقط
    val limited = current.take(MAX_HISTORY)
    prefs.edit().putStringSet(KEY_HISTORY, limited.toSet()).apply()
  }

  fun removeSearch(query: String) {
    val current = getHistory().toMutableList()
    current.remove(query)
    prefs.edit().putStringSet(KEY_HISTORY, current.toSet()).apply()
  }

  fun clearHistory() {
    prefs.edit().remove(KEY_HISTORY).apply()
  }

  fun getSuggestions(partial: String, allGroups: List<String>): List<String> {
    if (partial.length < 1) return emptyList()
    val lower = partial.lowercase()
    
    // اقتراحات من سجل البحث
    val fromHistory = getHistory().filter { it.lowercase().contains(lower) }
    
    // اقتراحات من أسماء المجموعات
    val fromGroups = allGroups.filter { it.lowercase().contains(lower) }.take(5)
    
    return (fromHistory + fromGroups).distinct().take(8)
  }
}
