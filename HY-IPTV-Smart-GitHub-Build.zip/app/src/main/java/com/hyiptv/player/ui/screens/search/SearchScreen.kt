package com.hyiptv.player.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.player.PlayerSession
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun SearchScreen(
  onBack: () -> Unit,
  onPlay: (Channel) -> Unit
) {
  val context = LocalContext.current
  val repo = remember { ChannelRepository(context) }
  val scope = rememberCoroutineScope()
  val keyboard = LocalSoftwareKeyboardController.current
  val focusRequester = remember { FocusRequester() }
  val listState = rememberLazyListState()

  var query by remember { mutableStateOf("") }
  var results by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var total by remember { mutableStateOf(0) }
  var loading by remember { mutableStateOf(false) }
  var page by remember { mutableStateOf(0) }
  var end by remember { mutableStateOf(false) }

  // Debounced search — starts from 1 character (partial name)
  LaunchedEffect(query) {
    if (query.isBlank()) {
      results = emptyList()
      total = 0
      return@LaunchedEffect
    }
    loading = true
    page = 0
    end = false
    // small debounce for typing
    kotlinx.coroutines.delay(250)
    total = repo.countSearch(query)
    results = repo.searchAll(query, 0)
    end = results.size < ChannelRepository.PAGE_SIZE
    loading = false
  }

  LaunchedEffect(listState, results) {
    snapshotFlow {
      val info = listState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
      last >= info.totalItemsCount - 4
    }.collect { nearEnd ->
      if (nearEnd && !loading && !end && query.isNotBlank()) {
        loading = true
        val next = page + 1
        val more = repo.searchAll(query, next)
        if (more.isEmpty() || more.size < ChannelRepository.PAGE_SIZE) end = true
        if (more.isNotEmpty()) {
          results = results + more
          page = next
        }
        loading = false
      }
    }
  }

  LaunchedEffect(Unit) {
    focusRequester.requestFocus()
  }

  Column(
    Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it },
          modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester),
          placeholder = {
            Text("ابحث عن قناة، فيلم، مسلسل…", color = TextMuted)
          },
          singleLine = true,
          leadingIcon = {
            Icon(Icons.Default.Search, null, tint = GoldPrimary)
          },
          trailingIcon = {
            if (query.isNotEmpty()) {
              IconButton(onClick = { query = "" }) {
                Icon(Icons.Default.Clear, null, tint = TextMuted)
              }
            }
          },
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
          keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DividerColor,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = GoldPrimary,
            focusedContainerColor = DarkSurface,
            unfocusedContainerColor = DarkSurface
          ),
          shape = RoundedCornerShape(12.dp)
        )
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    when {
      query.isBlank() -> {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              Icons.Default.Search,
              null,
              tint = GoldPrimary.copy(0.35f),
              modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text("اكتب جزءاً من الاسم", color = TextMuted)
            Text(
              "مثال: الجزيرة ، beout ، قمر",
              color = TextMuted,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      }
      loading && results.isEmpty() -> {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = GoldPrimary)
        }
      }
      results.isEmpty() -> {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Text("لا نتائج لـ \"$query\"", color = TextMuted)
        }
      }
      else -> {
        Text(
          "$total نتيجة",
          color = GoldAccent,
          style = MaterialTheme.typography.labelMedium,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(
          state = listState,
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(results, key = { it.id }) { item ->
            SearchResultRow(item) {
              scope.launch { repo.markWatched(item.id) }
              PlayerSession.setPlaylist(results, item)
              onPlay(item)
            }
          }
          if (loading) {
            item {
              Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), color = GoldPrimary, strokeWidth = 2.dp)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SearchResultRow(item: Channel, onClick: () -> Unit) {
  val typeLabel = when (item.contentType) {
    "movie" -> "فيلم"
    "series" -> "مسلسل"
    else -> "مباشر"
  }
  val typeIcon = when (item.contentType) {
    "movie" -> Icons.Default.Movie
    "series" -> Icons.Default.VideoLibrary
    else -> Icons.Default.LiveTv
  }

  Card(
    onClick = onClick,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CardBackground),
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
  ) {
    Row(
      Modifier
        .fillMaxWidth()
        .padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (!item.logoUrl.isNullOrBlank()) {
        AsyncImage(
          model = item.logoUrl,
          contentDescription = null,
          modifier = Modifier
            .size(44.dp)
            .background(DarkSurface, RoundedCornerShape(8.dp)),
          contentScale = ContentScale.Fit
        )
      } else {
        Box(
          Modifier
            .size(44.dp)
            .background(GoldPrimary.copy(0.12f), RoundedCornerShape(8.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(typeIcon, null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
        }
      }
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        Text(
          item.name,
          color = TextPrimary,
          fontWeight = FontWeight.Medium,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          "$typeLabel • ${item.group}",
          color = TextSecondary,
          style = MaterialTheme.typography.bodySmall,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
      Surface(
        color = GoldPrimary.copy(0.15f),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(
          typeLabel,
          color = GoldPrimary,
          style = MaterialTheme.typography.labelSmall,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }
    }
  }
}
