package com.hyiptv.player.util

import android.content.Context
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.repository.ChannelRepository
import kotlinx.coroutines.flow.Flow

/** Favorites facade shared by screens; Room remains the single source of truth. */
class FavoriteManager(context: Context) {
  private val repository = ChannelRepository(context.applicationContext)

  fun favoritesFlow(): Flow<List<Channel>> = repository.favoritesFlow()

  suspend fun getFavorites(): List<Channel> = repository.getFavorites()

  /** Returns the new favorite state, or false if the media item no longer exists. */
  suspend fun toggleFavorite(mediaId: String): Boolean =
    repository.toggleFavorite(mediaId)
}
