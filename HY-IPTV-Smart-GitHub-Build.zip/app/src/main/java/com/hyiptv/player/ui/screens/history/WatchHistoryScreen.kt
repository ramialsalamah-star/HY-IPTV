package com.hyiptv.player.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.hyiptv.player.ui.theme.*
import com.hyiptv.player.util.WatchProgressEntry
import com.hyiptv.player.util.WatchProgressManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchHistoryScreen(
  onBack: () -> Unit,
  onPlay: (mediaId: String, title: String) -> Unit
) {
  val context = LocalContext.current
  val manager = remember { WatchProgressManager(context) }
  val lifecycleOwner = LocalLifecycleOwner.current
  var entries by remember { mutableStateOf<List<WatchProgressEntry>>(emptyList()) }

  LaunchedEffect(Unit) { entries = manager.getAllProgress() }
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) entries = manager.getAllProgress()
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  Column(Modifier.fillMaxSize().background(BlackBackground)) {
    TopAppBar(
      title = { Text("سجل المشاهدة", color = GoldPrimary, fontWeight = FontWeight.Bold) },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )
    if (entries.isEmpty()) {
      Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.History, null, tint = GoldPrimary, modifier = Modifier.size(52.dp))
          Spacer(Modifier.height(12.dp))
          Text("لا يوجد سجل مشاهدة بعد", color = TextMuted)
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(entries, key = { it.mediaId }) { entry ->
          val percent = if (entry.durationMs > 0L)
            ((entry.positionMs.toDouble() / entry.durationMs) * 100.0).toInt().coerceIn(0, 100)
          else 0
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                  Text(entry.title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                  Text("${formatTime(entry.positionMs)} / ${formatTime(entry.durationMs)}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = { onPlay(entry.mediaId, entry.title) }) {
                  Icon(Icons.Default.PlayArrow, "متابعة المشاهدة", tint = GoldPrimary)
                }
              }
              LinearProgressIndicator(
                progress = percent / 100f,
                modifier = Modifier.fillMaxWidth().height(5.dp),
                color = GoldPrimary,
                trackColor = DarkSurface
              )
              Text("$percent%", color = TextSecondary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.End))
            }
          }
        }
      }
    }
  }
}

private fun formatTime(milliseconds: Long): String {
  if (milliseconds <= 0L) return "00:00"
  val seconds = milliseconds / 1_000L
  val hours = seconds / 3_600L
  val minutes = (seconds % 3_600L) / 60L
  val remainder = seconds % 60L
  return if (hours > 0L) String.format("%d:%02d:%02d", hours, minutes, remainder)
  else String.format("%02d:%02d", minutes, remainder)
}
