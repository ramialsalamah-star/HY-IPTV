package com.hyiptv.player.data.vpn

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * Keeps exactly one active imported OpenVPN profile in private app storage.
 * Importing a replacement atomically replaces the previous profile.
 */
class VpnRepository(private val context: Context) {

  private val _currentFile = MutableStateFlow<File?>(null)
  val currentFile: StateFlow<File?> = _currentFile.asStateFlow()

  private fun vpnDir(): File = File(context.filesDir, "vpn").apply { mkdirs() }

  private fun activeFile(): File = File(vpnDir(), "current_vpn.ovpn")

  fun getSavedVpnFile(): File? {
    val file = activeFile()
    return file.takeIf { it.isFile && it.length() > 100 }?.also { _currentFile.value = it }
  }

  private fun importBytes(bytes: ByteArray): Result<File> {
    return try {
      if (bytes.size !in 101..(2 * 1024 * 1024)) {
        return Result.failure(IllegalArgumentException("حجم ملف VPN غير صالح"))
      }
      val text = bytes.toString(Charsets.UTF_8)
      if (!text.contains(Regex("(?m)^\\s*remote\\s+\\S+")) ||
          !(text.contains(Regex("(?m)^\\s*client\\s*$")) ||
            text.contains(Regex("(?m)^\\s*dev\\s+tun\\b")))) {
        return Result.failure(IllegalArgumentException("الملف لا يبدو إعداد OpenVPN صالحاً"))
      }

      val destination = activeFile()
      val temporary = File(vpnDir(), "current_vpn.ovpn.tmp")
      temporary.writeBytes(bytes)
      val previous = File(vpnDir(), "previous_vpn.tmp")
      if (previous.exists()) previous.delete()
      if (destination.exists() && !destination.renameTo(previous)) {
        temporary.delete()
        return Result.failure(IllegalStateException("تعذر حفظ نسخة آمنة من الملف السابق"))
      }
      if (!temporary.renameTo(destination)) {
        temporary.delete()
        if (previous.exists()) previous.renameTo(destination)
        return Result.failure(IllegalStateException("تعذر حفظ ملف VPN"))
      }
      previous.delete()

      // Remove stale profiles/backups so only one profile remains active.
      vpnDir().listFiles()?.filter {
        it.isFile && it != destination && (it.extension.equals("ovpn", true) ||
          it.extension.equals("conf", true) || it.name.endsWith(".tmp"))
      }?.forEach { it.delete() }

      _currentFile.value = destination
      Result.success(destination)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun saveVpnFromUri(uri: Uri): Result<File> {
    return try {
      val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: return Result.failure(IllegalArgumentException("تعذر قراءة الملف المحدد"))
      importBytes(bytes)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun saveVpnFromFile(file: File): Result<File> {
    return try {
      if (!file.isFile) return Result.failure(IllegalArgumentException("الملف غير موجود"))
      importBytes(file.readBytes())
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // No bundled/demo profile is silently installed. The user controls the active profile.
  fun saveVpnFromAssets(): File? = null
  fun ensureInternalVpnExists(): File? = getSavedVpnFile()

  fun parseRemoteInfo(file: File): String {
    return try {
      val line = file.readLines().firstOrNull { it.trim().startsWith("remote ") }
      if (line == null) "خادم غير محدد"
      else line.trim().removePrefix("remote ").trim().split(Regex("\\s+"))
        .take(2).joinToString(" ").ifBlank { "خادم غير محدد" }
    } catch (_: Exception) { "تعذر قراءة الخادم" }
  }

  fun deleteCurrent() {
    try {
      vpnDir().listFiles()?.filter { it.isFile }?.forEach { it.delete() }
    } catch (_: Exception) {}
    _currentFile.value = null
  }

  fun scanForVpnFiles(): List<File> {
    val roots = listOf(
      File("/storage/emulated/0/Download"),
      File("/storage/emulated/0/Downloads"),
      File("/storage/emulated/0/Documents"),
      File("/storage/usb0"), File("/storage/usb1"), File("/storage/usbotg"),
      File("/mnt/media_rw/usb0"), File("/mnt/media_rw/usb1"),
      File("/sdcard/Download")
    )
    val found = linkedMapOf<String, File>()
    roots.forEach { root ->
      try {
        if (!root.isDirectory || !root.canRead()) return@forEach
        root.walkTopDown().maxDepth(2).filter { f ->
          f.isFile && (f.extension.equals("ovpn", true) || f.extension.equals("conf", true)) &&
            f.length() in 101..(2 * 1024 * 1024)
        }.forEach { f ->
          val key = try { f.canonicalPath } catch (_: Exception) { f.absolutePath }
          found[key] = f
        }
      } catch (_: Exception) {}
    }
    return found.values.sortedByDescending { it.lastModified() }.take(30)
  }

  fun getInternalFileInfo(): String {
    val file = getSavedVpnFile() ?: return "لا يوجد ملف VPN مستورد"
    return "${file.name} - ${file.length()} بايت - ${parseRemoteInfo(file)}"
  }
}
