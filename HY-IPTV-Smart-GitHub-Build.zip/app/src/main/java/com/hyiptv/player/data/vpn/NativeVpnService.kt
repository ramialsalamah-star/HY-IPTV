package com.hyiptv.player.data.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.hyiptv.player.MainActivity
import com.hyiptv.player.R
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

class NativeVpnService : VpnService() {

  companion object {
    const val ACTION_START = "com.hyiptv.player.action.START_VPN"
    const val ACTION_STOP = "com.hyiptv.player.action.STOP_VPN"
    const val EXTRA_CONFIG_PATH = "config_path"
    @Volatile var isRunning = false
    @Volatile var isConnected = false
    @Volatile var currentServerInfo: String = ""
  }

  private var vpnInterface: ParcelFileDescriptor? = null
  private var openvpnProcess: Process? = null
  private var isStopping = false
  private var tunFd: Int = -1

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_START -> {
        val configPath = intent.getStringExtra(EXTRA_CONFIG_PATH)
        if (configPath != null) {
          startRealVpn(configPath)
        }
      }
      ACTION_STOP -> {
        stopRealVpn()
      }
    }
    return START_STICKY
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        "vpn_channel",
        "VPN Service",
        NotificationManager.IMPORTANCE_LOW
      )
      val nm = getSystemService(NotificationManager::class.java)
      nm.createNotificationChannel(channel)
    }
  }

  private fun createNotification(connected: Boolean, serverInfo: String): Notification {
    val intent = Intent(this, MainActivity::class.java)
    val pendingIntent = PendingIntent.getActivity(
      this, 0, intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    
    val text = if (connected) "متصل حقيقي: $serverInfo - VPN يعمل" else "جاري الاتصال: $serverInfo"
    
    return NotificationCompat.Builder(this, "vpn_channel")
      .setContentTitle("HY IPTV VPN - حقيقي")
      .setContentText(text)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setContentIntent(pendingIntent)
      .setOngoing(true)
      .build()
  }

  private fun getOpenVpnBinary(): File? {
    return try {
      val filesDir = filesDir
      val binaryFile = File(filesDir, "openvpn_binary")
      
      val abis = Build.SUPPORTED_ABIS
      var found = false
      
      for (abi in abis) {
        try {
          val assetName = "pie_openvpn.$abi"
          assets.open(assetName).use { input ->
            FileOutputStream(binaryFile).use { output ->
              input.copyTo(output)
            }
            found = true
          }
          if (found) break
        } catch (_: Exception) {}
      }
      
      if (!found) {
        for (abi in abis) {
          try {
            val assetName = "openvpn.$abi"
            assets.open(assetName).use { input ->
              FileOutputStream(binaryFile).use { output ->
                input.copyTo(output)
              }
              found = true
            }
            if (found) break
          } catch (_: Exception) {}
        }
      }
      
      if (!found && binaryFile.exists() && binaryFile.length() > 100000) {
        found = true
      }
      
      if (found && binaryFile.exists()) {
        binaryFile.setExecutable(true)
        if (binaryFile.length() > 100000) {
          binaryFile
        } else {
          null
        }
      } else {
        null
      }
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  private fun getFdFromParcel(pfd: ParcelFileDescriptor): Int {
    return try {
      // حاول عبر reflection - getFd() مخفي
      val method: Method = ParcelFileDescriptor::class.java.getMethod("getFd")
      method.invoke(pfd) as Int
    } catch (e: Exception) {
      try {
        // جرب detachFd
        val method: Method = ParcelFileDescriptor::class.java.getMethod("detachFd")
        val fd = method.invoke(pfd) as Int
        // لا تسكر pfd بعد detach - نحن نملك fd الآن
        fd
      } catch (e2: Exception) {
        -1
      }
    }
  }

  private fun startRealVpn(configPath: String) {
    if (isRunning) {
      stopRealVpn()
      Thread.sleep(500)
    }
    
    isStopping = false
    
    try {
      val configFile = File(configPath)
      if (!configFile.exists() || configFile.length() < 100) {
        stopSelf()
        return
      }

      val serverInfo = try {
        val text = configFile.readText()
        val remoteLine = text.lines().firstOrNull { it.trim().startsWith("remote ") }?.trim() ?: "fr1.vpnjantit.com 2501"
        val parts = remoteLine.removePrefix("remote ").trim().split(" ").filter { it.isNotBlank() }
        if (parts.size >= 2) "${parts[0]} ${parts[1]}" else parts.firstOrNull() ?: "fr1.vpnjantit.com 2501"
      } catch (_: Exception) {
        "fr1.vpnjantit.com 2501"
      }
      
      currentServerInfo = serverInfo
      RealVpnHelper.currentServerInfo = serverInfo

      val binary = getOpenVpnBinary()
      
      if (binary != null && binary.exists()) {
        try {
          // أنشئ TUN interface حقيقي
          val builder = Builder()
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("8.8.4.4")
            .addDnsServer("1.1.1.1")
            .setSession("HY IPTV VPN")
            .setMtu(1500)
            .setBlocking(false)
          
          vpnInterface = builder.establish()
          
          if (vpnInterface != null) {
            // احصل على fd
            tunFd = getFdFromParcel(vpnInterface!!)
            
            if (tunFd == -1) {
              // جرب طريقة بديلة - استخدم fd 3 أو 4
              tunFd = vpnInterface!!.fd
            }
            
            android.util.Log.d("HY_VPN", "TUN fd: $tunFd")
            
            if (tunFd != -1) {
              // شغل OpenVPN مع TUN fd الحقيقي - هذا يجعله VPN حقيقي 100%
              val cmd = mutableListOf<String>()
              cmd.add(binary.absolutePath)
              cmd.add("--config")
              cmd.add(configPath)
              cmd.add("--dev")
              cmd.add("tun")
              cmd.add("--verb")
              cmd.add("3")
              cmd.add("--script-security")
              cmd.add("2")
              cmd.add("--route-noexec")
              cmd.add("--ifconfig-noexec")
              cmd.add("--tun-fd")
              cmd.add(tunFd.toString())
              // أضف management للتتبع
              cmd.add("--management")
              cmd.add("127.0.0.1")
              cmd.add("6001")
              
              android.util.Log.d("HY_VPN", "Starting OpenVPN: ${cmd.joinToString(" ")}")
              
              val processBuilder = ProcessBuilder(cmd)
              processBuilder.redirectErrorStream(true)
              
              // اضبط البيئة
              val env = processBuilder.environment()
              env["LD_LIBRARY_PATH"] = applicationInfo.nativeLibraryDir
              
              openvpnProcess = processBuilder.start()
              
              // اقرأ output
              Thread {
                try {
                  val reader = BufferedReader(InputStreamReader(openvpnProcess!!.inputStream))
                  var line: String?
                  while (reader.readLine().also { line = it } != null) {
                    if (isStopping) break
                    android.util.Log.d("HY_VPN", line ?: "")
                    // إذا ظهر "Initialization Sequence Completed" يعني متصل حقيقي
                    if (line?.contains("Initialization Sequence Completed") == true) {
                      isConnected = true
                      isRunning = true
                      RealVpnHelper.isRunning = true
                      android.util.Log.d("HY_VPN", "OpenVPN initialization completed")
                    }
                  }
                } catch (_: Exception) {}
              }.start()
              
              Thread.sleep(1500)
              
              // تحقق إذا العملية شغالة
              val isAlive = try { openvpnProcess?.isAlive ?: false } catch (_: Exception) { true }
              
              if (isAlive) {
                isRunning = true
                RealVpnHelper.isRunning = true
                
                val notification = createNotification(true, serverInfo)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                  startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
                } else {
                  startForeground(1, notification)
                }
                
                // راقب العملية - إذا ماتت، أوقف VPN
                Thread {
                  try {
                    openvpnProcess?.waitFor()
                    if (!isStopping) {
                      android.util.Log.d("HY_VPN", "OpenVPN process ended")
                      stopRealVpn()
                    }
                  } catch (_: Exception) {}
                }.start()
                
                // حافظ على TUN مفتوح
                Thread {
                  try {
                    while (!isStopping && isRunning) {
                      Thread.sleep(1000)
                    }
                  } catch (_: Exception) {}
                }.start()
                
                return
              }
            }
          }
        } catch (e: Exception) {
          e.printStackTrace()
          android.util.Log.e("HY_VPN", "Failed to start real VPN: ${e.message}")
          try { vpnInterface?.close() } catch (_: Exception) {}
          vpnInterface = null
        }
      }
      
      // إذا فشل binary، جرب طريقة بديلة: استخدم TUN بدون binary لكن مع routing حقيقي
      // هذا لا يزال يقطع النت إذا ما فيه forwarding، لذا لا نفتحه
      // بدلاً من ذلك، نعرض رسالة أن VPN يحتاج binary
      isRunning = false
      RealVpnHelper.isRunning = false
      
      // لا نبدأ foreground إذا فشل
      stopSelf()
      
    } catch (e: Exception) {
      e.printStackTrace()
      stopRealVpn()
    }
  }

  private fun stopRealVpn() {
    isStopping = true
    isRunning = false
    isConnected = false
    RealVpnHelper.isRunning = false
    currentServerInfo = ""
    RealVpnHelper.currentServerInfo = ""
    
    try {
      openvpnProcess?.destroy()
      openvpnProcess?.waitFor(1000, java.util.concurrent.TimeUnit.MILLISECONDS)
      try { openvpnProcess?.destroyForcibly() } catch (_: Exception) {}
    } catch (_: Exception) {}
    openvpnProcess = null
    
    try {
      vpnInterface?.close()
    } catch (_: Exception) {}
    vpnInterface = null
    tunFd = -1
    
    try {
      stopForeground(STOP_FOREGROUND_REMOVE)
    } catch (_: Exception) {
      try { stopForeground(true) } catch (_: Exception) {}
    }
    stopSelf()
  }

  override fun onDestroy() {
    stopRealVpn()
    super.onDestroy()
  }

  override fun onRevoke() {
    stopRealVpn()
    super.onRevoke()
  }
}
