package com.hyiptv.player.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
  tableName = "channels",
  indices = [
    Index(value = ["groupName"]),
    Index(value = ["name"]),
    Index(value = ["isFavorite"]),
    Index(value = ["contentType"])
  ]
)
data class ChannelEntity(
  @PrimaryKey val id: String,
  val name: String,
  val streamUrl: String,
  val logoUrl: String? = null,
  val groupName: String = "Uncategorized",
  val epgId: String? = null,
  val isFavorite: Boolean = false,
  val lastWatched: Long = 0L,
  val sourceType: String = "m3u",
  val contentType: String = "live" // live | movie | series
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
  @PrimaryKey val channelId: String,
  val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent")
data class RecentEntity(
  @PrimaryKey val channelId: String,
  val watchedAt: Long = System.currentTimeMillis(),
  val positionMs: Long = 0L
)


data class GroupCount(
  val name: String,
  val count: Int
)
