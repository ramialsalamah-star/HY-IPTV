package com.hyiptv.player.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.hyiptv.player.data.remote.XtreamApi
import com.hyiptv.player.data.model.Playlist
import com.hyiptv.player.data.model.PlaylistType
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

private val Context.xtreamDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "xtream_config")

private fun String.normalizedForComparison(): String {
  var s = trim()

  if (s.endsWith("/")) {
    s = s.dropLast(1)
  }

  s = s.removeSuffix("/player_api.php")
  s = s.removeSuffix("/xmltv.php")
  s = s.removeSuffix("/get.php")

  if (s.startsWith("https://", ignoreCase = true)) {
    s = "http://" + s.substring(8)
  }

  return s.lowercase()
}

class XtreamRepository(private val context: Context) {

  private val api = XtreamApi()
  private val channelRepo = ChannelRepository(context)
  private val gson = Gson()

  private val KEY_SERVER = stringPreferencesKey("server")
  private val KEY_USER = stringPreferencesKey("user")
  private val KEY_PASS = stringPreferencesKey("pass")

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _error = MutableStateFlow<String?>(null)
  val error: StateFlow<String?> = _error.asStateFlow()

  private val _status = MutableStateFlow<String?>(null)
  val status: StateFlow<String?> = _status.asStateFlow()

  suspend fun getSavedConfig(): XtreamApi.XtreamConfig? {
    val prefs = context.xtreamDataStore.data.first()

    val server = prefs[KEY_SERVER] ?: return null
    val user = prefs[KEY_USER] ?: return null
    val pass = prefs[KEY_PASS] ?: return null

    return XtreamApi.XtreamConfig(server, user, pass)
  }

  suspend fun saveConfig(config: XtreamApi.XtreamConfig) {
    context.xtreamDataStore.edit { prefs ->
      prefs[KEY_SERVER] = config.serverUrl
      prefs[KEY_USER] = config.username
      prefs[KEY_PASS] = config.password
    }
  }

  suspend fun clearSavedConfigIfMatches(
    config: XtreamApi.XtreamConfig
  ) {
    context.xtreamDataStore.edit { prefs ->

      val matches =
        prefs[KEY_SERVER]?.normalizedForComparison() ==
          config.serverUrl.normalizedForComparison() &&
        prefs[KEY_USER]?.trim() == config.username.trim() &&
        prefs[KEY_PASS]?.trim() == config.password.trim()

      if (matches) {
        prefs.remove(KEY_SERVER)
        prefs.remove(KEY_USER)
        prefs.remove(KEY_PASS)
      }
    }
  }

  /**
   * Remove channels belonging to previous sources before
   * storing the newly activated Xtream playlist.
   *
   * The current playlist ID is preserved as the target
   * source. Other saved playlist sources are purged.
   */
  private suspend fun purgeOtherSources(currentId: String) {

    // Remove legacy source names.
    channelRepo.removeSource("m3u")
    channelRepo.removeSource("xtream")
    channelRepo.removeSource("stalker")

    // Remove all previously stored playlist sources.
    channelRepo.clearPlaylistSources()

    // Remove individual saved playlist and Stalker sources.
    val playlists = PlaylistRepository(context).getPlaylists()

    playlists
      .filter { it.id != currentId }
      .forEach { other ->

        channelRepo.removeSource("playlist_${other.id}")

        channelRepo.removeSource("stalker_${other.id}")
      }
  }

  suspend fun connectAndLoad(
    server: String,
    username: String,
    password: String
  ): Result<Int> {

    val config = XtreamApi.XtreamConfig(
      server,
      username,
      password
    )

    _isLoading.value = true
    _error.value = null
    _status.value = null

    return try {

      val test = api.testConnection(config)

      if (test.isFailure) {
        val message = test.exceptionOrNull()?.message
          ?: "Connection failed"

        _error.value = message

        return Result.failure(Exception(message))
      }

      val playlistId = UUID.randomUUID().toString()

      val result = loadAndStore(
        config = config,
        playlistId = playlistId
      )

      if (result.isSuccess) {

        saveConfig(config)

        PlaylistRepository(context).savePlaylist(
          Playlist(
            id = playlistId,
            name = "Xtream - $username",
            type = PlaylistType.XTREAM,
            username = username,
            password = password,
            serverUrl = server,
            isActive = true
          )
        )
      }

      result

    } catch (error: Exception) {

      _error.value = error.message

      Result.failure(error)

    } finally {

      _isLoading.value = false
    }
  }

  suspend fun loadExistingPlaylist(
    playlist: Playlist
  ): Result<Int> {

    if (playlist.type != PlaylistType.XTREAM) {
      return Result.failure(
        Exception("نوع القائمة غير مدعوم")
      )
    }

    val config = XtreamApi.XtreamConfig(
      playlist.serverUrl,
      playlist.username,
      playlist.password
    )

    _isLoading.value = true
    _error.value = null
    _status.value = null

    return try {

      val test = api.testConnection(config)

      if (test.isFailure) {
        return Result.failure(
          test.exceptionOrNull()
            ?: Exception("Connection failed")
        )
      }

      loadAndStore(
        config = config,
        playlistId = playlist.id
      ).also { result ->

        result.onSuccess {
          saveConfig(config)

          PlaylistRepository(context)
            .setActivePlaylist(playlist.id)
        }
      }

    } catch (error: Exception) {

      _error.value = error.message

      Result.failure(error)

    } finally {

      _isLoading.value = false
    }
  }

  private suspend fun loadAndStore(
    config: XtreamApi.XtreamConfig,
    playlistId: String
  ): Result<Int> {

    _status.value = "Connected. Loading channels…"

    // Load Live TV.
    val live = api.getLiveStreams(config)

    if (live.isFailure) {

      val message = live.exceptionOrNull()?.message
        ?: "Failed to load channels"

      _error.value = message

      return Result.failure(Exception(message))
    }

    val channels = live.getOrThrow().map { channel ->

      channel.copy(
        id = "${playlistId}_${channel.id}",
        contentType = "live"
      )
    }

    // Load movies.
    val moviesResult = api.getVodStreams(config)

    val movies = moviesResult.getOrNull()?.map { movie ->

      com.hyiptv.player.data.model.Channel(
        id = "${playlistId}_${movie.id}",
        name = movie.name,
        streamUrl = movie.streamUrl,
        logoUrl = movie.posterUrl,
        group = movie.genre ?: "Movies",
        contentType = "movie"
      )

    } ?: emptyList()

    // Load series.
    val seriesResult = api.getSeries(config)

    val seriesError = seriesResult.exceptionOrNull()?.message

    val series = seriesResult.getOrNull()?.map { item ->

      val rawId = item.id.removePrefix("series_")

      com.hyiptv.player.data.model.Channel(
        id = "${playlistId}_series_$rawId",
        name = item.name,
        streamUrl = "series://$rawId",
        logoUrl = item.posterUrl,
        group = item.genre ?: "Series",
        contentType = "series"
      )

    } ?: emptyList()

    // Do not delete previous sources if the provider
    // returned no usable content.
    if (
      channels.isEmpty() &&
      movies.isEmpty() &&
      series.isEmpty()
    ) {

      val message =
        seriesError
          ?: moviesResult.exceptionOrNull()?.message
          ?: "لم يتم العثور على محتوى"

      _error.value = message

      return Result.failure(Exception(message))
    }

    // IMPORTANT:
    // Purge old sources only after successfully retrieving
    // the new provider content, immediately before storing.
    purgeOtherSources(playlistId)

    // Store the new Xtream content under its own source ID.
    val count = channelRepo.replaceChannels(
      channels + movies + series,
      sourceType = "playlist_$playlistId"
    )

    // Activate this playlist.
    PlaylistRepository(context).setActivePlaylist(playlistId)

    _status.value =
      "Live: ${channels.size}, Movies: ${movies.size}, Series: ${series.size}"

    if (seriesResult.isFailure) {

      _error.value =
        "تم حفظ القنوات والأفلام. تعذر تحميل المسلسلات: " +
          (seriesError ?: "خطأ غير معروف")

      _status.value =
        "Live: ${channels.size}, Movies: ${movies.size}. فشل جلب المسلسلات"

    } else if (series.isEmpty()) {

      _status.value =
        "تم الاتصال، لكن مزود الخدمة أعاد 0 مسلسل. " +
          "Live: ${channels.size}, Movies: ${movies.size}"
    }

    if (moviesResult.isFailure) {

      val movieError =
        "تعذر تحميل الأفلام: " +
          (moviesResult.exceptionOrNull()?.message
            ?: "خطأ غير معروف")

      _error.value =
        if (_error.value == null) {
          movieError
        } else {
          "${_error.value}\n$movieError"
        }
    }

    return Result.success(count)
  }

  suspend fun getSeriesEpisodes(
    seriesId: String
  ): Result<List<com.hyiptv.player.data.model.Episode>> {

    val config = getSavedConfig()
      ?: return Result.failure(
        Exception("بيانات Xtream غير محفوظة")
      )

    return api.getSeriesEpisodes(config, seriesId)
  }

  fun clearError() {
    _error.value = null
  }
}
