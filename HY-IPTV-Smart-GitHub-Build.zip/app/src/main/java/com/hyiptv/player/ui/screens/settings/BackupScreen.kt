package com.hyiptv.player.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hyiptv.player.data.repository.BackupRepository
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val backupRepo = remember { BackupRepository(context) }
  val channelRepo = remember { ChannelRepository(context) }
  val scope = rememberCoroutineScope()

  var channelCount by remember { mutableStateOf(0) }
  var backupFiles by remember { mutableStateOf<List<File>>(emptyList()) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }
  var isWorking by remember { mutableStateOf(false) }
  val folderPath = remember { backupRepo.getBackupFolderPath() }

  fun refresh() {
    scope.launch {
      channelCount = channelRepo.getChannelCount()
      backupFiles = backupRepo.listBackupFiles()
    }
  }

  LaunchedEffect(Unit) { refresh() }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(BlackBackground)
  ) {
    TopAppBar(
      title = {
        Text("Backup & Restore", color = GoldPrimary, fontWeight = FontWeight.Bold)
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalSurface)
    )

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Status card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, GoldPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(Modifier.padding(16.dp)) {
          Text(
            text = "Channels in database: $channelCount",
            color = TextPrimary,
            fontWeight = FontWeight.Medium
          )
          Spacer(Modifier.height(6.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
              text = folderPath,
              color = TextSecondary,
              style = MaterialTheme.typography.bodySmall
            )
          }
          Spacer(Modifier.height(4.dp))
          Text(
            text = "انسخ ملفات النسخ الاحتياطي من هذا المجلد قبل حذف التطبيق، ثم استوردها بعد إعادة التثبيت.",
            color = TextMuted,
            style = MaterialTheme.typography.bodySmall
          )
        }
      }

      // Export button
      Button(
        onClick = {
          isWorking = true
          message = null
          scope.launch {
            val result = backupRepo.exportToFile()
            isWorking = false
            result.onSuccess { file ->
              message = "Exported successfully:\n${file.name}"
              isError = false
              refresh()
            }.onFailure { e ->
              message = e.message ?: "Export failed"
              isError = true
            }
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp),
        enabled = !isWorking && channelCount > 0,
        colors = ButtonDefaults.buttonColors(
          containerColor = GoldPrimary,
          contentColor = BlackBackground
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        if (isWorking) {
          CircularProgressIndicator(Modifier.size(22.dp), color = BlackBackground, strokeWidth = 2.dp)
        } else {
          Icon(Icons.Default.Upload, null)
          Spacer(Modifier.width(8.dp))
          Text("Export Channels & Favorites", fontWeight = FontWeight.Bold)
        }
      }

      message?.let {
        Text(
          text = it,
          color = if (isError) ErrorRed else SuccessGreen,
          style = MaterialTheme.typography.bodyMedium
        )
      }

      Text(
        text = "Available backups",
        color = GoldAccent,
        style = MaterialTheme.typography.labelLarge
      )

      if (backupFiles.isEmpty()) {
        Text("No backup files found", color = TextMuted)
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          items(backupFiles, key = { it.absolutePath }) { file ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DividerColor, RoundedCornerShape(10.dp)),
              colors = CardDefaults.cardColors(containerColor = CardBackground),
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(Modifier.weight(1f)) {
                  Text(
                    text = file.name,
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyMedium
                  )
                  Text(
                    text = "${file.length() / 1024} KB",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodySmall
                  )
                }
                Button(
                  onClick = {
                    isWorking = true
                    message = null
                    scope.launch {
                      val result = backupRepo.importFromFile(file)
                      isWorking = false
                      result.onSuccess { count ->
                        message = "Imported $count channels"
                        isError = false
                        refresh()
                      }.onFailure { e ->
                        message = e.message ?: "Import failed"
                        isError = true
                      }
                    }
                  },
                  enabled = !isWorking,
                  colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = BlackBackground
                  ),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                  Icon(Icons.Default.Download, null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(4.dp))
                  Text("Import")
                }
              }
            }
          }
        }
      }
    }
  }
}
