package com.hyiptv.player.ui.screens.series

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as lazyColumnItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.hyiptv.player.R
import com.hyiptv.player.data.model.Channel
import com.hyiptv.player.data.model.Episode
import com.hyiptv.player.data.repository.ChannelRepository
import com.hyiptv.player.data.repository.PlaylistRepository
import com.hyiptv.player.data.repository.XtreamRepository
import com.hyiptv.player.ui.theme.*
import com.hyiptv.player.util.WatchProgressManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
@OptIn(ExperimentalFoundationApi::class)
fun SeriesScreen(
  onBack: () -> Unit,
  onPlay: (Channel) -> Unit = {}
) {
  val context = LocalContext.current
    var longPressFavMessage by remember { mutableStateOf<String?>(null) }
    val hapticFeedback = LocalHapticFeedback.current
    LaunchedEffect(longPressFavMessage) {
        if (longPressFavMessage != null) {
            kotlinx.coroutines.delay(2500)
            longPressFavMessage = null
        }
    }
  val repo = remember { ChannelRepository(context) }
  val xtreamRepository = remember { XtreamRepository(context) }
  val progressManager = remember { WatchProgressManager(context) }
  val lifecycleOwner = LocalLifecycleOwner.current
  var progressByUrl by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
  val scope = rememberCoroutineScope()
  val gridState = rememberLazyGridState()

  var items by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var total by remember { mutableStateOf(0) }
  var query by remember { mutableStateOf("") }
  var page by remember { mutableStateOf(0) }
  var loading by remember { mutableStateOf(true) }
  var loadingMore by remember { mutableStateOf(false) }
  var end by remember { mutableStateOf(false) }
  var searchOpen by remember { mutableStateOf(false) }
  // Persist the selected series and its episode list while the Player destination
  // is on top of the navigation stack. Plain remember{} is disposed when navigating
  // away and caused Back from playback to reopen the series catalogue.
  val selectedSeriesSaver = remember {
    Saver<Channel?, List<Any?>>(save = { channel ->
      channel?.let { listOf(it.id, it.name, it.streamUrl, it.logoUrl, it.group, it.epgId, it.isFavorite, it.contentType) }
    }, restore = { saved ->
      if (saved.size >= 8) Channel(
        id = saved[0] as String,
        name = saved[1] as String,
        streamUrl = saved[2] as String,
        logoUrl = saved[3] as String?,
        group = saved[4] as String,
        epgId = saved[5] as String?,
        isFavorite = saved[6] as Boolean,
        contentType = saved[7] as String
      ) else null
    })
  }
  val episodesSaver = remember {
    listSaver<List<Episode>, Any>(
      save = { list -> list.map { episode ->
        listOf(episode.id, episode.name, episode.streamUrl, episode.episodeNumber, episode.seasonNumber, episode.plot)
      } },
      restore = { saved -> saved.mapNotNull { row ->
        val values = row as? List<*> ?: return@mapNotNull null
        if (values.size < 6) return@mapNotNull null
        Episode(
          id = values[0] as String,
          name = values[1] as String,
          streamUrl = values[2] as String,
          episodeNumber = values[3] as Int,
          seasonNumber = values[4] as Int,
          plot = values[5] as String?
        )
      } }
    )
  }
  var selectedSeries by rememberSaveable(stateSaver = selectedSeriesSaver) { mutableStateOf<Channel?>(null) }
  // Keep the last selected/playing series highlighted when returning from the player.
  var currentSeriesId by rememberSaveable { mutableStateOf<String?>(null) }
  var episodes by rememberSaveable(stateSaver = episodesSaver) { mutableStateOf<List<Episode>>(emptyList()) }
  var loadingEpisodes by remember { mutableStateOf(false) }
  var episodeError by remember { mutableStateOf<String?>(null) }
  var refreshingXtream by remember { mutableStateOf(false) }
  var refreshMessage by remember { mutableStateOf<String?>(null) }
  var favorites by remember { mutableStateOf<List<Channel>>(emptyList()) }
  var showOnlyFavorites by remember { mutableStateOf(false) }
  var restoreFocusAfterDetails by remember { mutableStateOf(false) }

  // Handle Back inside the series screen before Navigation can pop the whole screen.
  // First leave the episode/details view; only a second Back returns to the home screen.
  BackHandler {
    if (selectedSeries != null) {
      selectedSeries = null
      restoreFocusAfterDetails = true
      episodes = emptyList()
      episodeError = null
      loadingEpisodes = false
    } else {
      onBack()
    }
  }

  fun loadFirst() {
    scope.launch {
      loading = true
      end = false
      page = 0
      total = repo.getSeriesCount()
      favorites = repo.getFavorites().filter { it.contentType == "series" }
      val result = if (showOnlyFavorites) favorites else repo.loadPage(query = query, page = 0, contentType = "series")
      items = result
      end = result.size < ChannelRepository.PAGE_SIZE || showOnlyFavorites
      loading = false
    }
  }

  fun toggleFavorite(channel: Channel) {
    scope.launch {
      val nowFavorite = repo.toggleFavorite(channel.id)
      favorites = repo.getFavorites().filter { it.contentType == "series" }
      if (showOnlyFavorites) items = favorites
      Toast.makeText(
        context,
        if (nowFavorite) "تمت إضافة ${channel.name} إلى المفضلة" else "تمت إزالة ${channel.name} من المفضلة",
        Toast.LENGTH_SHORT
      ).show()
    }
  }

  fun refreshXtreamSeries() {
    scope.launch {
      refreshingXtream = true
      refreshMessage = null
      val active = PlaylistRepository(context).getPlaylists().firstOrNull { it.isActive }
      if (active == null) {
        refreshMessage = "لا توجد قائمة نشطة"
      } else {
        val result = xtreamRepository.loadExistingPlaylist(active)
        result.onSuccess { count -> refreshMessage = "اكتمل التحديث: $count عنصر" }
          .onFailure { error -> refreshMessage = error.message ?: "تعذر التحديث" }
        loadFirst()
      }
      refreshingXtream = false
    }
  }

  fun loadMore() {
    if (loadingMore || end || showOnlyFavorites) return
    scope.launch {
      loadingMore = true
      val next = page + 1
      val more = repo.loadPage(query = query, page = next, contentType = "series")
      if (more.isEmpty() || more.size < ChannelRepository.PAGE_SIZE) end = true
      if (more.isNotEmpty()) {
        items = items + more
        page = next
      }
      loadingMore = false
    }
  }

  // Refresh every episode independently whenever the episode list changes or the
  // player returns to the foreground. SharedPreferences reads alone do not trigger
  // Compose recomposition, so keep a state snapshot for all episode URLs.
  LaunchedEffect(episodes) {
    progressByUrl = episodes.associate { episode ->
      episode.streamUrl to progressManager.getProgressPercent(episode.streamUrl)
    }
  }
  DisposableEffect(lifecycleOwner, episodes) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME && episodes.isNotEmpty()) {
        progressByUrl = episodes.associate { episode ->
          episode.streamUrl to progressManager.getProgressPercent(episode.streamUrl)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  LaunchedEffect(query, showOnlyFavorites) { loadFirst() }
  LaunchedEffect(gridState) {
    snapshotFlow {
      val info = gridState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
      last >= info.totalItemsCount - 4
    }.collect { nearEnd -> if (nearEnd) loadMore() }
  }

  // FULL SCREEN DETAILS - لما نضغط على مسلسل ندخل جوا شاشة كاملة
  if (selectedSeries != null) {
    val series = selectedSeries!!
    val firstEpisodeFocus = remember { FocusRequester() }
    val watchedCount = episodes.count { (progressByUrl[it.streamUrl] ?: 0) >= 90 }

    LaunchedEffect(episodes) {
      if (episodes.isNotEmpty()) {
        delay(400)
        try { firstEpisodeFocus.requestFocus() } catch (_: Exception) {}
      }
    }

    Box(Modifier.fillMaxSize().background(BlackBackground)) {
      Column(Modifier.fillMaxSize()) {
        // Top Bar
        TopAppBar(
          title = {
            Text(
              series.name,
              color = GoldPrimary,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          },
          navigationIcon = {
            IconButton(onClick = {
              selectedSeries = null
              restoreFocusAfterDetails = true
              episodes = emptyList()
            }) {
              Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                null,
                tint = GoldPrimary
              )
            }
          },
          actions = {
            val isFav = favorites.any { it.id == series.id }
            Card(
              modifier = Modifier
                .padding(end = 8.dp)
                .clickable { toggleFavorite(series) },
              colors = CardDefaults.cardColors(
                containerColor = if (isFav) Color(0xFF4CAF50) else GoldPrimary
              ),
              shape = RoundedCornerShape(8.dp),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                  contentDescription = "fav",
                  tint = if (isFav) Color.White else BlackBackground,
                  modifier = Modifier.size(18.dp)
                )
                Text(
                  text = if (isFav) "In Favorite ❤️" else "Add to Favorite 🤍",
                  color = if (isFav) Color.White else BlackBackground,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(containerColor = BlackBackground)
        )

        Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
          // Poster كبير على اليسار
          Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.width(320.dp).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = CardBackground)
          ) {
            Box(Modifier.fillMaxSize()) {
              if (!series.logoUrl.isNullOrBlank()) {
                AsyncImage(
                  model = series.logoUrl,
                  contentDescription = series.name,
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(Modifier.fillMaxSize().background(DarkSurface), contentAlignment = Alignment.Center) {
                  Text("HY", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 48.sp)
                }
              }
              Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, BlackBackground.copy(0.85f)))))
              // زر داخل المسلسل يظهر فوق البوستر للتوضيح
              // (طلب المستخدم: الضغط على البوستر = داخل مسلسل)
              androidx.compose.foundation.layout.Box(
                modifier = Modifier
                  .align(Alignment.BottomCenter)
                  .fillMaxWidth()
                  .background(Color.Black.copy(alpha = 0.6f))
                  .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
              ) {
                Text("داخل المسلسل", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
              }
              // Green rectangular return button stays attached to the active series poster.
              androidx.compose.material3.Button(
                onClick = {
                  selectedSeries = null
                  episodes = emptyList()
                  episodeError = null
                  loadingEpisodes = false
                },
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
              ) {
                Text("الرجوع إلى قائمة المسلسلات", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
              Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                Text(series.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 3)
                Spacer(Modifier.height(6.dp))
                Text(series.group.ifBlank { "مسلسل" }, color = GoldAccent, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text("الحلقات: ${episodes.size} • تمت مشاهدتها: $watchedCount", color = TextSecondary, fontSize = 12.sp)
              }
            }
          }

          // قائمة الحلقات على اليمين - شاشة كاملة
          Column(Modifier.weight(1f).fillMaxHeight()) {
            Text("الحلقات", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(bottom = 12.dp))

            when {
              loadingEpisodes -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  CircularProgressIndicator(color = GoldPrimary)
                  Spacer(Modifier.height(12.dp))
                  Text("جاري تحميل الحلقات...", color = TextMuted)
                }
              }
              episodeError != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(episodeError!!, color = ErrorRed, textAlign = TextAlign.Center)
              }
              episodes.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد حلقات", color = TextMuted)
              }
              else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
              ) {
                lazyColumnItems(episodes, key = { it.id }) { episode ->
                  val watchedPercent = progressByUrl[episode.streamUrl] ?: progressManager.getProgressPercent(episode.streamUrl)
                  val watched = watchedPercent >= 90
                  var focused by remember { mutableStateOf(false) }
                  val cleanName = episode.name.replace(Regex("^-+|-+$"), "").trim().ifBlank { "الحلقة ${episode.episodeNumber}" }
                  val isFirst = episodes.indexOf(episode) == 0

                  Card(
                    modifier = Modifier
                      .fillMaxWidth()
                      .onFocusChanged { focused = it.isFocused }
                      .border(
                        width = if (focused) 3.dp else 1.dp,
                        color = if (focused) Color(0xFF39E600) else if (watched) SuccessGreen.copy(0.5f) else DividerColor,
                        shape = RoundedCornerShape(12.dp)
                      )
                      .focusable()
                      .then(if (isFirst) Modifier.focusRequester(firstEpisodeFocus) else Modifier)
                      .clickable {
                        onPlay(Channel(id = episode.id, name = "${series.name} - $cleanName", streamUrl = episode.streamUrl, group = series.group, contentType = "series"))
                      },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                      containerColor = when {
                        focused -> Color(0xFF39E600).copy(alpha = 0.25f)
                        watched -> SuccessGreen.copy(alpha = 0.12f)
                        else -> CardBackground
                      }
                    )
                  ) {
                    // LTR shell fixes physical placement: play at the left, watch status at the far right.
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                      Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Box(
                          Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)).background(if (watched) SuccessGreen else GoldPrimary),
                          contentAlignment = Alignment.Center
                        ) {
                          if (watched) {
                            Text("✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                          } else {
                            Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(26.dp))
                          }
                        }
                        Spacer(Modifier.width(14.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                          Column(Modifier.weight(1f)) {
                            Text(
                              cleanName,
                              color = if (watched) SuccessGreen else if (focused) Color.White else TextPrimary,
                              fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium,
                              fontSize = 16.sp,
                              maxLines = 2,
                              overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                              Text(
                                "S${episode.seasonNumber} E${episode.episodeNumber}",
                                color = if (focused) GoldLight else TextMuted,
                                fontSize = 12.sp
                              )
                              if (watched) {
                                Spacer(Modifier.width(8.dp))
                                Text("تمت المشاهدة", color = SuccessGreen, fontSize = 11.sp)
                              }
                            }
                            if (watchedPercent in 1..99) {
                              Spacer(Modifier.height(7.dp))
                              LinearProgressIndicator(
                                progress = { watchedPercent / 100f },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp)),
                                color = GoldPrimary,
                                trackColor = DividerColor
                              )
                            }
                          }
                        }
                        if (watchedPercent > 0) {
                          Spacer(Modifier.width(12.dp))
                          Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                          ) {
                            Icon(
                              Icons.Default.Visibility,
                              contentDescription = "نسبة المشاهدة",
                              tint = if (watched) SuccessGreen else GoldPrimary,
                              modifier = Modifier.size(28.dp)
                            )
                            Text(
                              "${watchedPercent}%",
                              color = if (watched) SuccessGreen else GoldPrimary,
                              fontSize = 12.sp,
                              fontWeight = FontWeight.Bold
                            )
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return
  }

  // GRID SCREEN - شاشة المسلسلات الرئيسية
  Box(Modifier.fillMaxSize().background(BlackBackground)) {
    Column(Modifier.fillMaxSize().padding(start = 56.dp)) {
      TopAppBar(
        title = {
          if (searchOpen) {
            OutlinedTextField(
              value = query,
              onValueChange = { query = it },
              placeholder = { Text(stringResource(R.string.search), color = TextMuted) },
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary, unfocusedBorderColor = DividerColor,
                focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
                cursorColor = GoldPrimary, focusedContainerColor = DarkSurface, unfocusedContainerColor = DarkSurface
              ),
              modifier = Modifier.fillMaxWidth()
            )
          } else {
            Text("المسلسلات ($total)", color = GoldPrimary, fontWeight = FontWeight.Bold)
          }
        },
        navigationIcon = {
          IconButton(onClick = { if (searchOpen) searchOpen = false else onBack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = GoldPrimary)
          }
        },
        actions = {
          IconButton(onClick = { searchOpen = !searchOpen }) {
            Icon(Icons.Default.Search, null, tint = GoldPrimary)
          }
          IconButton(onClick = { refreshXtreamSeries() }) {
            Icon(Icons.Default.Refresh, null, tint = GoldPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = BlackBackground)
      )

      refreshMessage?.let {
        Text(it, color = GoldAccent, modifier = Modifier.padding(8.dp), fontSize = 12.sp)
      }

      when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = GoldPrimary)
        }
        items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.VideoLibrary, null, tint = GoldPrimary.copy(0.4f), modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.no_data), color = TextMuted)
          }
        }
        else -> LazyVerticalGrid(
          columns = GridCells.Adaptive(160.dp),
          state = gridState,
          contentPadding = PaddingValues(12.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(items, key = { it.id }) { item ->
            val isFav = favorites.any { it.id == item.id }
            val cardFocusRequester = remember(item.id) { FocusRequester() }
            var cardFocused by remember { mutableStateOf(false) }
            var remoteLongPressHandled by remember { mutableStateOf(false) }
            var remoteLongPressJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
            LaunchedEffect(restoreFocusAfterDetails, currentSeriesId, selectedSeries) {
              if (restoreFocusAfterDetails && selectedSeries == null && currentSeriesId == item.id) {
                delay(180)
                try { cardFocusRequester.requestFocus() } catch (_: Exception) { }
                restoreFocusAfterDetails = false
              }
            }


            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = CardBackground),
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .focusRequester(cardFocusRequester)
                .onFocusChanged { cardFocused = it.isFocused }
                .border(
                  width = if (cardFocused) 3.dp else 1.dp,
                  color = if (cardFocused) Color(0xFF39E600) else DividerColor,
                  shape = RoundedCornerShape(16.dp)
                )
                .focusable()
                .onPreviewKeyEvent { event ->
                  val isOk: Boolean = event.key == Key.DirectionCenter || event.key == Key.Enter || event.key == Key.NumPadEnter
                  if (!isOk) return@onPreviewKeyEvent false
                  return@onPreviewKeyEvent when (event.type) {
                    KeyEventType.KeyDown -> {
                      if (remoteLongPressJob == null && !remoteLongPressHandled) {
                        remoteLongPressJob = scope.launch {
                          delay(600)
                          remoteLongPressHandled = true
                          toggleFavorite(item)
                        }
                      }
                      false
                    }
                    KeyEventType.KeyUp -> {
                      remoteLongPressJob?.cancel()
                      remoteLongPressJob = null
                      val wasLongPress: Boolean = remoteLongPressHandled
                      remoteLongPressHandled = false
                      wasLongPress
                    }
                    else -> false
                  }
                }
                .combinedClickable(
                  onLongClick = { toggleFavorite(item) },
                  onClick = {
                    selectedSeries = item
                    currentSeriesId = item.id
                    episodes = emptyList()
                    episodeError = null
                    loadingEpisodes = true
                    scope.launch {
                      if (item.streamUrl.startsWith("series://")) {
                        val id = item.streamUrl.removePrefix("series://")
                        val result = xtreamRepository.getSeriesEpisodes(id)
                        loadingEpisodes = false
                        result.onSuccess { episodes = it }
                          .onFailure { episodeError = it.message ?: "تعذر تحميل الحلقات" }
                      } else {
                        loadingEpisodes = false
                        episodeError = "هذا العنصر ليس مسلسلاً"
                      }
                    }
                  }
                ),
            ) {
              Box(Modifier.fillMaxSize()) {
                // Poster
                if (!item.logoUrl.isNullOrBlank()) {
                  AsyncImage(
                    model = item.logoUrl,
                    contentDescription = item.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                  )
                } else {
                  Box(Modifier.fillMaxSize().background(DarkSurface), contentAlignment = Alignment.Center) {
                    Text("HY", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                  }
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, BlackBackground.copy(0.85f)))))

                // Visible one-tap favorite control on every series poster.
                Card(
                  modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).clickable { toggleFavorite(item) },
                  shape = RoundedCornerShape(7.dp),
                  colors = CardDefaults.cardColors(containerColor = if (isFav) Color(0xFF4CAF50) else Color(0xDD111111))
                ) {
                  Row(Modifier.padding(horizontal = 7.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (isFav) "In Favorite" else "Add to Favorite", tint = Color.White, modifier = Modifier.size(14.dp))
                    Text(if (isFav) "In Favorite" else "Add to Favorite", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                  }
                }

                // زر داخل المسلسل - تحت
                Box(
                  modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(vertical = 5.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text("داخل المسلسل", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }



                // اسم المسلسل
                Column(Modifier.align(Alignment.BottomStart).padding(start = 8.dp, end = 8.dp, bottom = 22.dp, top = 8.dp)) {
                  Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                  Spacer(Modifier.height(2.dp))
                  Text(item.group.ifBlank { "مسلسل" }, color = GoldAccent, fontSize = 9.sp, maxLines = 1)
                }
              }
            }
          }
        }
      }
    }
    // شريط المفضلة الجانبي على يسار شاشة المسلسلات
    Card(
      onClick = { showOnlyFavorites = !showOnlyFavorites },
      modifier = Modifier.align(Alignment.CenterStart).width(52.dp).fillMaxHeight()
        .padding(start = 6.dp, top = 8.dp, bottom = 8.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = if (showOnlyFavorites) Color(0xFF49351B) else CardBackground)
    ) {
      Column(
        Modifier.fillMaxSize().padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Icon(
          if (showOnlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
          contentDescription = "المفضلة",
          tint = if (showOnlyFavorites) Color(0xFF4CAF50) else GoldPrimary,
          modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
          "المفضلة",
          color = GoldPrimary,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          modifier = Modifier.graphicsLayer(rotationZ = -90f),
          maxLines = 1
        )
        Spacer(Modifier.height(12.dp))
        Text("${favorites.size}", color = TextSecondary, fontSize = 10.sp)
      }
    }
  }
}
