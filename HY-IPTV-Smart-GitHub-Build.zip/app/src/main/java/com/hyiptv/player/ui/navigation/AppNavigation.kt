package com.hyiptv.player.ui.navigation

import androidx.compose.runtime.*
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hyiptv.player.ui.screens.splash.SplashScreen
import com.hyiptv.player.ui.screens.connections.ConnectionsScreen
import com.hyiptv.player.ui.screens.favorites.FavoritesScreen
import com.hyiptv.player.ui.screens.history.WatchHistoryScreen
import com.hyiptv.player.ui.screens.home.HomeScreen
import com.hyiptv.player.ui.screens.live.LiveTvScreen
import com.hyiptv.player.ui.screens.movies.MoviesScreen
import com.hyiptv.player.ui.screens.player.PlayerScreen
import com.hyiptv.player.ui.screens.playlist.PlaylistScreen
import com.hyiptv.player.ui.screens.series.SeriesScreen
import com.hyiptv.player.ui.screens.settings.BackupScreen
import com.hyiptv.player.ui.screens.settings.SettingsScreen
import com.hyiptv.player.ui.screens.stalker.StalkerPortalScreen
import com.hyiptv.player.ui.screens.xtream.XtreamScreen
import com.hyiptv.player.ui.screens.search.SearchScreen
import com.hyiptv.player.ui.screens.vpn.VpnScreen
import androidx.compose.ui.platform.LocalContext
import com.hyiptv.player.util.LastChannelManager
import com.hyiptv.player.util.LiveTvStateManager
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class Screen(val route: String) {
  data object Home : Screen("home")
  data object Splash : Screen("splash")
  data object LiveTv : Screen("live_tv")
  data object Movies : Screen("movies")
  data object Series : Screen("series")
  data object Settings : Screen("settings")
  data object Playlist : Screen("playlist")
  data object Connections : Screen("connections")
  data object Stalker : Screen("stalker")
  data object Xtream : Screen("xtream")
  data object Favorites : Screen("favorites")
  data object WatchHistory : Screen("watch_history")
  data object Backup : Screen("backup")
  data object Search : Screen("search")
  data object Vpn : Screen("vpn")
  data object Player : Screen("player/{url}/{title}/{source}") {
    fun createRoute(url: String, title: String, source: String = "default"): String {
      val encodedUrl = URLEncoder.encode(url, StandardCharsets.UTF_8.toString())
      val encodedTitle = URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
      val encodedSource = URLEncoder.encode(source, StandardCharsets.UTF_8.toString())
      return "player/$encodedUrl/$encodedTitle/$encodedSource"
    }
  }
}

@Composable
fun AppNavigation() {
  val navController = rememberNavController()
  val context = LocalContext.current
  val lastChannelManager = remember { LastChannelManager(context) }
  val liveTvStateManager = remember { LiveTvStateManager(context) }

  NavHost(navController = navController, startDestination = Screen.Splash.route) {
    composable(Screen.Splash.route) {
      SplashScreen(
        onFinished = {
          // Always open the home screen on startup. Playback starts only
          // after the user explicitly selects a channel.
          navController.navigate(Screen.Home.route) {
            popUpTo(Screen.Splash.route) { inclusive = true }
            launchSingleTop = true
          }
        }
      )
    }
    composable(Screen.Home.route) {
      HomeScreen(
        onNavigateToLive = { navController.navigate(Screen.LiveTv.route) },
        onNavigateToMovies = { navController.navigate(Screen.Movies.route) },
        onNavigateToSeries = { navController.navigate(Screen.Series.route) },
        onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
        onNavigateToPlaylist = { navController.navigate(Screen.Connections.route) },
        onNavigateToStalker = { navController.navigate(Screen.Stalker.route) },
        onNavigateToXtream = { navController.navigate(Screen.Xtream.route) },
        onNavigateToFavorites = { navController.navigate(Screen.Favorites.route) },
        onNavigateToSearch = { navController.navigate(Screen.Search.route) },
        onNavigateToHistory = { navController.navigate(Screen.WatchHistory.route) }
      )
    }
    composable(Screen.LiveTv.route) {
      LiveTvScreen(
        // Return explicitly to Home. A plain popBackStack() can fail when
        // Live TV was opened from a restored/deep-link navigation state.
        onBack = {
          val returnedHome = navController.popBackStack(
            route = Screen.Home.route,
            inclusive = false
          )
          if (!returnedHome) {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.LiveTv.route) { inclusive = true }
              launchSingleTop = true
            }
          }
        },
        onPlayChannel = { ch ->
          liveTvStateManager.saveChannel(ch.id, ch.name, ch.streamUrl, ch.group)
          lastChannelManager.save(ch.streamUrl, ch.name, userSelected = true)
          navController.navigate(Screen.Player.createRoute(ch.streamUrl, ch.name, "live"))
        }
      )
    }
    composable(Screen.Movies.route) {
      MoviesScreen(
        onBack = { navController.popBackStack() },
        onPlay = { ch ->
          navController.navigate(Screen.Player.createRoute(ch.streamUrl, ch.name, "movie"))
        }
      )
    }
    composable(Screen.Series.route) {
      SeriesScreen(
        onBack = { navController.popBackStack() },
        onPlay = { ch ->
          navController.navigate(Screen.Player.createRoute(ch.streamUrl, ch.name, "series"))
        }
      )
    }
    composable(Screen.Settings.route) {
      SettingsScreen(
        onBack = { navController.popBackStack() },
        onNavigateToBackup = { navController.navigate(Screen.Backup.route) },
        onNavigateToPlaylist = { navController.navigate(Screen.Playlist.route) },
        onNavigateToVpn = { navController.navigate(Screen.Vpn.route) }
      )
    }
    composable(Screen.Playlist.route) {
      PlaylistScreen(
        onBack = { navController.popBackStack() },
        onPlaylistLoaded = {
          navController.navigate(Screen.LiveTv.route) {
            popUpTo(Screen.Home.route) { inclusive = false }
            launchSingleTop = true
          }
        }
      )
    }
    composable(Screen.Connections.route) {
      ConnectionsScreen(
        onBack = { navController.popBackStack() },
        onNavigateToXtream = { navController.navigate(Screen.Xtream.route) },
        onNavigateToM3u = { navController.navigate(Screen.Playlist.route) },
        onNavigateToStalker = { navController.navigate(Screen.Stalker.route) }
      )
    }
    composable(Screen.Stalker.route) {
      StalkerPortalScreen(
        onBack = { navController.popBackStack() },
        onConnected = {
          navController.navigate(Screen.LiveTv.route) {
            popUpTo(Screen.Home.route) { inclusive = false }
            launchSingleTop = true
          }
        }
      )
    }
    composable(Screen.Xtream.route) {
      XtreamScreen(
        onBack = { navController.popBackStack() },
        onConnected = {
          // The import is complete and the repository has committed the
          // playlist. Open Live TV immediately and remove the setup screens.
          navController.navigate(Screen.LiveTv.route) {
            popUpTo(Screen.Home.route) { inclusive = false }
            launchSingleTop = true
          }
        }
      )
    }
    composable(Screen.Favorites.route) {
      FavoritesScreen(
        onBack = { navController.popBackStack() },
        onPlayChannel = { ch ->
          val src = when {
            ch.contentType == "movie" -> "movie"
            ch.contentType == "series" -> "series"
            else -> "live"
          }
          if (src == "live") {
            liveTvStateManager.saveChannel(ch.id, ch.name, ch.streamUrl, ch.group)
            lastChannelManager.save(ch.streamUrl, ch.name, userSelected = true)
          }
          navController.navigate(Screen.Player.createRoute(ch.streamUrl, ch.name, src))
        }
      )
    }
    composable(Screen.Vpn.route) {
      VpnScreen(onBack = { navController.popBackStack() })
    }
    composable(Screen.Search.route) {
      SearchScreen(
        onBack = { navController.popBackStack() },
        onPlay = { ch ->
          val src = when {
            ch.contentType == "movie" -> "movie"
            ch.contentType == "series" -> "series"
            else -> "live"
          }
          navController.navigate(Screen.Player.createRoute(ch.streamUrl, ch.name, src))
        }
      )
    }
    composable(Screen.WatchHistory.route) {
      WatchHistoryScreen(
        onBack = { navController.popBackStack() },
        onPlay = { mediaId, title ->
          navController.navigate(Screen.Player.createRoute(mediaId, title, "default"))
        }
      )
    }
    composable(Screen.Backup.route) {
      BackupScreen(onBack = { navController.popBackStack() })
    }
    composable(
      Screen.Player.route,
      arguments = listOf(
        navArgument("url") { type = NavType.StringType },
        navArgument("title") { type = NavType.StringType },
        navArgument("source") { type = NavType.StringType; defaultValue = "default" }
      )
    ) { backStackEntry ->
      val encodedUrl = backStackEntry.arguments?.getString("url") ?: ""
      val encodedTitle = backStackEntry.arguments?.getString("title") ?: ""
      val encodedSource = backStackEntry.arguments?.getString("source") ?: "default"
      val url = URLDecoder.decode(encodedUrl, StandardCharsets.UTF_8.toString())
      val title = URLDecoder.decode(encodedTitle, StandardCharsets.UTF_8.toString())
      val source = URLDecoder.decode(encodedSource, StandardCharsets.UTF_8.toString())
      PlayerScreen(
        streamUrl = url,
        title = title,
        source = source,
        onBack = {
          // Pop only the player and keep the originating screen (including
          // the selected series and its episode list) on the back stack.
          val targetRoute = when (source) {
            "movie" -> Screen.Movies.route
            "series" -> Screen.Series.route
            else -> Screen.LiveTv.route
          }
          val returnedToSource = navController.popBackStack(
            route = targetRoute,
            inclusive = false
          )
          // If the originating screen is not on the stack (for example,
          // playback was opened from a deep link), recreate it exactly once.
          if (!returnedToSource) {
            navController.navigate(targetRoute) {
              launchSingleTop = true
            }
          }
        }
      )
    }
  }
}
