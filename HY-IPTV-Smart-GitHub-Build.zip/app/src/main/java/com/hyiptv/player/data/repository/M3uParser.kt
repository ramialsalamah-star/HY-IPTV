package com.hyiptv.player.data.repository

import android.content.Context
import android.net.Uri
import com.hyiptv.player.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit

class M3uParser {

  private val client by lazy {
    OkHttpClient.Builder()
      .connectTimeout(30, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .followRedirects(true)
      .followSslRedirects(true)
      .retryOnConnectionFailure(true)
      .build()
  }

  suspend fun parseFromUrl(url: String): Result<List<Channel>> = withContext(Dispatchers.IO) {
    try {
      val normalizedUrl = normalizePlaylistUrl(url)
      
      val request = Request.Builder()
        .url(normalizedUrl)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36")
        .header("Accept", "*/*")
        .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
        .header("Cache-Control", "no-cache")
        .header("Pragma", "no-cache")
        .get()
        .build()

      val response = client.newCall(request).execute()
      
      if (!response.isSuccessful) {
        return@withContext Result.failure(
          Exception("HTTP ${response.code}: تعذر تحميل القائمة - ${response.message}")
        )
      }

      val body = response.body
      if (body == null) {
        return@withContext Result.failure(Exception("الخادم لم يرجع بيانات"))
      }

      // FIX for "unexpected end of stream" - read as string with OkHttp which handles chunked encoding correctly
      val content = body.string()
      if (content.isBlank()) {
        return@withContext Result.failure(Exception("الملف فارغ"))
      }

      val channels = parseContent(
        BufferedReader(content.reader()),
        normalizedUrl
      )

      if (channels.isEmpty()) {
        Result.failure(Exception("الملف لا يحتوي على قنوات - تأكد من صحة الرابط"))
      } else {
        Result.success(channels)
      }
    } catch (e: Exception) {
      val msg = when {
        e.message?.contains("unexpected end of stream", ignoreCase = true) == true -> 
          "انقطع الاتصال أثناء التحميل - السيرفر مزدحم، حاول مرة أخرى"
        e.message?.contains("timeout", ignoreCase = true) == true ->
          "انتهت مهلة الاتصال - السيرفر بطيء، حاول مرة أخرى"
        e.message?.contains("Unable to resolve host", ignoreCase = true) == true ->
          "تعذر الوصول للسيرفر - تأكد من الإنترنت والرابط"
        else -> e.message ?: "فشل تحميل الرابط"
      }
      Result.failure(Exception(msg))
    }
  }

  suspend fun parseFromUri(context: Context, uri: Uri): Result<List<Channel>> =
    withContext(Dispatchers.IO) {
      try {
        val scheme = uri.scheme
        if (scheme == "file") {
          try {
            val path = uri.path
            if (path != null) {
              val file = java.io.File(path)
              if (file.exists() && file.canRead()) {
                val channels = file.bufferedReader(Charsets.UTF_8).use { r ->
                  parseContent(BufferedReader(r))
                }
                if (channels.isNotEmpty()) {
                  return@withContext Result.success(channels)
                }
              }
            }
          } catch (_: Exception) {}
        }
        val input: InputStream = try {
          context.contentResolver.openInputStream(uri)
        } catch (e: SecurityException) {
          return@withContext Result.failure(
            Exception("صلاحية الملف منتهية - أعد اختيار الملف من مدير الملفات أو انقله إلى مجلد التنزيلات")
          )
        } ?: return@withContext Result.failure(Exception("تعذر فتح الملف"))
        val channels = input.use { stream ->
          val buffered = stream.buffered()
          buffered.mark(4)
          val bom = ByteArray(3)
          val read = buffered.read(bom)
          val charset = when {
            read >= 3 && bom[0] == 0xEF.toByte() && bom[1] == 0xBB.toByte() && bom[2] == 0xBF.toByte() -> Charsets.UTF_8
            read >= 2 && bom[0] == 0xFF.toByte() && bom[1] == 0xFE.toByte() -> Charsets.UTF_16LE
            read >= 2 && bom[0] == 0xFE.toByte() && bom[1] == 0xFF.toByte() -> Charsets.UTF_16BE
            else -> Charsets.UTF_8
          }
          buffered.reset()
          if (charset == Charsets.UTF_8 && read >= 3 && bom[0] == 0xEF.toByte()) {
            buffered.skip(3)
          } else if (charset == Charsets.UTF_16LE || charset == Charsets.UTF_16BE) {
            buffered.skip(2)
          }
          parseContent(BufferedReader(InputStreamReader(buffered, charset)))
        }
        if (channels.isEmpty()) {
          Result.failure(Exception("الملف لا يحتوي على قنوات صالحة"))
        } else {
          Result.success(channels)
        }
      } catch (e: SecurityException) {
        Result.failure(Exception("صلاحية الملف مرفوضة (Android 9) - انقل الملف إلى Download واختره من هناك"))
      } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "فشل قراءة ملف M3U"))
      }
    }

  fun parseContent(reader: BufferedReader, baseUrl: String? = null): List<Channel> {
    val channels = mutableListOf<Channel>()
    var currentName = ""
    var currentTvgName: String? = null
    var currentLogo: String? = null
    var currentGroup = "Uncategorized"
    var currentEpgId: String? = null

    reader.forEachLine { rawLine ->
      val trimmed = rawLine.trim().removePrefix("\uFEFF").trim()
      when {
        trimmed.isEmpty() -> { /* skip */ }
        trimmed.startsWith("#EXTINF:", ignoreCase = true) -> {
          currentTvgName = extractAttribute(trimmed, "tvg-name")
          currentLogo = extractAttribute(trimmed, "tvg-logo")
          currentGroup = extractAttribute(trimmed, "group-title") ?: "Uncategorized"
          currentEpgId = extractAttribute(trimmed, "tvg-id")
          val commaIndex = trimmed.lastIndexOf(',')
          currentName = if (commaIndex >= 0 && commaIndex < trimmed.length - 1) {
            trimmed.substring(commaIndex + 1).trim()
          } else {
            currentTvgName?.takeIf { it.isNotBlank() } ?: "Unknown Channel"
          }
        }
        trimmed.startsWith("#") -> {
          // other tags ignored
        }
        else -> {
          val relative = baseUrl != null && !trimmed.contains(" ") && trimmed.contains("/")
          if (currentName.isNotEmpty() || trimmed.startsWith("http") || relative) {
            val name = currentName.ifBlank {
              currentTvgName?.takeIf { it.isNotBlank() } ?: "Channel ${channels.size + 1}"
            }
            val type = classify(currentGroup, name)
            val streamUrl = resolveStreamUrl(trimmed, baseUrl)
            channels.add(
              Channel(
                id = UUID.nameUUIDFromBytes(streamUrl.toByteArray(Charsets.UTF_8)).toString(),
                name = name,
                streamUrl = streamUrl,
                logoUrl = currentLogo,
                group = currentGroup,
                epgId = currentEpgId,
                contentType = type
              )
            )
          }
          currentName = ""
          currentTvgName = null
          currentLogo = null
          currentGroup = "Uncategorized"
          currentEpgId = null
        }
      }
    }
    // Prevent duplicate entries when a provider repeats the same stream URL.
    return channels.distinctBy { it.streamUrl.trim() }
  }

  private fun resolveStreamUrl(raw: String, baseUrl: String?): String {
    val value = raw.trim()
    val lower = value.lowercase()
    if (lower.startsWith("http://") || lower.startsWith("https://") ||
      lower.startsWith("rtsp://") || lower.startsWith("rtmp://") ||
      lower.startsWith("mms://") || lower.startsWith("udp://")
    ) {
      return value
    }
    if (baseUrl.isNullOrBlank()) return value
    return try {
      URL(URL(baseUrl), value).toString()
    } catch (_: Exception) {
      value
    }
  }

  private fun normalizePlaylistUrl(raw: String): String {
    val value = raw.trim()
    require(value.isNotBlank()) { "رابط القائمة فارغ" }
    val withScheme = if (value.startsWith("http://", true) || value.startsWith("https://", true)) value else "http://$value"
    val parsed = URL(withScheme)
    require(parsed.host.isNotBlank()) { "رابط القائمة غير صالح" }
    return withScheme
  }

  private fun classify(group: String, name: String): String {
    val g = (group + " " + name).lowercase()
    return when {
      listOf("series", "serial", "مسلسل", "مسلسلات", "serie", "tv show").any { g.contains(it) } -> "series"
      listOf("movie", "movies", "vod", "film", "cinema", "أفلام", "افلام", "فيلم").any { g.contains(it) } -> "movie"
      else -> "live"
    }
  }

  private fun extractAttribute(line: String, attribute: String): String? {
    val patterns = listOf(
      """${attribute}="([^"]*)"""",
      """${attribute}='([^']*)'""",
      """${attribute}=([^\s,]+)"""
    )
    for (pattern in patterns) {
      val regex = Regex(pattern, RegexOption.IGNORE_CASE)
      val match = regex.find(line)
      if (match != null) {
        return match.groupValues[1].ifBlank { null }
      }
    }
    return null
  }
}
