package com.hyiptv.player.data.remote

import com.hyiptv.player.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Basic Stalker / Ministra Portal client.
 * Many portals use slightly different paths; this covers the most common ones.
 */
class StalkerApi {

  private val MAG_USER_AGENT =
    "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

  private val client = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .followRedirects(true)
    .build()

  private fun normalizePortalUrl(url: String): String {
    var u = url.trim().removeSuffix("/")
    if (!u.startsWith("http://", ignoreCase = true) && !u.startsWith("https://", ignoreCase = true)) {
      u = "http://$u"
    }
    return u
  }

  /** Build portal endpoints without duplicating a supplied base path such as /c. */
  private fun portalEndpoints(base: String, query: String): List<String> {
    val uri = java.net.URI(base)
    val origin = "${uri.scheme}://${uri.rawAuthority}"
    val basePath = (uri.rawPath ?: "").trimEnd('/')
    val paths = linkedSetOf<String>()
    // If the user supplied /c (or another portal prefix), try it first.
    paths += "${basePath}/portal.php"
    // Also support portals configured at the domain root.
    paths += "/portal.php"
    // Common Ministra/Stalker installation path.
    paths += "/stalker_portal/server/load.php"
    return paths.map { path -> "$origin$path?$query" }
  }

  /**
   * Perform handshake and return token if successful.
   */
  suspend fun handshake(portalUrl: String, mac: String): Result<String> = withContext(Dispatchers.IO) {
    try {
      val base = normalizePortalUrl(portalUrl)
      val endpoints = portalEndpoints(
        base, "type=stb&action=handshake&JsHttpRequest=1-xml"
      )

      var lastError = "Handshake failed"
      for (endpoint in endpoints) {
        val request = Request.Builder()
          .url(endpoint)
          .header("User-Agent", MAG_USER_AGENT)
          .header("X-User-Agent", "Model: MAG254; Link: Ethernet")
          .header("Cookie", "mac=${mac.lowercase()}; stb_lang=en; timezone=GMT")
          .get()
          .build()

        try {
          client.newCall(request).execute().use { response ->
            val body = response.body?.string()
            if (body == null) {
              lastError = "Empty response"
              return@use
            }
            if (!response.isSuccessful) {
              lastError = "HTTP ${response.code}"
              return@use
            }
            val token = extractToken(body)
            if (token != null) {
              return@withContext Result.success(token)
            }
            lastError = "No token in response"
          }
        } catch (e: Exception) {
          lastError = e.message ?: "Request failed"
        }
      }
      Result.failure(Exception(lastError))
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun extractToken(body: String): String? {
    return try {
      val json = JSONObject(body)
      if (json.has("js")) {
        val js = json.getJSONObject("js")
        if (js.has("token")) return js.getString("token")
      }
      if (json.has("token")) return json.getString("token")
      null
    } catch (e: Exception) {
      val regex = Regex("\"token\"\\s*:\\s*\"([^\"]+)\"")
      regex.find(body)?.groupValues?.get(1)
    }
  }

  /**
   * Load live channels after successful handshake.
   */
  suspend fun getLiveChannels(
    portalUrl: String,
    mac: String,
    token: String
  ): Result<List<Channel>> = withContext(Dispatchers.IO) {
    try {
      val base = normalizePortalUrl(portalUrl)
      val endpoints = portalEndpoints(
        base, "type=itv&action=get_all_channels&JsHttpRequest=1-xml"
      )

      for (endpoint in endpoints) {
        val request = Request.Builder()
          .url(endpoint)
          .header("User-Agent", MAG_USER_AGENT)
          .header("X-User-Agent", "Model: MAG254; Link: Ethernet")
          .header("Cookie", "mac=${mac.lowercase()}; stb_lang=en; timezone=GMT")
          .header("Authorization", "Bearer $token")
          .get()
          .build()

        try {
          client.newCall(request).execute().use { response ->
            val body = response.body?.string()
            if (body == null || !response.isSuccessful) {
              return@use
            }
            val channels = parseChannels(body, base)
            if (channels.isNotEmpty()) {
              return@withContext Result.success(resolveCommands(base, mac, token, channels))
            }
          }
        } catch (_: Exception) {
          // try next endpoint
        }
      }
      Result.failure(Exception("Could not load channels from portal"))
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun parseChannels(body: String, baseUrl: String): List<Channel> {
    val list = mutableListOf<Channel>()
    try {
      val json = JSONObject(body)
      val js = if (json.has("js")) json.getJSONObject("js") else json
      val data = when {
        js.has("data") -> js.getJSONArray("data")
        js.has("channels") -> js.getJSONArray("channels")
        else -> return emptyList()
      }

      for (i in 0 until data.length()) {
        val item = data.getJSONObject(i)
        val name = item.optString("name", item.optString("title", "Channel ${i + 1}"))
        val cmd = item.optString("cmd", item.optString("url", ""))
        val logo = item.optString("logo", item.optString("logo_url", null))
        val genre = item.optString("genre", item.optString("category", "Live"))

        var streamUrl = cmd
          .removePrefix("ffmpeg ")
          .removePrefix("auto ")
          .trim()

        if (streamUrl.isBlank() && item.has("id")) {
          val id = item.getString("id")
          streamUrl =
            "$baseUrl/portal.php?type=itv&action=create_link&cmd=$id&JsHttpRequest=1-xml"
        }

        if (streamUrl.isNotBlank()) {
          list.add(
            Channel(
              id = item.optString("id", UUID.randomUUID().toString()),
              name = name,
              streamUrl = streamUrl,
              logoUrl = logo?.ifBlank { null },
              group = genre.ifBlank { "Live" }
            )
          )
        }
      }
    } catch (_: Exception) {
      // ignore parse errors for this endpoint
    }
    return list
  }

  /**
   * Ask the portal for a real media URL. Many Stalker servers return a cmd
   * such as "ffrt http://..." that is not playable until create_link runs.
   */
  fun createLink(portalUrl: String, mac: String, token: String, cmd: String): String? {
    val base = normalizePortalUrl(portalUrl)
    val encoded = URLEncoder.encode(cmd, StandardCharsets.UTF_8.name())
    val endpoints = portalEndpoints(
      base, "type=itv&action=create_link&cmd=$encoded&JsHttpRequest=1-xml"
    )
    for (endpoint in endpoints) {
      val request = Request.Builder()
        .url(endpoint)
        .header("User-Agent", MAG_USER_AGENT)
        .header("X-User-Agent", "Model: MAG254; Link: Ethernet")
        .header("Cookie", "mac=${mac.lowercase()}; stb_lang=en; timezone=GMT")
        .header("Authorization", "Bearer $token")
        .get()
        .build()
      try {
        client.newCall(request).execute().use { response ->
          val body = response.body?.string() ?: return@use
          val link = extractPlayableCmd(body)
          if (!link.isNullOrBlank()) return link
        }
      } catch (_: Exception) {
        // try the next portal path
      }
    }
    return null
  }

  fun needsResolve(url: String): Boolean {
    val value = url.trim().lowercase()
    if (value.isBlank()) return false
    return value.contains("portal.php") ||
      value.contains("action=create_link") ||
      value.startsWith("ffmpeg ") ||
      value.startsWith("ffrt ") ||
      value.startsWith("auto ")
  }

  fun commandFromStoredUrl(url: String): String {
    val trimmed = url.trim()
    val query = trimmed.substringAfter("cmd=", "")
    if (query.isNotEmpty() && trimmed.contains("create_link")) {
      val raw = query.substringBefore("&")
      return try {
        URLDecoder.decode(raw, StandardCharsets.UTF_8.name())
      } catch (_: Exception) {
        raw
      }
    }
    return trimmed
  }

  private fun resolveCommands(base: String, mac: String, token: String, channels: List<Channel>): List<Channel> {
    return channels.map { channel ->
      val direct = cleanPlayable(channel.streamUrl)
      if (direct != null && !needsResolve(direct)) {
        channel.copy(streamUrl = direct)
      } else {
        val cmd = commandFromStoredUrl(channel.streamUrl)
        val linked = createLink(base, mac, token, cmd)
        if (linked != null) channel.copy(streamUrl = linked) else channel
      }
    }
  }

  private fun extractPlayableCmd(body: String): String? {
    return try {
      val json = JSONObject(body)
      val js = if (json.has("js")) json.get("js") else json
      val cmd = when (js) {
        is JSONObject -> js.optString("cmd", js.optString("url", ""))
        else -> ""
      }
      cleanPlayable(cmd)
    } catch (_: Exception) {
      null
    }
  }

  private fun cleanPlayable(cmd: String): String? {
    var value = cmd.trim()
    if (value.isBlank()) return null
    value = value.removePrefix("ffmpeg ").removePrefix("ffrt ").removePrefix("auto ").trim()
    val httpAt = value.indexOf("http")
    if (httpAt > 0) value = value.substring(httpAt)
    val lower = value.lowercase()
    val direct = lower.startsWith("http://") || lower.startsWith("https://") ||
      lower.startsWith("rtsp://") || lower.startsWith("rtmp://")
    if (!direct || needsResolve(value)) return null
    return value
  }

  /**
   * Generate a realistic-looking MAC from a device id (for portals that require MAC).
   */
  fun generateMacFromDeviceId(deviceId: String): String {
    val digest = java.security.MessageDigest.getInstance("SHA-256")
      .digest(deviceId.toByteArray(Charsets.UTF_8))
    val bytes = digest.copyOfRange(0, 6)
    // Locally administered unicast MAC; stable for this installation identifier.
    bytes[0] = ((bytes[0].toInt() and 0xFE) or 0x02).toByte()
    return bytes.joinToString(":") { "%02X".format(it) }
  }
}
